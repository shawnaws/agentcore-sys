# Multi-Language Code Snippets

This file contains code snippets extracted from the .jsii.tabl.json file, organized by programming language.

**Total snippets processed:** 55
**Languages available:** python, csharp, java, go, TypeScript

## Table of Contents

- [TypeScript](#typescript)
- [Python](#python)
- [Java](#java)
- [Csharp](#csharp)
- [Go](#go)

---

## TypeScript

**55 snippet(s) available**

### Snippet 1 (ID: 51c2184c...)

```typescript
// Create a new API key identity
const apiKeyIdentityArn = "your-api-key-arn"
```

### Snippet 2 (ID: 6c86e96d...)

```typescript
const oauthIdentityArn = "oauth-idp-arn";
```

### Snippet 3 (ID: 50e9623f...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});

// The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create runtime using the built image
const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact
});
```

### Snippet 4 (ID: bd4fbd33...)

```typescript
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromAsset(
  path.join(__dirname, "path to agent dockerfile directory")
);

const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
});
```

### Snippet 5 (ID: 837f5f72...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});

//Initial Deployment - Automatically creates Version 1
const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0"),
});
// At this point: A DEFAULT endpoint is created which points to version 1

// You can create a new endpoint (production) which points to version1
const prodEndpoint = runtime.addEndpoint("production", {
  version: "1",
  description: "Stable production endpoint - pinned to v1"
});

// When you update the runtime configuration e.g. new container image, protocol change, network settings
// a new version (Version 2) is automatically created

// After update: Version 2 is created automatically
// DEFAULT endpoint automatically updates to Version 2
// Production endpoint remains on Version 1 (explicitly pinned)

// Now that Version 2 exists, create a staging endpoint for testing
const stagingEndpoint = runtime.addEndpoint("staging", {
  version: "2",
  description: "Staging environment for testing new version"
});

// Staging endpoint: Points to Version 2 (testing)
// After testing, you can update production endpoint to Version 2 using the AWS Console or APIs
```

### Snippet 6 (ID: 97a9a76c...)

```typescript
// Reference an existing runtime by its ID
const existingRuntimeId = "abc123-runtime-id"; // The ID of an existing runtime

// Create a standalone endpoint
const endpoint = new agentcore.RuntimeEndpoint(this, "MyEndpoint", {
  endpointName: "production",
  agentRuntimeId: existingRuntimeId,
  agentRuntimeVersion: "1", // Specify which version to use
  description: "Production endpoint for existing runtime"
});
```

### Snippet 7 (ID: d4ae6d28...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  authorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration.usingCognito(
    "us-west-2_ABC123",  // User Pool ID (required)
    "client123",         // Client ID (required)
    "us-west-2"         // Region (optional, defaults to stack region)
  ),
});
```

### Snippet 8 (ID: 8bced5c5...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  authorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration.usingJWT(
    "https://example.com/.well-known/openid-configuration",  // Discovery URL (required)
    ["client1", "client2"],  // Allowed Client IDs (optional)
    ["audience1"]           // Allowed Audiences (optional)
  ),
});
```

### Snippet 9 (ID: 2271afce...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  authorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration.usingOAuth(
    "https://github.com/.well-known/openid-configuration",
    "oauth_client_123",
  ),
});
```

### Snippet 10 (ID: b84b740e...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Explicitly using public network (this is the default)
const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  networkConfiguration: agentcore.RuntimeNetworkConfiguration.usingPublicNetwork(),
});
```

### Snippet 11 (ID: b72e3ac0...)

```typescript
const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create or use an existing VPC
const vpc = new ec2.Vpc(this, 'MyVpc', {
  maxAzs: 2,
});

// Configure runtime with VPC
const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  networkConfiguration: agentcore.RuntimeNetworkConfiguration.usingVpc(this, {
    vpc: vpc,
    vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
    // Optionally specify security groups, or one will be created automatically
    // securityGroups: [mySecurityGroup],
  }),
});
```

### Snippet 12 (ID: 545b0fa6...)

```typescript
const vpc = new ec2.Vpc(this, 'MyVpc', {
  maxAzs: 2,
});

const repository = new ecr.Repository(this, "TestRepository", {
  repositoryName: "test-agent-runtime",
});
const agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create runtime with VPC configuration
const runtime = new agentcore.Runtime(this, "MyAgentRuntime", {
  runtimeName: "myAgent",
  agentRuntimeArtifact: agentRuntimeArtifact,
  networkConfiguration: agentcore.RuntimeNetworkConfiguration.usingVpc(this, {
    vpc: vpc,
    vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
  }),
});

// Now you can manage network access using the connections property
// Allow inbound HTTPS traffic from a specific security group
const webServerSecurityGroup = new ec2.SecurityGroup(this, 'WebServerSG', { vpc });
runtime.connections.allowFrom(webServerSecurityGroup, ec2.Port.tcp(443), 'Allow HTTPS from web servers');

// Allow outbound connections to a database
const databaseSecurityGroup = new ec2.SecurityGroup(this, 'DatabaseSG', { vpc });
runtime.connections.allowTo(databaseSecurityGroup, ec2.Port.tcp(5432), 'Allow PostgreSQL connection');

// Allow outbound HTTPS to anywhere (for external API calls)
runtime.connections.allowToAnyIpv4(ec2.Port.tcp(443), 'Allow HTTPS outbound');
```

### Snippet 13 (ID: 920d31a1...)

```typescript

// Create a basic memory with default settings, no LTM strategies
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my_memory",
  description: "A memory for storing user interactions for a period of 90 days",
  expirationDuration: cdk.Duration.days(90),
});
```

### Snippet 14 (ID: de9dfac6...)

```typescript
// Create a custom KMS key for encryption
const encryptionKey = new kms.Key(this, "MemoryEncryptionKey", {
  enableKeyRotation: true,
  description: "KMS key for memory encryption",
});

// Create memory with custom encryption
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my_encrypted_memory",
  description: "Memory with custom KMS encryption",
  expirationDuration: cdk.Duration.days(90),
  kmsKey: encryptionKey,
});
```

### Snippet 15 (ID: b638db3f...)

```typescript
// Create memory with built-in strategies
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my_memory",
  description: "Memory with built-in strategies",
  expirationDuration: cdk.Duration.days(90),
  memoryStrategies: [
    agentcore.MemoryStrategy.usingBuiltInSummarization(),
    agentcore.MemoryStrategy.usingBuiltInSemantic(),
    agentcore.MemoryStrategy.usingBuiltInUserPreference(),
  ],
});
```

### Snippet 16 (ID: c943056b...)

```typescript
// Create memory with built-in strategies
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my_memory",
  description: "Memory with built-in strategies",
  expirationDuration: cdk.Duration.days(90),
  memoryStrategies: [
    agentcore.MemoryStrategy.usingUserPreference({
        name: "CustomerPreferences",
        namespaces: ["support/customer/{actorId}/preferences"]
    }),
    agentcore.MemoryStrategy.usingSemantic({
        name: "CustomerSupportSemantic",
        namespaces: ["support/customer/{actorId}/semantic"]
    }),
  ],
});
```

### Snippet 17 (ID: 3b589e6a...)

```typescript
// Create a custom execution role
const executionRole = new iam.Role(this, "MemoryExecutionRole", {
  assumedBy: new iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
  managedPolicies: [
    iam.ManagedPolicy.fromAwsManagedPolicyName(
      "AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy"
    ),
  ],
});

// Create memory with custom execution role
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my_memory",
  description: "Memory with custom execution role",
  expirationDuration: cdk.Duration.days(90),
 // executionRole: executionRole,
});
```

### Snippet 18 (ID: 853451ae...)

```typescript
// Create a custom semantic memory strategy
const customSemanticStrategy = agentcore.MemoryStrategy.usingSemanticOverride({
  name: "customSemanticStrategy",
  description: "Custom semantic memory strategy",
  namespaces: ["/custom/strategies/{memoryStrategyId}/actors/{actorId}"],
  customConsolidation: {
    model: bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
    appendToPrompt: "Custom consolidation prompt for semantic memory",
  },
  customExtraction: {
    model: bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
    appendToPrompt: "Custom extraction prompt for semantic memory",
  },
});

// Create memory with custom strategy
const memory = new agentcore.Memory(this, "MyMemory", {
  memoryName: "my-custom-memory",
  description: "Memory with custom strategy",
  expirationDuration: cdk.Duration.days(90),
  memoryStrategies: [customSemanticStrategy],
});
```

### Snippet 19 (ID: aa0231c9...)

```typescript
// Create memory without initial strategies
const memory = new agentcore.Memory(this, "test-memory", {
  memoryName: "test_memory_add_strategy",
  description: "A test memory for testing addMemoryStrategy method",
  expirationDuration: cdk.Duration.days(90),
});

// Add strategies after instantiation
memory.addMemoryStrategy(agentcore.MemoryStrategy.usingBuiltInSummarization());
memory.addMemoryStrategy(agentcore.MemoryStrategy.usingBuiltInSemantic());
```

### Snippet 20 (ID: aef59cfa...)

```typescript
// Create a basic browser with public network access
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "A browser for web automation",
});
```

### Snippet 21 (ID: 15980722...)

```typescript
// Create a browser with custom tags
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "A browser for web automation with tags",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingPublicNetwork(),
  tags: {
    Environment: "Production",
    Team: "AI/ML",
    Project: "AgentCore",
  },
});
```

### Snippet 22 (ID: 5db8ac38...)

```typescript
const browser = new agentcore.BrowserCustom(this, 'BrowserVpcWithRecording', {
  browserCustomName: 'browser_recording',
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingVpc(this, {
    vpc: new ec2.Vpc(this, 'VPC', { restrictDefaultSecurityGroup: false }),
  }),
});
```

### Snippet 23 (ID: 3611091a...)

```typescript
const vpc = new ec2.Vpc(this, 'testVPC');

const browser = new agentcore.BrowserCustom(this, 'test-browser', {
  browserCustomName: 'test_browser',
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingVpc(this, {
    vpc: vpc,
  }),
});

browser.connections.addSecurityGroup(new ec2.SecurityGroup(this, 'AdditionalGroup', { vpc }));
```

### Snippet 24 (ID: 5177993c...)

```typescript
// Create an S3 bucket for recordings
const recordingBucket = new s3.Bucket(this, "RecordingBucket", {
  bucketName: "my-browser-recordings",
  removalPolicy: RemovalPolicy.DESTROY, // For demo purposes
});

// Create browser with recording enabled
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "Browser with recording enabled",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingPublicNetwork(),
  recordingConfig: {
    enabled: true,
    s3Location: {
      bucketName: recordingBucket.bucketName,
      objectKey: "browser-recordings/",
    },
  },
});
```

### Snippet 25 (ID: 27976676...)

```typescript
// Create a custom execution role
const executionRole = new iam.Role(this, "BrowserExecutionRole", {
  assumedBy: new iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
  managedPolicies: [
    iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonBedrockAgentCoreBrowserExecutionRolePolicy"),
  ],
});

// Create browser with custom execution role
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "Browser with custom execution role",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingPublicNetwork(),
  executionRole: executionRole,
});
```

### Snippet 26 (ID: ac3e1e5e...)

```typescript
// Create an S3 bucket for recordings
const recordingBucket = new s3.Bucket(this, "RecordingBucket", {
  bucketName: "my-browser-recordings",
  removalPolicy: RemovalPolicy.DESTROY, // For demo purposes
});

// Create browser with recording enabled
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "Browser with recording enabled",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingPublicNetwork(),
  recordingConfig: {
    enabled: true,
    s3Location: {
      bucketName: recordingBucket.bucketName,
      objectKey: "browser-recordings/",
    },
  },
});

// The browser construct automatically grants S3 permissions to the execution role
// when recording is enabled, so no additional IAM configuration is needed
```

### Snippet 27 (ID: 444b170b...)

```typescript
// Create a browser
const browser = new agentcore.BrowserCustom(this, "MyBrowser", {
  browserCustomName: "my_browser",
  description: "Browser for web automation",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingPublicNetwork(),
});

// Create a role that needs access to the browser
const userRole = new iam.Role(this, "UserRole", {
  assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
});

// Grant read permissions (Get and List actions)
browser.grantRead(userRole);

// Grant use permissions (Start, Update, Stop actions)
browser.grantUse(userRole);

// Grant specific custom permissions
browser.grant(userRole, "bedrock-agentcore:GetBrowserSession");
```

### Snippet 28 (ID: a016e911...)

```typescript
// Create a basic gateway with default MCP protocol and Cognito authorizer
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
});
```

### Snippet 29 (ID: cddccfcc...)

```typescript
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
});
```

### Snippet 30 (ID: 2cf05827...)

```typescript
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
});
```

### Snippet 31 (ID: cdfb1cbb...)

```typescript
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  authorizerConfiguration: agentcore.GatewayAuthorizer.awsIam,
});

// Grant access to a Lambda function's role
const lambdaRole = new iam.Role(this, "LambdaRole", {
  assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
});

// The Lambda needs permission to invoke the gateway
gateway.grantInvoke(lambdaRole);
```

### Snippet 32 (ID: 1b96e6d2...)

```typescript
// Create a KMS key for encryption
const encryptionKey = new kms.Key(this, "GatewayEncryptionKey", {
  enableKeyRotation: true,
  description: "KMS key for gateway encryption",
});

// Create gateway with KMS encryption
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-encrypted-gateway",
  description: "Gateway with KMS encryption",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
  kmsKey: encryptionKey,
  exceptionLevel: agentcore.GatewayExceptionLevel.DEBUG,
});
```

### Snippet 33 (ID: 2fae250c...)

```typescript
// Create a custom execution role
const executionRole = new iam.Role(this, "GatewayExecutionRole", {
  assumedBy: new iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
  managedPolicies: [
    iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonBedrockAgentCoreGatewayExecutionRolePolicy"),
  ],
});

// Create gateway with custom execution role
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  description: "Gateway with custom execution role",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
  role: executionRole,
});
```

### Snippet 34 (ID: a47f4a02...)

```typescript
// Create a gateway
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  description: "Gateway for external service integration",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
});

// Create a role that needs access to the gateway
const userRole = new iam.Role(this, "UserRole", {
  assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
});

// Grant read permissions (Get and List actions)
gateway.grantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
gateway.grantManage(userRole);

// Grant specific custom permissions
gateway.grant(userRole, "bedrock-agentcore:GetGateway");
```

### Snippet 35 (ID: 52d6584e...)

```typescript
const toolSchema = agentcore.ToolSchema.fromLocalAsset(
    path.join(__dirname, "schemas", "my-tool-schema.json")
  );
```

### Snippet 36 (ID: 14041e87...)

```typescript

const toolSchema = agentcore.ToolSchema.fromS3File(
    s3.Bucket.fromBucketName(this, "SchemasBucket", "my-schemas-bucket"),
    "tools/complex-tool-schema.json",
    "123456789012"
  );
```

### Snippet 37 (ID: 11b5c8ff...)

```typescript
const toolSchema = agentcore.ToolSchema.fromInline([{
      name: "hello_world",
      description: "A simple hello world tool",
      inputSchema: {
        type: agentcore.SchemaDefinitionType.OBJECT,
        properties: {
          name: {
            type: agentcore.SchemaDefinitionType.STRING,
            description: "The name to greet",
          },
        },
        required: ["name"],
      },
    }]);
```

### Snippet 38 (ID: bf7d63e6...)

```typescript
// When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
const schema = agentcore.ApiSchema.fromLocalAsset(path.join(__dirname, "mySchema.yml"));
schema.bind(this);
```

### Snippet 39 (ID: dad78422...)

```typescript
const inlineSchema = agentcore.ApiSchema.fromInline(`
openapi: 3.0.3
info:
  title: Library API
  version: 1.0.0
paths:
  /search:
    get:
      summary: Search for books
      operationId: searchBooks
      parameters:
        - name: query
          in: query
          required: true
          schema:
            type: string
`);
```

### Snippet 40 (ID: 23c2fae5...)

```typescript
const bucket = s3.Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
const s3Schema = agentcore.ApiSchema.fromS3File(bucket, "schemas/action-group.yaml");
```

### Snippet 41 (ID: 5fbfe426...)

```typescript
// Create a gateway first
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
});

// These ARNs are returned when creating the API key credential provider via Console or API
const apiKeyProviderArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
const apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

const bucket = s3.Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
const s3mySchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

// Add an OpenAPI target directly to the gateway
const target = gateway.addOpenApiTarget("MyTarget", {
  gatewayTargetName: "my-api-target",
  description: "Target for external API integration",
  apiSchema: s3mySchema,
  credentialProviderConfigurations: [
    agentcore.GatewayCredentialProvider.apiKey({
      providerArn: apiKeyProviderArn,
      secretArn: apiKeySecretArn,
      credentialLocation: agentcore.ApiKeyCredentialLocation.header({
        credentialParameterName: "X-API-Key",
      }),
    }),
  ],
});

// Add a Lambda target
const lambdaFunction = new lambda.Function(this, "MyFunction", {
  runtime: lambda.Runtime.NODEJS_22_X,
  handler: "index.handler",
  code: lambda.Code.fromInline(`
    exports.handler = async (event) => {
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Hello from Lambda!' })
      };
    };
  `),
});

const lambdaTarget = gateway.addLambdaTarget("MyLambdaTarget", {
  gatewayTargetName: "my-lambda-target",
  description: "Lambda function target",
  lambdaFunction: lambdaFunction,
  toolSchema: agentcore.ToolSchema.fromInline([
    {
      name: "hello_world",
      description: "A simple hello world tool",
      inputSchema: {
        type: agentcore.SchemaDefinitionType.OBJECT,
        properties: {
          name: {
            type: agentcore.SchemaDefinitionType.STRING,
            description: "The name to greet",
          },
        },
        required: ["name"],
      },
    },
  ]),
});

// Add a Smithy target
const smithySchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/mymodel.json");
const smithyTarget = gateway.addSmithyTarget("MySmithyTarget", {
  gatewayTargetName: "my-smithy-target",
  description: "Smithy model target",
  smithyModel: smithySchema,
  credentialProviderConfigurations: [
    agentcore.GatewayCredentialProvider.iamRole(),
  ],
});
```

### Snippet 42 (ID: 3293480b...)

```typescript
// Create a gateway first
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
});

const apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
const apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

const bucket = s3.Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
const s3Schema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

// Create a gateway target with OpenAPI Schema
const openApitarget = agentcore.GatewayTarget.forOpenApi(this, "MyTarget", {
  gatewayTargetName: "my-api-target",
  description: "Target for external API integration",
  gateway: gateway,  // Note: you need to pass the gateway reference
  apiSchema: s3Schema,
  credentialProviderConfigurations: [
    agentcore.GatewayCredentialProvider.apiKey({
     providerArn: apiKeyIdentityArn,
     secretArn: apiKeySecretArn,
      credentialLocation: agentcore.ApiKeyCredentialLocation.header({
        credentialParameterName: "X-API-Key",
      }),
    }),
  ],
});

// Create a Lambda function
const lambdaFunction = new lambda.Function(this, "MyFunction", {
  runtime: lambda.Runtime.NODEJS_22_X,
  handler: "index.handler",
  code: lambda.Code.fromInline(`
        exports.handler = async (event) => {
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Hello from Lambda!' })
            };
        };
    `),
});

// Create a gateway target with Lambda and tool schema
const lambdaTarget = agentcore.GatewayTarget.forLambda(this, "MyLambdaTarget", {
  gatewayTargetName: "my-lambda-target",
  description: "Target for Lambda function integration",
  gateway: gateway,
  lambdaFunction: lambdaFunction,
  toolSchema: agentcore.ToolSchema.fromInline([
    {
      name: "hello_world",
      description: "A simple hello world tool",
      inputSchema: {
        type: agentcore.SchemaDefinitionType.OBJECT,
        description: "Input schema for hello world tool",
        properties: {
          name: {
            type: agentcore.SchemaDefinitionType.STRING,
            description: "The name to greet",
          },
        },
        required: ["name"],
      },
      outputSchema: {
        type: agentcore.SchemaDefinitionType.OBJECT,
        description: "Output schema for hello world tool",
        properties: {
          message: {
            type: agentcore.SchemaDefinitionType.STRING,
            description: "The greeting message",
          },
        },
      },
    },
  ]),
  credentialProviderConfigurations: [agentcore.GatewayCredentialProvider.iamRole()],
});


// Create an OAuth identity
const oauthIdentityArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth123"
const oauthSecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

const schemaBucket = s3.Bucket.fromBucketName(this, "SchemaBucket", "my-schema-bucket");
const s3SmithySchema = agentcore.ApiSchema.fromS3File(schemaBucket, "schemas/myschema.json");

// Create a gateway target with Smithy Model and OAuth
const target = agentcore.GatewayTarget.forSmithy(this, "MySmithyTarget", {
  gatewayTargetName: "my-smithy-target",
  description: "Target for Smithy model integration",
  gateway: gateway,
  smithyModel: s3SmithySchema,
  credentialProviderConfigurations: [
    agentcore.GatewayCredentialProvider.oauth({
      providerArn: oauthIdentityArn,
      secretArn: oauthSecretArn,
      scopes: ["read", "write"],
      customParameters: {
        audience: "https://api.example.com",
        response_type: "code",
      },
    }),
  ],
});
```

### Snippet 43 (ID: 7d741b0e...)

```typescript
// Create a gateway and target
const gateway = new agentcore.Gateway(this, "MyGateway", {
  gatewayName: "my-gateway",
  protocolConfiguration: new agentcore.McpProtocolConfiguration({
    instructions: "Use this gateway to connect to external MCP tools",
    searchType: agentcore.McpGatewaySearchType.SEMANTIC,
    supportedVersions: [agentcore.MCPProtocolVersion.MCP_2025_03_26],
  }),
  authorizerConfiguration: agentcore.GatewayAuthorizer.usingCustomJwt({
    discoveryUrl: "https://auth.example.com/.well-known/openid-configuration",
    allowedAudience: ["my-app"],
    allowedClients: ["my-client-id"],
  }),
});

const apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
const apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

const bucket = s3.Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
const s3apiSchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

const target = agentcore.GatewayTarget.forOpenApi(this, "MyTarget", {
  gatewayTargetName: "my-target",
  gateway: gateway,
  apiSchema: s3apiSchema,
  credentialProviderConfigurations: [
    agentcore.GatewayCredentialProvider.apiKey({
     providerArn: apiKeyIdentityArn,
     secretArn: apiKeySecretArn,
      credentialLocation: agentcore.ApiKeyCredentialLocation.header({
        credentialParameterName: "X-API-Key",
      }),
    }),
  ],
});

// Create a role that needs access to the gateway target
const userRole = new iam.Role(this, "UserRole", {
  assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
});

// Grant read permissions (Get and List actions)
target.grantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
target.grantManage(userRole);

// Grant specific custom permissions
target.grant(userRole, "bedrock-agentcore:GetGatewayTarget");
```

### Snippet 44 (ID: fde53762...)

```typescript
// Create a basic code interpreter with public network access
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_code_interpreter",
  description: "A code interpreter for Python execution",
});
```

### Snippet 45 (ID: fd30da56...)

```typescript
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_sandbox_interpreter",
  description: "Code interpreter with isolated network access",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingVpc(this, {
    vpc: new ec2.Vpc(this, 'VPC', { restrictDefaultSecurityGroup: false }),
  }),
});
```

### Snippet 46 (ID: 504a5940...)

```typescript
const vpc = new ec2.Vpc(this, 'testVPC');

const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_sandbox_interpreter",
  description: "Code interpreter with isolated network access",
  networkConfiguration: agentcore.BrowserNetworkConfiguration.usingVpc(this, {
    vpc: vpc,
  }),
});

codeInterpreter.connections.addSecurityGroup(new ec2.SecurityGroup(this, 'AdditionalGroup', { vpc }));
```

### Snippet 47 (ID: aa6f2dda...)

```typescript
// Create code interpreter with sandbox network mode (isolated)
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_sandbox_interpreter",
  description: "Code interpreter with isolated network access",
  networkConfiguration: agentcore.CodeInterpreterNetworkConfiguration.usingSandboxNetwork(),
});
```

### Snippet 48 (ID: a7071766...)

```typescript
// Create a custom execution role
const executionRole = new iam.Role(this, "CodeInterpreterExecutionRole", {
  assumedBy: new iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
});

// Create code interpreter with custom execution role
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_code_interpreter",
  description: "Code interpreter with custom execution role",
  networkConfiguration: agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork(),
  executionRole: executionRole,
});
```

### Snippet 49 (ID: cedd86ae...)

```typescript
// Create a code interpreter
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_code_interpreter",
  description: "Code interpreter for Python execution",
  networkConfiguration: agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork(),
});

// Create a role that needs access to the code interpreter
const userRole = new iam.Role(this, "UserRole", {
  assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
});

// Grant read permissions (Get and List actions)
codeInterpreter.grantRead(userRole);

// Grant use permissions (Start, Invoke, Stop actions)
codeInterpreter.grantUse(userRole);

// Grant specific custom permissions
codeInterpreter.grant(userRole, "bedrock-agentcore:GetCodeInterpreterSession");
```

### Snippet 50 (ID: 65a79060...)

```typescript
// Create code interpreter with sandbox network mode (isolated)
const codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", {
  codeInterpreterCustomName: "my_sandbox_interpreter",
  description: "Code interpreter with isolated network access",
  networkConfiguration: agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork(),
  tags: {
    Environment: "Production",
    Team: "AI/ML",
    Project: "AgentCore",
  },
});
```

### Snippet 51 (ID: cae11061...)

```typescript
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123"
```

### Snippet 52 (ID: 0471d468...)

```typescript
"runtime-abc123"
```

### Snippet 53 (ID: 6b4f6935...)

```typescript
"2024-01-15T10:30:00Z"
```

### Snippet 54 (ID: 379fc387...)

```typescript
"2024-01-15T14:45:00Z"
```

### Snippet 55 (ID: 7e85b1e8...)

```typescript
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123"
```

---

## Python

**55 snippet(s) available**

### Snippet 1 (ID: 51c2184c...)

```python
# Create a new API key identity
api_key_identity_arn = "your-api-key-arn"
```

### Snippet 2 (ID: 6c86e96d...)

```python
oauth_identity_arn = "oauth-idp-arn"
```

### Snippet 3 (ID: 50e9623f...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

# The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create runtime using the built image
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

### Snippet 4 (ID: bd4fbd33...)

```python
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_asset(
    path.join(__dirname, "path to agent dockerfile directory"))

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact
)
```

### Snippet 5 (ID: 837f5f72...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)

# Initial Deployment - Automatically creates Version 1
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")
)
# At this point: A DEFAULT endpoint is created which points to version 1

# You can create a new endpoint (production) which points to version1
prod_endpoint = runtime.add_endpoint("production",
    version="1",
    description="Stable production endpoint - pinned to v1"
)

# When you update the runtime configuration e.g. new container image, protocol change, network settings
# a new version (Version 2) is automatically created

# After update: Version 2 is created automatically
# DEFAULT endpoint automatically updates to Version 2
# Production endpoint remains on Version 1 (explicitly pinned)

# Now that Version 2 exists, create a staging endpoint for testing
staging_endpoint = runtime.add_endpoint("staging",
    version="2",
    description="Staging environment for testing new version"
)
```

### Snippet 6 (ID: 97a9a76c...)

```python
# Reference an existing runtime by its ID
existing_runtime_id = "abc123-runtime-id" # The ID of an existing runtime

# Create a standalone endpoint
endpoint = agentcore.RuntimeEndpoint(self, "MyEndpoint",
    endpoint_name="production",
    agent_runtime_id=existing_runtime_id,
    agent_runtime_version="1",  # Specify which version to use
    description="Production endpoint for existing runtime"
)
```

### Snippet 7 (ID: d4ae6d28...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_cognito("us-west-2_ABC123", "client123", "us-west-2")
)
```

### Snippet 8 (ID: 8bced5c5...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_jWT("https://example.com/.well-known/openid-configuration", ["client1", "client2"], ["audience1"])
)
```

### Snippet 9 (ID: 2271afce...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    authorizer_configuration=agentcore.RuntimeAuthorizerConfiguration.using_oAuth("https://github.com/.well-known/openid-configuration", "oauth_client_123")
)
```

### Snippet 10 (ID: b84b740e...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Explicitly using public network (this is the default)
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_public_network()
)
```

### Snippet 11 (ID: b72e3ac0...)

```python
repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create or use an existing VPC
vpc = ec2.Vpc(self, "MyVpc",
    max_azs=2
)

# Configure runtime with VPC
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_vpc(self,
        vpc=vpc,
        vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS)
    )
)
```

### Snippet 12 (ID: 545b0fa6...)

```python
vpc = ec2.Vpc(self, "MyVpc",
    max_azs=2
)

repository = ecr.Repository(self, "TestRepository",
    repository_name="test-agent-runtime"
)
agent_runtime_artifact = agentcore.AgentRuntimeArtifact.from_ecr_repository(repository, "v1.0.0")

# Create runtime with VPC configuration
runtime = agentcore.Runtime(self, "MyAgentRuntime",
    runtime_name="myAgent",
    agent_runtime_artifact=agent_runtime_artifact,
    network_configuration=agentcore.RuntimeNetworkConfiguration.using_vpc(self,
        vpc=vpc,
        vpc_subnets=ec2.SubnetSelection(subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS)
    )
)

# Now you can manage network access using the connections property
# Allow inbound HTTPS traffic from a specific security group
web_server_security_group = ec2.SecurityGroup(self, "WebServerSG", vpc=vpc)
runtime.connections.allow_from(web_server_security_group, ec2.Port.tcp(443), "Allow HTTPS from web servers")

# Allow outbound connections to a database
database_security_group = ec2.SecurityGroup(self, "DatabaseSG", vpc=vpc)
runtime.connections.allow_to(database_security_group, ec2.Port.tcp(5432), "Allow PostgreSQL connection")

# Allow outbound HTTPS to anywhere (for external API calls)
runtime.connections.allow_to_any_ipv4(ec2.Port.tcp(443), "Allow HTTPS outbound")
```

### Snippet 13 (ID: 920d31a1...)

```python
# Create a basic memory with default settings, no LTM strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="A memory for storing user interactions for a period of 90 days",
    expiration_duration=cdk.Duration.days(90)
)
```

### Snippet 14 (ID: de9dfac6...)

```python
# Create a custom KMS key for encryption
encryption_key = kms.Key(self, "MemoryEncryptionKey",
    enable_key_rotation=True,
    description="KMS key for memory encryption"
)

# Create memory with custom encryption
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_encrypted_memory",
    description="Memory with custom KMS encryption",
    expiration_duration=cdk.Duration.days(90),
    kms_key=encryption_key
)
```

### Snippet 15 (ID: b638db3f...)

```python
# Create memory with built-in strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with built-in strategies",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[
        agentcore.MemoryStrategy.using_built_in_summarization(),
        agentcore.MemoryStrategy.using_built_in_semantic(),
        agentcore.MemoryStrategy.using_built_in_user_preference()
    ]
)
```

### Snippet 16 (ID: c943056b...)

```python
# Create memory with built-in strategies
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with built-in strategies",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[
        agentcore.MemoryStrategy.using_user_preference(
            name="CustomerPreferences",
            namespaces=["support/customer/{actorId}/preferences"]
        ),
        agentcore.MemoryStrategy.using_semantic(
            name="CustomerSupportSemantic",
            namespaces=["support/customer/{actorId}/semantic"]
        )
    ]
)
```

### Snippet 17 (ID: 3b589e6a...)

```python
# Create a custom execution role
execution_role = iam.Role(self, "MemoryExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy")
    ]
)

# Create memory with custom execution role
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my_memory",
    description="Memory with custom execution role",
    expiration_duration=cdk.Duration.days(90)
)
```

### Snippet 18 (ID: 853451ae...)

```python
# Create a custom semantic memory strategy
custom_semantic_strategy = agentcore.MemoryStrategy.using_semantic_override(
    name="customSemanticStrategy",
    description="Custom semantic memory strategy",
    namespaces=["/custom/strategies/{memoryStrategyId}/actors/{actorId}"],
    custom_consolidation=agentcoreLib.bedrock_agentcore.OverrideConfig(
        model=bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        append_to_prompt="Custom consolidation prompt for semantic memory"
    ),
    custom_extraction=agentcoreLib.bedrock_agentcore.OverrideConfig(
        model=bedrock.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        append_to_prompt="Custom extraction prompt for semantic memory"
    )
)

# Create memory with custom strategy
memory = agentcore.Memory(self, "MyMemory",
    memory_name="my-custom-memory",
    description="Memory with custom strategy",
    expiration_duration=cdk.Duration.days(90),
    memory_strategies=[custom_semantic_strategy]
)
```

### Snippet 19 (ID: aa0231c9...)

```python
# Create memory without initial strategies
memory = agentcore.Memory(self, "test-memory",
    memory_name="test_memory_add_strategy",
    description="A test memory for testing addMemoryStrategy method",
    expiration_duration=cdk.Duration.days(90)
)

# Add strategies after instantiation
memory.add_memory_strategy(agentcore.MemoryStrategy.using_built_in_summarization())
memory.add_memory_strategy(agentcore.MemoryStrategy.using_built_in_semantic())
```

### Snippet 20 (ID: aef59cfa...)

```python
# Create a basic browser with public network access
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="A browser for web automation"
)
```

### Snippet 21 (ID: 15980722...)

```python
# Create a browser with custom tags
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="A browser for web automation with tags",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    tags={
        "Environment": "Production",
        "Team": "AI/ML",
        "Project": "AgentCore"
    }
)
```

### Snippet 22 (ID: 5db8ac38...)

```python
browser = agentcore.BrowserCustom(self, "BrowserVpcWithRecording",
    browser_custom_name="browser_recording",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=ec2.Vpc(self, "VPC", restrict_default_security_group=False)
    )
)
```

### Snippet 23 (ID: 3611091a...)

```python
vpc = ec2.Vpc(self, "testVPC")

browser = agentcore.BrowserCustom(self, "test-browser",
    browser_custom_name="test_browser",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=vpc
    )
)

browser.connections.add_security_group(ec2.SecurityGroup(self, "AdditionalGroup", vpc=vpc))
```

### Snippet 24 (ID: 5177993c...)

```python
# Create an S3 bucket for recordings
recording_bucket = s3.Bucket(self, "RecordingBucket",
    bucket_name="my-browser-recordings",
    removal_policy=RemovalPolicy.DESTROY
)

# Create browser with recording enabled
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with recording enabled",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    recording_config=agentcoreLib.bedrock_agentcore.RecordingConfig(
        enabled=True,
        s3_location=s3.Location(
            bucket_name=recording_bucket.bucket_name,
            object_key="browser-recordings/"
        )
    )
)
```

### Snippet 25 (ID: 27976676...)

```python
# Create a custom execution role
execution_role = iam.Role(self, "BrowserExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreBrowserExecutionRolePolicy")
    ]
)

# Create browser with custom execution role
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with custom execution role",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    execution_role=execution_role
)
```

### Snippet 26 (ID: ac3e1e5e...)

```python
# Create an S3 bucket for recordings
recording_bucket = s3.Bucket(self, "RecordingBucket",
    bucket_name="my-browser-recordings",
    removal_policy=RemovalPolicy.DESTROY
)

# Create browser with recording enabled
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser with recording enabled",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network(),
    recording_config=agentcoreLib.bedrock_agentcore.RecordingConfig(
        enabled=True,
        s3_location=s3.Location(
            bucket_name=recording_bucket.bucket_name,
            object_key="browser-recordings/"
        )
    )
)
```

### Snippet 27 (ID: 444b170b...)

```python
# Create a browser
browser = agentcore.BrowserCustom(self, "MyBrowser",
    browser_custom_name="my_browser",
    description="Browser for web automation",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_public_network()
)

# Create a role that needs access to the browser
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
browser.grant_read(user_role)

# Grant use permissions (Start, Update, Stop actions)
browser.grant_use(user_role)

# Grant specific custom permissions
browser.grant(user_role, "bedrock-agentcore:GetBrowserSession")
```

### Snippet 28 (ID: a016e911...)

```python
# Create a basic gateway with default MCP protocol and Cognito authorizer
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)
```

### Snippet 29 (ID: cddccfcc...)

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    )
)
```

### Snippet 30 (ID: 2cf05827...)

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    )
)
```

### Snippet 31 (ID: cdfb1cbb...)

```python
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    authorizer_configuration=agentcore.GatewayAuthorizer.aws_iam
)

# Grant access to a Lambda function's role
lambda_role = iam.Role(self, "LambdaRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# The Lambda needs permission to invoke the gateway
gateway.grant_invoke(lambda_role)
```

### Snippet 32 (ID: 1b96e6d2...)

```python
# Create a KMS key for encryption
encryption_key = kms.Key(self, "GatewayEncryptionKey",
    enable_key_rotation=True,
    description="KMS key for gateway encryption"
)

# Create gateway with KMS encryption
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-encrypted-gateway",
    description="Gateway with KMS encryption",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    ),
    kms_key=encryption_key,
    exception_level=agentcore.GatewayExceptionLevel.DEBUG
)
```

### Snippet 33 (ID: 2fae250c...)

```python
# Create a custom execution role
execution_role = iam.Role(self, "GatewayExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    managed_policies=[
        iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockAgentCoreGatewayExecutionRolePolicy")
    ]
)

# Create gateway with custom execution role
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    description="Gateway with custom execution role",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    ),
    role=execution_role
)
```

### Snippet 34 (ID: a47f4a02...)

```python
# Create a gateway
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    description="Gateway for external service integration",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    )
)

# Create a role that needs access to the gateway
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
gateway.grant_read(user_role)

# Grant manage permissions (Create, Update, Delete actions)
gateway.grant_manage(user_role)

# Grant specific custom permissions
gateway.grant(user_role, "bedrock-agentcore:GetGateway")
```

### Snippet 35 (ID: 52d6584e...)

```python
tool_schema = agentcore.ToolSchema.from_local_asset(
    path.join(__dirname, "schemas", "my-tool-schema.json"))
```

### Snippet 36 (ID: 14041e87...)

```python
tool_schema = agentcore.ToolSchema.from_s3_file(
    s3.Bucket.from_bucket_name(self, "SchemasBucket", "my-schemas-bucket"), "tools/complex-tool-schema.json", "123456789012")
```

### Snippet 37 (ID: 11b5c8ff...)

```python
tool_schema = agentcore.ToolSchema.from_inline([
    name="hello_world",
    description="A simple hello world tool",
    input_schema=agentcoreLib.bedrock_agentcore.SchemaDefinition(
        type=agentcore.SchemaDefinitionType.OBJECT,
        properties={
            "name": agentcoreLib.bedrock_agentcore.SchemaDefinition(
                type=agentcore.SchemaDefinitionType.STRING,
                description="The name to greet"
            )
        },
        required=["name"]
    )
])
```

### Snippet 38 (ID: bf7d63e6...)

```python
# When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
schema = agentcore.ApiSchema.from_local_asset(path.join(__dirname, "mySchema.yml"))
schema.bind(self)
```

### Snippet 39 (ID: dad78422...)

```python
inline_schema = agentcore.ApiSchema.from_inline("""
    openapi: 3.0.3
    info:
      title: Library API
      version: 1.0.0
    paths:
      /search:
        get:
          summary: Search for books
          operationId: searchBooks
          parameters:
            - name: query
              in: query
              required: true
              schema:
                type: string
    """)
```

### Snippet 40 (ID: 23c2fae5...)

```python
bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/action-group.yaml")
```

### Snippet 41 (ID: 5fbfe426...)

```python
# Create a gateway first
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    )
)

# These ARNs are returned when creating the API key credential provider via Console or API
api_key_provider_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
api_key_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3my_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/myschema.yaml")

# Add an OpenAPI target directly to the gateway
target = gateway.add_open_api_target("MyTarget",
    gateway_target_name="my-api-target",
    description="Target for external API integration",
    api_schema=s3my_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.api_key(
            provider_arn=api_key_provider_arn,
            secret_arn=api_key_secret_arn,
            credential_location=agentcore.ApiKeyCredentialLocation.header(
                credential_parameter_name="X-API-Key"
            )
        )
    ]
)

# Add a Lambda target
lambda_function = lambda_.Function(self, "MyFunction",
    runtime=lambda_.Runtime.NODEJS_22_X,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
            exports.handler = async (event) => {
              return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Hello from Lambda!' })
              };
            };
          """)
)

lambda_target = gateway.add_lambda_target("MyLambdaTarget",
    gateway_target_name="my-lambda-target",
    description="Lambda function target",
    lambda_function=lambda_function,
    tool_schema=agentcore.ToolSchema.from_inline([
        name="hello_world",
        description="A simple hello world tool",
        input_schema=agentcoreLib.bedrock_agentcore.SchemaDefinition(
            type=agentcore.SchemaDefinitionType.OBJECT,
            properties={
                "name": agentcoreLib.bedrock_agentcore.SchemaDefinition(
                    type=agentcore.SchemaDefinitionType.STRING,
                    description="The name to greet"
                )
            },
            required=["name"]
        )

    ])
)

# Add a Smithy target
smithy_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/mymodel.json")
smithy_target = gateway.add_smithy_target("MySmithyTarget",
    gateway_target_name="my-smithy-target",
    description="Smithy model target",
    smithy_model=smithy_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.iam_role()
    ]
)
```

### Snippet 42 (ID: 3293480b...)

```python
# Create a gateway first
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway"
)

api_key_identity_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
api_key_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/myschema.yaml")

# Create a gateway target with OpenAPI Schema
open_apitarget = agentcore.GatewayTarget.for_open_api(self, "MyTarget",
    gateway_target_name="my-api-target",
    description="Target for external API integration",
    gateway=gateway,  # Note: you need to pass the gateway reference
    api_schema=s3_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.api_key(
            provider_arn=api_key_identity_arn,
            secret_arn=api_key_secret_arn,
            credential_location=agentcore.ApiKeyCredentialLocation.header(
                credential_parameter_name="X-API-Key"
            )
        )
    ]
)

# Create a Lambda function
lambda_function = lambda_.Function(self, "MyFunction",
    runtime=lambda_.Runtime.NODEJS_22_X,
    handler="index.handler",
    code=lambda_.Code.from_inline("""
                exports.handler = async (event) => {
                    return {
                        statusCode: 200,
                        body: JSON.stringify({ message: 'Hello from Lambda!' })
                    };
                };
            """)
)

# Create a gateway target with Lambda and tool schema
lambda_target = agentcore.GatewayTarget.for_lambda(self, "MyLambdaTarget",
    gateway_target_name="my-lambda-target",
    description="Target for Lambda function integration",
    gateway=gateway,
    lambda_function=lambda_function,
    tool_schema=agentcore.ToolSchema.from_inline([
        name="hello_world",
        description="A simple hello world tool",
        input_schema=agentcoreLib.bedrock_agentcore.SchemaDefinition(
            type=agentcore.SchemaDefinitionType.OBJECT,
            description="Input schema for hello world tool",
            properties={
                "name": agentcoreLib.bedrock_agentcore.SchemaDefinition(
                    type=agentcore.SchemaDefinitionType.STRING,
                    description="The name to greet"
                )
            },
            required=["name"]
        ),
        output_schema=agentcoreLib.bedrock_agentcore.SchemaDefinition(
            type=agentcore.SchemaDefinitionType.OBJECT,
            description="Output schema for hello world tool",
            properties={
                "message": agentcoreLib.bedrock_agentcore.SchemaDefinition(
                    type=agentcore.SchemaDefinitionType.STRING,
                    description="The greeting message"
                )
            }
        )

    ]),
    credential_provider_configurations=[agentcore.GatewayCredentialProvider.iam_role()]
)

# Create an OAuth identity
oauth_identity_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth123"
oauth_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

schema_bucket = s3.Bucket.from_bucket_name(self, "SchemaBucket", "my-schema-bucket")
s3_smithy_schema = agentcore.ApiSchema.from_s3_file(schema_bucket, "schemas/myschema.json")

# Create a gateway target with Smithy Model and OAuth
target = agentcore.GatewayTarget.for_smithy(self, "MySmithyTarget",
    gateway_target_name="my-smithy-target",
    description="Target for Smithy model integration",
    gateway=gateway,
    smithy_model=s3_smithy_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.oauth(
            provider_arn=oauth_identity_arn,
            secret_arn=oauth_secret_arn,
            scopes=["read", "write"],
            custom_parameters={
                "audience": "https://api.example.com",
                "response_type": "code"
            }
        )
    ]
)
```

### Snippet 43 (ID: 7d741b0e...)

```python
# Create a gateway and target
gateway = agentcore.Gateway(self, "MyGateway",
    gateway_name="my-gateway",
    protocol_configuration=agentcore.McpProtocolConfiguration(
        instructions="Use this gateway to connect to external MCP tools",
        search_type=agentcore.McpGatewaySearchType.SEMANTIC,
        supported_versions=[agentcore.MCPProtocolVersion.MCP_2025_03_26]
    ),
    authorizer_configuration=agentcore.GatewayAuthorizer.using_custom_jwt(
        discovery_url="https://auth.example.com/.well-known/openid-configuration",
        allowed_audience=["my-app"],
        allowed_clients=["my-client-id"]
    )
)

api_key_identity_arn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
api_key_secret_arn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket = s3.Bucket.from_bucket_name(self, "ExistingBucket", "my-schema-bucket")
s3api_schema = agentcore.ApiSchema.from_s3_file(bucket, "schemas/myschema.yaml")

target = agentcore.GatewayTarget.for_open_api(self, "MyTarget",
    gateway_target_name="my-target",
    gateway=gateway,
    api_schema=s3api_schema,
    credential_provider_configurations=[
        agentcore.GatewayCredentialProvider.api_key(
            provider_arn=api_key_identity_arn,
            secret_arn=api_key_secret_arn,
            credential_location=agentcore.ApiKeyCredentialLocation.header(
                credential_parameter_name="X-API-Key"
            )
        )
    ]
)

# Create a role that needs access to the gateway target
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
target.grant_read(user_role)

# Grant manage permissions (Create, Update, Delete actions)
target.grant_manage(user_role)

# Grant specific custom permissions
target.grant(user_role, "bedrock-agentcore:GetGatewayTarget")
```

### Snippet 44 (ID: fde53762...)

```python
# Create a basic code interpreter with public network access
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="A code interpreter for Python execution"
)
```

### Snippet 45 (ID: fd30da56...)

```python
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=ec2.Vpc(self, "VPC", restrict_default_security_group=False)
    )
)
```

### Snippet 46 (ID: 504a5940...)

```python
vpc = ec2.Vpc(self, "testVPC")

code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.BrowserNetworkConfiguration.using_vpc(self,
        vpc=vpc
    )
)

code_interpreter.connections.add_security_group(ec2.SecurityGroup(self, "AdditionalGroup", vpc=vpc))
```

### Snippet 47 (ID: aa6f2dda...)

```python
# Create code interpreter with sandbox network mode (isolated)
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_sandbox_network()
)
```

### Snippet 48 (ID: a7071766...)

```python
# Create a custom execution role
execution_role = iam.Role(self, "CodeInterpreterExecutionRole",
    assumed_by=iam.ServicePrincipal("bedrock-agentcore.amazonaws.com")
)

# Create code interpreter with custom execution role
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="Code interpreter with custom execution role",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network(),
    execution_role=execution_role
)
```

### Snippet 49 (ID: cedd86ae...)

```python
# Create a code interpreter
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_code_interpreter",
    description="Code interpreter for Python execution",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network()
)

# Create a role that needs access to the code interpreter
user_role = iam.Role(self, "UserRole",
    assumed_by=iam.ServicePrincipal("lambda.amazonaws.com")
)

# Grant read permissions (Get and List actions)
code_interpreter.grant_read(user_role)

# Grant use permissions (Start, Invoke, Stop actions)
code_interpreter.grant_use(user_role)

# Grant specific custom permissions
code_interpreter.grant(user_role, "bedrock-agentcore:GetCodeInterpreterSession")
```

### Snippet 50 (ID: 65a79060...)

```python
# Create code interpreter with sandbox network mode (isolated)
code_interpreter = agentcore.CodeInterpreterCustom(self, "MyCodeInterpreter",
    code_interpreter_custom_name="my_sandbox_interpreter",
    description="Code interpreter with isolated network access",
    network_configuration=agentcore.CodeInterpreterNetworkConfiguration.using_public_network(),
    tags={
        "Environment": "Production",
        "Team": "AI/ML",
        "Project": "AgentCore"
    }
)
```

### Snippet 51 (ID: cae11061...)

```python
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123"
```

### Snippet 52 (ID: 0471d468...)

```python
"runtime-abc123"
```

### Snippet 53 (ID: 6b4f6935...)

```python
"2024-01-15T10:30:00Z"
```

### Snippet 54 (ID: 379fc387...)

```python
"2024-01-15T14:45:00Z"
```

### Snippet 55 (ID: 7e85b1e8...)

```python
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123"
```

---

## Java

**55 snippet(s) available**

### Snippet 1 (ID: 51c2184c...)

```java
// Create a new API key identity
String apiKeyIdentityArn = "your-api-key-arn";
```

### Snippet 2 (ID: 6c86e96d...)

```java
String oauthIdentityArn = "oauth-idp-arn";
```

### Snippet 3 (ID: 50e9623f...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();

// The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create runtime using the built image
Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .build();
```

### Snippet 4 (ID: bd4fbd33...)

```java
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromAsset(path.join(__dirname, "path to agent dockerfile directory"));

Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .build();
```

### Snippet 5 (ID: 837f5f72...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();

//Initial Deployment - Automatically creates Version 1
Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0"))
        .build();
// At this point: A DEFAULT endpoint is created which points to version 1

// You can create a new endpoint (production) which points to version1
RuntimeEndpoint prodEndpoint = runtime.addEndpoint("production", AddEndpointOptions.builder()
        .version("1")
        .description("Stable production endpoint - pinned to v1")
        .build());

// When you update the runtime configuration e.g. new container image, protocol change, network settings
// a new version (Version 2) is automatically created

// After update: Version 2 is created automatically
// DEFAULT endpoint automatically updates to Version 2
// Production endpoint remains on Version 1 (explicitly pinned)

// Now that Version 2 exists, create a staging endpoint for testing
RuntimeEndpoint stagingEndpoint = runtime.addEndpoint("staging", AddEndpointOptions.builder()
        .version("2")
        .description("Staging environment for testing new version")
        .build());
```

### Snippet 6 (ID: 97a9a76c...)

```java
// Reference an existing runtime by its ID
String existingRuntimeId = "abc123-runtime-id"; // The ID of an existing runtime

// Create a standalone endpoint
RuntimeEndpoint endpoint = RuntimeEndpoint.Builder.create(this, "MyEndpoint")
        .endpointName("production")
        .agentRuntimeId(existingRuntimeId)
        .agentRuntimeVersion("1") // Specify which version to use
        .description("Production endpoint for existing runtime")
        .build();
```

### Snippet 7 (ID: d4ae6d28...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .authorizerConfiguration(agentcore.RuntimeAuthorizerConfiguration.usingCognito("us-west-2_ABC123", "client123", "us-west-2"))
        .build();
```

### Snippet 8 (ID: 8bced5c5...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .authorizerConfiguration(agentcore.RuntimeAuthorizerConfiguration.usingJWT("https://example.com/.well-known/openid-configuration", List.of("client1", "client2"), List.of("audience1")))
        .build();
```

### Snippet 9 (ID: 2271afce...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .authorizerConfiguration(agentcore.RuntimeAuthorizerConfiguration.usingOAuth("https://github.com/.well-known/openid-configuration", "oauth_client_123"))
        .build();
```

### Snippet 10 (ID: b84b740e...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Explicitly using public network (this is the default)
Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .networkConfiguration(agentcore.RuntimeNetworkConfiguration.usingPublicNetwork())
        .build();
```

### Snippet 11 (ID: b72e3ac0...)

```java
Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create or use an existing VPC
Vpc vpc = Vpc.Builder.create(this, "MyVpc")
        .maxAzs(2)
        .build();

// Configure runtime with VPC
Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .networkConfiguration(agentcore.RuntimeNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(vpc)
                .vpcSubnets(SubnetSelection.builder().subnetType(SubnetType.PRIVATE_WITH_EGRESS).build())
                .build()))
        .build();
```

### Snippet 12 (ID: 545b0fa6...)

```java
Vpc vpc = Vpc.Builder.create(this, "MyVpc")
        .maxAzs(2)
        .build();

Repository repository = Repository.Builder.create(this, "TestRepository")
        .repositoryName("test-agent-runtime")
        .build();
AgentRuntimeArtifact agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.fromEcrRepository(repository, "v1.0.0");

// Create runtime with VPC configuration
Runtime runtime = Runtime.Builder.create(this, "MyAgentRuntime")
        .runtimeName("myAgent")
        .agentRuntimeArtifact(agentRuntimeArtifact)
        .networkConfiguration(agentcore.RuntimeNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(vpc)
                .vpcSubnets(SubnetSelection.builder().subnetType(SubnetType.PRIVATE_WITH_EGRESS).build())
                .build()))
        .build();

// Now you can manage network access using the connections property
// Allow inbound HTTPS traffic from a specific security group
SecurityGroup webServerSecurityGroup = SecurityGroup.Builder.create(this, "WebServerSG").vpc(vpc).build();
runtime.connections.allowFrom(webServerSecurityGroup, Port.tcp(443), "Allow HTTPS from web servers");

// Allow outbound connections to a database
SecurityGroup databaseSecurityGroup = SecurityGroup.Builder.create(this, "DatabaseSG").vpc(vpc).build();
runtime.connections.allowTo(databaseSecurityGroup, Port.tcp(5432), "Allow PostgreSQL connection");

// Allow outbound HTTPS to anywhere (for external API calls)
runtime.connections.allowToAnyIpv4(Port.tcp(443), "Allow HTTPS outbound");
```

### Snippet 13 (ID: 920d31a1...)

```java
// Create a basic memory with default settings, no LTM strategies
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my_memory")
        .description("A memory for storing user interactions for a period of 90 days")
        .expirationDuration(Duration.days(90))
        .build();
```

### Snippet 14 (ID: de9dfac6...)

```java
// Create a custom KMS key for encryption
Key encryptionKey = Key.Builder.create(this, "MemoryEncryptionKey")
        .enableKeyRotation(true)
        .description("KMS key for memory encryption")
        .build();

// Create memory with custom encryption
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my_encrypted_memory")
        .description("Memory with custom KMS encryption")
        .expirationDuration(Duration.days(90))
        .kmsKey(encryptionKey)
        .build();
```

### Snippet 15 (ID: b638db3f...)

```java
// Create memory with built-in strategies
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my_memory")
        .description("Memory with built-in strategies")
        .expirationDuration(Duration.days(90))
        .memoryStrategies(List.of(agentcore.MemoryStrategy.usingBuiltInSummarization(), agentcore.MemoryStrategy.usingBuiltInSemantic(), agentcore.MemoryStrategy.usingBuiltInUserPreference()))
        .build();
```

### Snippet 16 (ID: c943056b...)

```java
// Create memory with built-in strategies
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my_memory")
        .description("Memory with built-in strategies")
        .expirationDuration(Duration.days(90))
        .memoryStrategies(List.of(agentcore.MemoryStrategy.usingUserPreference(MemoryStrategyCommonProps.builder()
                .name("CustomerPreferences")
                .namespaces(List.of("support/customer/{actorId}/preferences"))
                .build()), agentcore.MemoryStrategy.usingSemantic(MemoryStrategyCommonProps.builder()
                .name("CustomerSupportSemantic")
                .namespaces(List.of("support/customer/{actorId}/semantic"))
                .build())))
        .build();
```

### Snippet 17 (ID: 3b589e6a...)

```java
// Create a custom execution role
Role executionRole = Role.Builder.create(this, "MemoryExecutionRole")
        .assumedBy(new ServicePrincipal("bedrock-agentcore.amazonaws.com"))
        .managedPolicies(List.of(ManagedPolicy.fromAwsManagedPolicyName("AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy")))
        .build();

// Create memory with custom execution role
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my_memory")
        .description("Memory with custom execution role")
        .expirationDuration(Duration.days(90))
        .build();
```

### Snippet 18 (ID: 853451ae...)

```java
// Create a custom semantic memory strategy
OverrideMemoryStrategy customSemanticStrategy = agentcore.MemoryStrategy.usingSemanticOverride(OverrideStrategyProps.builder()
        .name("customSemanticStrategy")
        .description("Custom semantic memory strategy")
        .namespaces(List.of("/custom/strategies/{memoryStrategyId}/actors/{actorId}"))
        .customConsolidation(OverrideConfig.builder()
                .model(BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0)
                .appendToPrompt("Custom consolidation prompt for semantic memory")
                .build())
        .customExtraction(OverrideConfig.builder()
                .model(BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0)
                .appendToPrompt("Custom extraction prompt for semantic memory")
                .build())
        .build());

// Create memory with custom strategy
Memory memory = Memory.Builder.create(this, "MyMemory")
        .memoryName("my-custom-memory")
        .description("Memory with custom strategy")
        .expirationDuration(Duration.days(90))
        .memoryStrategies(List.of(customSemanticStrategy))
        .build();
```

### Snippet 19 (ID: aa0231c9...)

```java
// Create memory without initial strategies
Memory memory = Memory.Builder.create(this, "test-memory")
        .memoryName("test_memory_add_strategy")
        .description("A test memory for testing addMemoryStrategy method")
        .expirationDuration(Duration.days(90))
        .build();

// Add strategies after instantiation
memory.addMemoryStrategy(agentcore.MemoryStrategy.usingBuiltInSummarization());
memory.addMemoryStrategy(agentcore.MemoryStrategy.usingBuiltInSemantic());
```

### Snippet 20 (ID: aef59cfa...)

```java
// Create a basic browser with public network access
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("A browser for web automation")
        .build();
```

### Snippet 21 (ID: 15980722...)

```java
// Create a browser with custom tags
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("A browser for web automation with tags")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingPublicNetwork())
        .tags(Map.of(
                "Environment", "Production",
                "Team", "AI/ML",
                "Project", "AgentCore"))
        .build();
```

### Snippet 22 (ID: 5db8ac38...)

```java
BrowserCustom browser = BrowserCustom.Builder.create(this, "BrowserVpcWithRecording")
        .browserCustomName("browser_recording")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(Vpc.Builder.create(this, "VPC").restrictDefaultSecurityGroup(false).build())
                .build()))
        .build();
```

### Snippet 23 (ID: 3611091a...)

```java
Vpc vpc = new Vpc(this, "testVPC");

BrowserCustom browser = BrowserCustom.Builder.create(this, "test-browser")
        .browserCustomName("test_browser")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(vpc)
                .build()))
        .build();

browser.connections.addSecurityGroup(SecurityGroup.Builder.create(this, "AdditionalGroup").vpc(vpc).build());
```

### Snippet 24 (ID: 5177993c...)

```java
// Create an S3 bucket for recordings
Bucket recordingBucket = Bucket.Builder.create(this, "RecordingBucket")
        .bucketName("my-browser-recordings")
        .removalPolicy(RemovalPolicy.DESTROY)
        .build();

// Create browser with recording enabled
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("Browser with recording enabled")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingPublicNetwork())
        .recordingConfig(RecordingConfig.builder()
                .enabled(true)
                .s3Location(Location.builder()
                        .bucketName(recordingBucket.getBucketName())
                        .objectKey("browser-recordings/")
                        .build())
                .build())
        .build();
```

### Snippet 25 (ID: 27976676...)

```java
// Create a custom execution role
Role executionRole = Role.Builder.create(this, "BrowserExecutionRole")
        .assumedBy(new ServicePrincipal("bedrock-agentcore.amazonaws.com"))
        .managedPolicies(List.of(ManagedPolicy.fromAwsManagedPolicyName("AmazonBedrockAgentCoreBrowserExecutionRolePolicy")))
        .build();

// Create browser with custom execution role
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("Browser with custom execution role")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingPublicNetwork())
        .executionRole(executionRole)
        .build();
```

### Snippet 26 (ID: ac3e1e5e...)

```java
// Create an S3 bucket for recordings
Bucket recordingBucket = Bucket.Builder.create(this, "RecordingBucket")
        .bucketName("my-browser-recordings")
        .removalPolicy(RemovalPolicy.DESTROY)
        .build();

// Create browser with recording enabled
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("Browser with recording enabled")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingPublicNetwork())
        .recordingConfig(RecordingConfig.builder()
                .enabled(true)
                .s3Location(Location.builder()
                        .bucketName(recordingBucket.getBucketName())
                        .objectKey("browser-recordings/")
                        .build())
                .build())
        .build();
```

### Snippet 27 (ID: 444b170b...)

```java
// Create a browser
BrowserCustom browser = BrowserCustom.Builder.create(this, "MyBrowser")
        .browserCustomName("my_browser")
        .description("Browser for web automation")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingPublicNetwork())
        .build();

// Create a role that needs access to the browser
Role userRole = Role.Builder.create(this, "UserRole")
        .assumedBy(new ServicePrincipal("lambda.amazonaws.com"))
        .build();

// Grant read permissions (Get and List actions)
browser.grantRead(userRole);

// Grant use permissions (Start, Update, Stop actions)
browser.grantUse(userRole);

// Grant specific custom permissions
browser.grant(userRole, "bedrock-agentcore:GetBrowserSession");
```

### Snippet 28 (ID: a016e911...)

```java
// Create a basic gateway with default MCP protocol and Cognito authorizer
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .build();
```

### Snippet 29 (ID: cddccfcc...)

```java
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .build();
```

### Snippet 30 (ID: 2cf05827...)

```java
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .build();
```

### Snippet 31 (ID: cdfb1cbb...)

```java
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .authorizerConfiguration(agentcore.getGatewayAuthorizer().getAwsIam())
        .build();

// Grant access to a Lambda function's role
Role lambdaRole = Role.Builder.create(this, "LambdaRole")
        .assumedBy(new ServicePrincipal("lambda.amazonaws.com"))
        .build();

// The Lambda needs permission to invoke the gateway
gateway.grantInvoke(lambdaRole);
```

### Snippet 32 (ID: 1b96e6d2...)

```java
// Create a KMS key for encryption
Key encryptionKey = Key.Builder.create(this, "GatewayEncryptionKey")
        .enableKeyRotation(true)
        .description("KMS key for gateway encryption")
        .build();

// Create gateway with KMS encryption
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-encrypted-gateway")
        .description("Gateway with KMS encryption")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .kmsKey(encryptionKey)
        .exceptionLevel(agentcore.getGatewayExceptionLevel().DEBUG)
        .build();
```

### Snippet 33 (ID: 2fae250c...)

```java
// Create a custom execution role
Role executionRole = Role.Builder.create(this, "GatewayExecutionRole")
        .assumedBy(new ServicePrincipal("bedrock-agentcore.amazonaws.com"))
        .managedPolicies(List.of(ManagedPolicy.fromAwsManagedPolicyName("AmazonBedrockAgentCoreGatewayExecutionRolePolicy")))
        .build();

// Create gateway with custom execution role
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .description("Gateway with custom execution role")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .role(executionRole)
        .build();
```

### Snippet 34 (ID: a47f4a02...)

```java
// Create a gateway
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .description("Gateway for external service integration")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .build();

// Create a role that needs access to the gateway
Role userRole = Role.Builder.create(this, "UserRole")
        .assumedBy(new ServicePrincipal("lambda.amazonaws.com"))
        .build();

// Grant read permissions (Get and List actions)
gateway.grantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
gateway.grantManage(userRole);

// Grant specific custom permissions
gateway.grant(userRole, "bedrock-agentcore:GetGateway");
```

### Snippet 35 (ID: 52d6584e...)

```java
ToolSchema toolSchema = agentcore.ToolSchema.fromLocalAsset(path.join(__dirname, "schemas", "my-tool-schema.json"));
```

### Snippet 36 (ID: 14041e87...)

```java
S3ToolSchema toolSchema = agentcore.ToolSchema.fromS3File(Bucket.fromBucketName(this, "SchemasBucket", "my-schemas-bucket"), "tools/complex-tool-schema.json", "123456789012");
```

### Snippet 37 (ID: 11b5c8ff...)

```java
InlineToolSchema toolSchema = agentcore.ToolSchema.fromInline(List.of(ToolDefinition.builder()
        .name("hello_world")
        .description("A simple hello world tool")
        .inputSchema(SchemaDefinition.builder()
                .type(agentcore.getSchemaDefinitionType().OBJECT)
                .properties(Map.of(
                        "name", SchemaDefinition.builder()
                                .type(agentcore.getSchemaDefinitionType().STRING)
                                .description("The name to greet")
                                .build()))
                .required(List.of("name"))
                .build())
        .build()));
```

### Snippet 38 (ID: bf7d63e6...)

```java
// When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
AssetApiSchema schema = agentcore.ApiSchema.fromLocalAsset(path.join(__dirname, "mySchema.yml"));
schema.bind(this);
```

### Snippet 39 (ID: dad78422...)

```java
InlineApiSchema inlineSchema = agentcore.ApiSchema.fromInline("\nopenapi: 3.0.3\ninfo:\n  title: Library API\n  version: 1.0.0\npaths:\n  /search:\n    get:\n      summary: Search for books\n      operationId: searchBooks\n      parameters:\n        - name: query\n          in: query\n          required: true\n          schema:\n            type: string\n");
```

### Snippet 40 (ID: 23c2fae5...)

```java
IBucket bucket = Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
S3ApiSchema s3Schema = agentcore.ApiSchema.fromS3File(bucket, "schemas/action-group.yaml");
```

### Snippet 41 (ID: 5fbfe426...)

```java
// Create a gateway first
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .build();

// These ARNs are returned when creating the API key credential provider via Console or API
String apiKeyProviderArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
String apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

IBucket bucket = Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
S3ApiSchema s3mySchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

// Add an OpenAPI target directly to the gateway
GatewayTarget target = gateway.addOpenApiTarget("MyTarget", AddOpenApiTargetOptions.builder()
        .gatewayTargetName("my-api-target")
        .description("Target for external API integration")
        .apiSchema(s3mySchema)
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.apiKey(ApiKeyCredentialProviderProps.builder()
                .providerArn(apiKeyProviderArn)
                .secretArn(apiKeySecretArn)
                .credentialLocation(agentcore.ApiKeyCredentialLocation.header(ApiKeyAdditionalConfiguration.builder()
                        .credentialParameterName("X-API-Key")
                        .build()))
                .build())))
        .build());

// Add a Lambda target
Function lambdaFunction = Function.Builder.create(this, "MyFunction")
        .runtime(Runtime.NODEJS_22_X)
        .handler("index.handler")
        .code(Code.fromInline("\n    exports.handler = async (event) => {\n      return {\n        statusCode: 200,\n        body: JSON.stringify({ message: 'Hello from Lambda!' })\n      };\n    };\n  "))
        .build();

GatewayTarget lambdaTarget = gateway.addLambdaTarget("MyLambdaTarget", AddLambdaTargetOptions.builder()
        .gatewayTargetName("my-lambda-target")
        .description("Lambda function target")
        .lambdaFunction(lambdaFunction)
        .toolSchema(agentcore.ToolSchema.fromInline(List.of(ToolDefinition.builder()
                .name("hello_world")
                .description("A simple hello world tool")
                .inputSchema(SchemaDefinition.builder()
                        .type(agentcore.getSchemaDefinitionType().OBJECT)
                        .properties(Map.of(
                                "name", SchemaDefinition.builder()
                                        .type(agentcore.getSchemaDefinitionType().STRING)
                                        .description("The name to greet")
                                        .build()))
                        .required(List.of("name"))
                        .build())
                .build())))
        .build());

// Add a Smithy target
S3ApiSchema smithySchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/mymodel.json");
GatewayTarget smithyTarget = gateway.addSmithyTarget("MySmithyTarget", AddSmithyTargetOptions.builder()
        .gatewayTargetName("my-smithy-target")
        .description("Smithy model target")
        .smithyModel(smithySchema)
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.iamRole()))
        .build());
```

### Snippet 42 (ID: 3293480b...)

```java
// Create a gateway first
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .build();

String apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
String apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

IBucket bucket = Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
S3ApiSchema s3Schema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

// Create a gateway target with OpenAPI Schema
GatewayTarget openApitarget = agentcore.GatewayTarget.forOpenApi(this, "MyTarget", GatewayTargetOpenApiProps.builder()
        .gatewayTargetName("my-api-target")
        .description("Target for external API integration")
        .gateway(gateway) // Note: you need to pass the gateway reference
        .apiSchema(s3Schema)
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.apiKey(ApiKeyCredentialProviderProps.builder()
                .providerArn(apiKeyIdentityArn)
                .secretArn(apiKeySecretArn)
                .credentialLocation(agentcore.ApiKeyCredentialLocation.header(ApiKeyAdditionalConfiguration.builder()
                        .credentialParameterName("X-API-Key")
                        .build()))
                .build())))
        .build());

// Create a Lambda function
Function lambdaFunction = Function.Builder.create(this, "MyFunction")
        .runtime(Runtime.NODEJS_22_X)
        .handler("index.handler")
        .code(Code.fromInline("\n        exports.handler = async (event) => {\n            return {\n                statusCode: 200,\n                body: JSON.stringify({ message: 'Hello from Lambda!' })\n            };\n        };\n    "))
        .build();

// Create a gateway target with Lambda and tool schema
GatewayTarget lambdaTarget = agentcore.GatewayTarget.forLambda(this, "MyLambdaTarget", GatewayTargetLambdaProps.builder()
        .gatewayTargetName("my-lambda-target")
        .description("Target for Lambda function integration")
        .gateway(gateway)
        .lambdaFunction(lambdaFunction)
        .toolSchema(agentcore.ToolSchema.fromInline(List.of(ToolDefinition.builder()
                .name("hello_world")
                .description("A simple hello world tool")
                .inputSchema(SchemaDefinition.builder()
                        .type(agentcore.getSchemaDefinitionType().OBJECT)
                        .description("Input schema for hello world tool")
                        .properties(Map.of(
                                "name", SchemaDefinition.builder()
                                        .type(agentcore.getSchemaDefinitionType().STRING)
                                        .description("The name to greet")
                                        .build()))
                        .required(List.of("name"))
                        .build())
                .outputSchema(SchemaDefinition.builder()
                        .type(agentcore.getSchemaDefinitionType().OBJECT)
                        .description("Output schema for hello world tool")
                        .properties(Map.of(
                                "message", SchemaDefinition.builder()
                                        .type(agentcore.getSchemaDefinitionType().STRING)
                                        .description("The greeting message")
                                        .build()))
                        .build())
                .build())))
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.iamRole()))
        .build());

// Create an OAuth identity
String oauthIdentityArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth123";
String oauthSecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

IBucket schemaBucket = Bucket.fromBucketName(this, "SchemaBucket", "my-schema-bucket");
S3ApiSchema s3SmithySchema = agentcore.ApiSchema.fromS3File(schemaBucket, "schemas/myschema.json");

// Create a gateway target with Smithy Model and OAuth
GatewayTarget target = agentcore.GatewayTarget.forSmithy(this, "MySmithyTarget", GatewayTargetSmithyProps.builder()
        .gatewayTargetName("my-smithy-target")
        .description("Target for Smithy model integration")
        .gateway(gateway)
        .smithyModel(s3SmithySchema)
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.oauth(OAuthConfiguration.builder()
                .providerArn(oauthIdentityArn)
                .secretArn(oauthSecretArn)
                .scopes(List.of("read", "write"))
                .customParameters(Map.of(
                        "audience", "https://api.example.com",
                        "response_type", "code"))
                .build())))
        .build());
```

### Snippet 43 (ID: 7d741b0e...)

```java
// Create a gateway and target
Gateway gateway = Gateway.Builder.create(this, "MyGateway")
        .gatewayName("my-gateway")
        .protocolConfiguration(McpProtocolConfiguration.Builder.create()
                .instructions("Use this gateway to connect to external MCP tools")
                .searchType(agentcore.getMcpGatewaySearchType().SEMANTIC)
                .supportedVersions(List.of(agentcore.getMCPProtocolVersion().MCP_2025_03_26))
                .build())
        .authorizerConfiguration(agentcore.GatewayAuthorizer.usingCustomJwt(CustomJwtConfiguration.builder()
                .discoveryUrl("https://auth.example.com/.well-known/openid-configuration")
                .allowedAudience(List.of("my-app"))
                .allowedClients(List.of("my-client-id"))
                .build()))
        .build();

String apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
String apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

IBucket bucket = Bucket.fromBucketName(this, "ExistingBucket", "my-schema-bucket");
S3ApiSchema s3apiSchema = agentcore.ApiSchema.fromS3File(bucket, "schemas/myschema.yaml");

GatewayTarget target = agentcore.GatewayTarget.forOpenApi(this, "MyTarget", GatewayTargetOpenApiProps.builder()
        .gatewayTargetName("my-target")
        .gateway(gateway)
        .apiSchema(s3apiSchema)
        .credentialProviderConfigurations(List.of(agentcore.GatewayCredentialProvider.apiKey(ApiKeyCredentialProviderProps.builder()
                .providerArn(apiKeyIdentityArn)
                .secretArn(apiKeySecretArn)
                .credentialLocation(agentcore.ApiKeyCredentialLocation.header(ApiKeyAdditionalConfiguration.builder()
                        .credentialParameterName("X-API-Key")
                        .build()))
                .build())))
        .build());

// Create a role that needs access to the gateway target
Role userRole = Role.Builder.create(this, "UserRole")
        .assumedBy(new ServicePrincipal("lambda.amazonaws.com"))
        .build();

// Grant read permissions (Get and List actions)
target.grantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
target.grantManage(userRole);

// Grant specific custom permissions
target.grant(userRole, "bedrock-agentcore:GetGatewayTarget");
```

### Snippet 44 (ID: fde53762...)

```java
// Create a basic code interpreter with public network access
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_code_interpreter")
        .description("A code interpreter for Python execution")
        .build();
```

### Snippet 45 (ID: fd30da56...)

```java
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_sandbox_interpreter")
        .description("Code interpreter with isolated network access")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(Vpc.Builder.create(this, "VPC").restrictDefaultSecurityGroup(false).build())
                .build()))
        .build();
```

### Snippet 46 (ID: 504a5940...)

```java
Vpc vpc = new Vpc(this, "testVPC");

CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_sandbox_interpreter")
        .description("Code interpreter with isolated network access")
        .networkConfiguration(agentcore.BrowserNetworkConfiguration.usingVpc(this, VpcConfigProps.builder()
                .vpc(vpc)
                .build()))
        .build();

codeInterpreter.connections.addSecurityGroup(SecurityGroup.Builder.create(this, "AdditionalGroup").vpc(vpc).build());
```

### Snippet 47 (ID: aa6f2dda...)

```java
// Create code interpreter with sandbox network mode (isolated)
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_sandbox_interpreter")
        .description("Code interpreter with isolated network access")
        .networkConfiguration(agentcore.CodeInterpreterNetworkConfiguration.usingSandboxNetwork())
        .build();
```

### Snippet 48 (ID: a7071766...)

```java
// Create a custom execution role
Role executionRole = Role.Builder.create(this, "CodeInterpreterExecutionRole")
        .assumedBy(new ServicePrincipal("bedrock-agentcore.amazonaws.com"))
        .build();

// Create code interpreter with custom execution role
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_code_interpreter")
        .description("Code interpreter with custom execution role")
        .networkConfiguration(agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork())
        .executionRole(executionRole)
        .build();
```

### Snippet 49 (ID: cedd86ae...)

```java
// Create a code interpreter
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_code_interpreter")
        .description("Code interpreter for Python execution")
        .networkConfiguration(agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork())
        .build();

// Create a role that needs access to the code interpreter
Role userRole = Role.Builder.create(this, "UserRole")
        .assumedBy(new ServicePrincipal("lambda.amazonaws.com"))
        .build();

// Grant read permissions (Get and List actions)
codeInterpreter.grantRead(userRole);

// Grant use permissions (Start, Invoke, Stop actions)
codeInterpreter.grantUse(userRole);

// Grant specific custom permissions
codeInterpreter.grant(userRole, "bedrock-agentcore:GetCodeInterpreterSession");
```

### Snippet 50 (ID: 65a79060...)

```java
// Create code interpreter with sandbox network mode (isolated)
CodeInterpreterCustom codeInterpreter = CodeInterpreterCustom.Builder.create(this, "MyCodeInterpreter")
        .codeInterpreterCustomName("my_sandbox_interpreter")
        .description("Code interpreter with isolated network access")
        .networkConfiguration(agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork())
        .tags(Map.of(
                "Environment", "Production",
                "Team", "AI/ML",
                "Project", "AgentCore"))
        .build();
```

### Snippet 51 (ID: cae11061...)

```java
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123";
```

### Snippet 52 (ID: 0471d468...)

```java
"runtime-abc123";
```

### Snippet 53 (ID: 6b4f6935...)

```java
"2024-01-15T10:30:00Z";
```

### Snippet 54 (ID: 379fc387...)

```java
"2024-01-15T14:45:00Z";
```

### Snippet 55 (ID: 7e85b1e8...)

```java
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123";
```

---

## Csharp

**55 snippet(s) available**

### Snippet 1 (ID: 51c2184c...)

```csharp
// Create a new API key identity
var apiKeyIdentityArn = "your-api-key-arn";
```

### Snippet 2 (ID: 6c86e96d...)

```csharp
var oauthIdentityArn = "oauth-idp-arn";
```

### Snippet 3 (ID: 50e9623f...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});

// The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

// Create runtime using the built image
var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact
});
```

### Snippet 4 (ID: bd4fbd33...)

```csharp
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromAsset(path.Join(__dirname, "path to agent dockerfile directory"));

var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact
});
```

### Snippet 5 (ID: 837f5f72...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});

//Initial Deployment - Automatically creates Version 1
var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0")
});
// At this point: A DEFAULT endpoint is created which points to version 1

// You can create a new endpoint (production) which points to version1
var prodEndpoint = runtime.AddEndpoint("production", new AddEndpointOptions {
    Version = "1",
    Description = "Stable production endpoint - pinned to v1"
});

// When you update the runtime configuration e.g. new container image, protocol change, network settings
// a new version (Version 2) is automatically created

// After update: Version 2 is created automatically
// DEFAULT endpoint automatically updates to Version 2
// Production endpoint remains on Version 1 (explicitly pinned)

// Now that Version 2 exists, create a staging endpoint for testing
var stagingEndpoint = runtime.AddEndpoint("staging", new AddEndpointOptions {
    Version = "2",
    Description = "Staging environment for testing new version"
});
```

### Snippet 6 (ID: 97a9a76c...)

```csharp
// Reference an existing runtime by its ID
var existingRuntimeId = "abc123-runtime-id"; // The ID of an existing runtime

// Create a standalone endpoint
var endpoint = new agentcore.RuntimeEndpoint(this, "MyEndpoint", new RuntimeEndpointProps {
    EndpointName = "production",
    AgentRuntimeId = existingRuntimeId,
    AgentRuntimeVersion = "1",  // Specify which version to use
    Description = "Production endpoint for existing runtime"
});
```

### Snippet 7 (ID: d4ae6d28...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    AuthorizerConfiguration = agentcore.RuntimeAuthorizerConfiguration.UsingCognito("us-west-2_ABC123", "client123", "us-west-2")
});
```

### Snippet 8 (ID: 8bced5c5...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    AuthorizerConfiguration = agentcore.RuntimeAuthorizerConfiguration.UsingJWT("https://example.com/.well-known/openid-configuration", new [] { "client1", "client2" }, new [] { "audience1" })
});
```

### Snippet 9 (ID: 2271afce...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    AuthorizerConfiguration = agentcore.RuntimeAuthorizerConfiguration.UsingOAuth("https://github.com/.well-known/openid-configuration", "oauth_client_123")
});
```

### Snippet 10 (ID: b84b740e...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

// Explicitly using public network (this is the default)
var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    NetworkConfiguration = agentcore.RuntimeNetworkConfiguration.UsingPublicNetwork()
});
```

### Snippet 11 (ID: b72e3ac0...)

```csharp
var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

// Create or use an existing VPC
var vpc = new Vpc(this, "MyVpc", new VpcProps {
    MaxAzs = 2
});

// Configure runtime with VPC
var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    NetworkConfiguration = agentcore.RuntimeNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = vpc,
        VpcSubnets = new SubnetSelection { SubnetType = SubnetType.PRIVATE_WITH_EGRESS }
    })
});
```

### Snippet 12 (ID: 545b0fa6...)

```csharp
var vpc = new Vpc(this, "MyVpc", new VpcProps {
    MaxAzs = 2
});

var repository = new Repository(this, "TestRepository", new RepositoryProps {
    RepositoryName = "test-agent-runtime"
});
var agentRuntimeArtifact = agentcore.AgentRuntimeArtifact.FromEcrRepository(repository, "v1.0.0");

// Create runtime with VPC configuration
var runtime = new agentcore.Runtime(this, "MyAgentRuntime", new RuntimeProps {
    RuntimeName = "myAgent",
    AgentRuntimeArtifact = agentRuntimeArtifact,
    NetworkConfiguration = agentcore.RuntimeNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = vpc,
        VpcSubnets = new SubnetSelection { SubnetType = SubnetType.PRIVATE_WITH_EGRESS }
    })
});

// Now you can manage network access using the connections property
// Allow inbound HTTPS traffic from a specific security group
var webServerSecurityGroup = new SecurityGroup(this, "WebServerSG", new SecurityGroupProps { Vpc = vpc });
runtime.Connections.AllowFrom(webServerSecurityGroup, Port.Tcp(443), "Allow HTTPS from web servers");

// Allow outbound connections to a database
var databaseSecurityGroup = new SecurityGroup(this, "DatabaseSG", new SecurityGroupProps { Vpc = vpc });
runtime.Connections.AllowTo(databaseSecurityGroup, Port.Tcp(5432), "Allow PostgreSQL connection");

// Allow outbound HTTPS to anywhere (for external API calls)
runtime.Connections.AllowToAnyIpv4(Port.Tcp(443), "Allow HTTPS outbound");
```

### Snippet 13 (ID: 920d31a1...)

```csharp
// Create a basic memory with default settings, no LTM strategies
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my_memory",
    Description = "A memory for storing user interactions for a period of 90 days",
    ExpirationDuration = Duration.Days(90)
});
```

### Snippet 14 (ID: de9dfac6...)

```csharp
// Create a custom KMS key for encryption
var encryptionKey = new Key(this, "MemoryEncryptionKey", new KeyProps {
    EnableKeyRotation = true,
    Description = "KMS key for memory encryption"
});

// Create memory with custom encryption
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my_encrypted_memory",
    Description = "Memory with custom KMS encryption",
    ExpirationDuration = Duration.Days(90),
    KmsKey = encryptionKey
});
```

### Snippet 15 (ID: b638db3f...)

```csharp
// Create memory with built-in strategies
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my_memory",
    Description = "Memory with built-in strategies",
    ExpirationDuration = Duration.Days(90),
    MemoryStrategies = new [] { agentcore.MemoryStrategy.UsingBuiltInSummarization(), agentcore.MemoryStrategy.UsingBuiltInSemantic(), agentcore.MemoryStrategy.UsingBuiltInUserPreference() }
});
```

### Snippet 16 (ID: c943056b...)

```csharp
// Create memory with built-in strategies
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my_memory",
    Description = "Memory with built-in strategies",
    ExpirationDuration = Duration.Days(90),
    MemoryStrategies = new [] { agentcore.MemoryStrategy.UsingUserPreference(new MemoryStrategyCommonProps {
        Name = "CustomerPreferences",
        Namespaces = new [] { "support/customer/{actorId}/preferences" }
    }), agentcore.MemoryStrategy.UsingSemantic(new MemoryStrategyCommonProps {
        Name = "CustomerSupportSemantic",
        Namespaces = new [] { "support/customer/{actorId}/semantic" }
    }) }
});
```

### Snippet 17 (ID: 3b589e6a...)

```csharp
// Create a custom execution role
var executionRole = new Role(this, "MemoryExecutionRole", new RoleProps {
    AssumedBy = new ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    ManagedPolicies = new [] { ManagedPolicy.FromAwsManagedPolicyName("AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy") }
});

// Create memory with custom execution role
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my_memory",
    Description = "Memory with custom execution role",
    ExpirationDuration = Duration.Days(90)
});
```

### Snippet 18 (ID: 853451ae...)

```csharp
// Create a custom semantic memory strategy
var customSemanticStrategy = agentcore.MemoryStrategy.UsingSemanticOverride(new OverrideStrategyProps {
    Name = "customSemanticStrategy",
    Description = "Custom semantic memory strategy",
    Namespaces = new [] { "/custom/strategies/{memoryStrategyId}/actors/{actorId}" },
    CustomConsolidation = new OverrideConfig {
        Model = BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        AppendToPrompt = "Custom consolidation prompt for semantic memory"
    },
    CustomExtraction = new OverrideConfig {
        Model = BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        AppendToPrompt = "Custom extraction prompt for semantic memory"
    }
});

// Create memory with custom strategy
var memory = new agentcore.Memory(this, "MyMemory", new MemoryProps {
    MemoryName = "my-custom-memory",
    Description = "Memory with custom strategy",
    ExpirationDuration = Duration.Days(90),
    MemoryStrategies = new [] { customSemanticStrategy }
});
```

### Snippet 19 (ID: aa0231c9...)

```csharp
// Create memory without initial strategies
var memory = new agentcore.Memory(this, "test-memory", new MemoryProps {
    MemoryName = "test_memory_add_strategy",
    Description = "A test memory for testing addMemoryStrategy method",
    ExpirationDuration = Duration.Days(90)
});

// Add strategies after instantiation
memory.AddMemoryStrategy(agentcore.MemoryStrategy.UsingBuiltInSummarization());
memory.AddMemoryStrategy(agentcore.MemoryStrategy.UsingBuiltInSemantic());
```

### Snippet 20 (ID: aef59cfa...)

```csharp
// Create a basic browser with public network access
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "A browser for web automation"
});
```

### Snippet 21 (ID: 15980722...)

```csharp
// Create a browser with custom tags
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "A browser for web automation with tags",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingPublicNetwork(),
    Tags = new Dictionary<string, string> {
        { "Environment", "Production" },
        { "Team", "AI/ML" },
        { "Project", "AgentCore" }
    }
});
```

### Snippet 22 (ID: 5db8ac38...)

```csharp
var browser = new agentcore.BrowserCustom(this, "BrowserVpcWithRecording", new BrowserCustomProps {
    BrowserCustomName = "browser_recording",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = new Vpc(this, "VPC", new VpcProps { RestrictDefaultSecurityGroup = false })
    })
});
```

### Snippet 23 (ID: 3611091a...)

```csharp
var vpc = new Vpc(this, "testVPC");

var browser = new agentcore.BrowserCustom(this, "test-browser", new BrowserCustomProps {
    BrowserCustomName = "test_browser",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = vpc
    })
});

browser.Connections.AddSecurityGroup(new SecurityGroup(this, "AdditionalGroup", new SecurityGroupProps { Vpc = vpc }));
```

### Snippet 24 (ID: 5177993c...)

```csharp
// Create an S3 bucket for recordings
var recordingBucket = new Bucket(this, "RecordingBucket", new BucketProps {
    BucketName = "my-browser-recordings",
    RemovalPolicy = RemovalPolicy.DESTROY
});

// Create browser with recording enabled
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "Browser with recording enabled",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingPublicNetwork(),
    RecordingConfig = new RecordingConfig {
        Enabled = true,
        S3Location = new Location {
            BucketName = recordingBucket.BucketName,
            ObjectKey = "browser-recordings/"
        }
    }
});
```

### Snippet 25 (ID: 27976676...)

```csharp
// Create a custom execution role
var executionRole = new Role(this, "BrowserExecutionRole", new RoleProps {
    AssumedBy = new ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    ManagedPolicies = new [] { ManagedPolicy.FromAwsManagedPolicyName("AmazonBedrockAgentCoreBrowserExecutionRolePolicy") }
});

// Create browser with custom execution role
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "Browser with custom execution role",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingPublicNetwork(),
    ExecutionRole = executionRole
});
```

### Snippet 26 (ID: ac3e1e5e...)

```csharp
// Create an S3 bucket for recordings
var recordingBucket = new Bucket(this, "RecordingBucket", new BucketProps {
    BucketName = "my-browser-recordings",
    RemovalPolicy = RemovalPolicy.DESTROY
});

// Create browser with recording enabled
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "Browser with recording enabled",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingPublicNetwork(),
    RecordingConfig = new RecordingConfig {
        Enabled = true,
        S3Location = new Location {
            BucketName = recordingBucket.BucketName,
            ObjectKey = "browser-recordings/"
        }
    }
});
```

### Snippet 27 (ID: 444b170b...)

```csharp
// Create a browser
var browser = new agentcore.BrowserCustom(this, "MyBrowser", new BrowserCustomProps {
    BrowserCustomName = "my_browser",
    Description = "Browser for web automation",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingPublicNetwork()
});

// Create a role that needs access to the browser
var userRole = new Role(this, "UserRole", new RoleProps {
    AssumedBy = new ServicePrincipal("lambda.amazonaws.com")
});

// Grant read permissions (Get and List actions)
browser.GrantRead(userRole);

// Grant use permissions (Start, Update, Stop actions)
browser.GrantUse(userRole);

// Grant specific custom permissions
browser.Grant(userRole, "bedrock-agentcore:GetBrowserSession");
```

### Snippet 28 (ID: a016e911...)

```csharp
// Create a basic gateway with default MCP protocol and Cognito authorizer
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway"
});
```

### Snippet 29 (ID: cddccfcc...)

```csharp
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    })
});
```

### Snippet 30 (ID: 2cf05827...)

```csharp
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    })
});
```

### Snippet 31 (ID: cdfb1cbb...)

```csharp
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.AwsIam
});

// Grant access to a Lambda function's role
var lambdaRole = new Role(this, "LambdaRole", new RoleProps {
    AssumedBy = new ServicePrincipal("lambda.amazonaws.com")
});

// The Lambda needs permission to invoke the gateway
gateway.GrantInvoke(lambdaRole);
```

### Snippet 32 (ID: 1b96e6d2...)

```csharp
// Create a KMS key for encryption
var encryptionKey = new Key(this, "GatewayEncryptionKey", new KeyProps {
    EnableKeyRotation = true,
    Description = "KMS key for gateway encryption"
});

// Create gateway with KMS encryption
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-encrypted-gateway",
    Description = "Gateway with KMS encryption",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    }),
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    }),
    KmsKey = encryptionKey,
    ExceptionLevel = agentcore.GatewayExceptionLevel.DEBUG
});
```

### Snippet 33 (ID: 2fae250c...)

```csharp
// Create a custom execution role
var executionRole = new Role(this, "GatewayExecutionRole", new RoleProps {
    AssumedBy = new ServicePrincipal("bedrock-agentcore.amazonaws.com"),
    ManagedPolicies = new [] { ManagedPolicy.FromAwsManagedPolicyName("AmazonBedrockAgentCoreGatewayExecutionRolePolicy") }
});

// Create gateway with custom execution role
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    Description = "Gateway with custom execution role",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    }),
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    }),
    Role = executionRole
});
```

### Snippet 34 (ID: a47f4a02...)

```csharp
// Create a gateway
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    Description = "Gateway for external service integration",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    }),
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    })
});

// Create a role that needs access to the gateway
var userRole = new Role(this, "UserRole", new RoleProps {
    AssumedBy = new ServicePrincipal("lambda.amazonaws.com")
});

// Grant read permissions (Get and List actions)
gateway.GrantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
gateway.GrantManage(userRole);

// Grant specific custom permissions
gateway.Grant(userRole, "bedrock-agentcore:GetGateway");
```

### Snippet 35 (ID: 52d6584e...)

```csharp
var toolSchema = agentcore.ToolSchema.FromLocalAsset(path.Join(__dirname, "schemas", "my-tool-schema.json"));
```

### Snippet 36 (ID: 14041e87...)

```csharp
var toolSchema = agentcore.ToolSchema.FromS3File(Bucket.FromBucketName(this, "SchemasBucket", "my-schemas-bucket"), "tools/complex-tool-schema.json", "123456789012");
```

### Snippet 37 (ID: 11b5c8ff...)

```csharp
var toolSchema = agentcore.ToolSchema.FromInline(new [] { new ToolDefinition {
    Name = "hello_world",
    Description = "A simple hello world tool",
    InputSchema = new SchemaDefinition {
        Type = agentcore.SchemaDefinitionType.OBJECT,
        Properties = new Dictionary<string, SchemaDefinition> {
            { "name", new SchemaDefinition {
                Type = agentcore.SchemaDefinitionType.STRING,
                Description = "The name to greet"
            } }
        },
        Required = new [] { "name" }
    }
} });
```

### Snippet 38 (ID: bf7d63e6...)

```csharp
// When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
var schema = agentcore.ApiSchema.FromLocalAsset(path.Join(__dirname, "mySchema.yml"));
schema.Bind(this);
```

### Snippet 39 (ID: dad78422...)

```csharp
var inlineSchema = agentcore.ApiSchema.FromInline(@"
openapi: 3.0.3
info:
  title: Library API
  version: 1.0.0
paths:
  /search:
    get:
      summary: Search for books
      operationId: searchBooks
      parameters:
        - name: query
          in: query
          required: true
          schema:
            type: string
");
```

### Snippet 40 (ID: 23c2fae5...)

```csharp
var bucket = Bucket.FromBucketName(this, "ExistingBucket", "my-schema-bucket");
var s3Schema = agentcore.ApiSchema.FromS3File(bucket, "schemas/action-group.yaml");
```

### Snippet 41 (ID: 5fbfe426...)

```csharp
// Create a gateway first
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    }),
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    })
});

// These ARNs are returned when creating the API key credential provider via Console or API
var apiKeyProviderArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
var apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

var bucket = Bucket.FromBucketName(this, "ExistingBucket", "my-schema-bucket");
var s3mySchema = agentcore.ApiSchema.FromS3File(bucket, "schemas/myschema.yaml");

// Add an OpenAPI target directly to the gateway
var target = gateway.AddOpenApiTarget("MyTarget", new AddOpenApiTargetOptions {
    GatewayTargetName = "my-api-target",
    Description = "Target for external API integration",
    ApiSchema = s3mySchema,
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.ApiKey(new ApiKeyCredentialProviderProps {
        ProviderArn = apiKeyProviderArn,
        SecretArn = apiKeySecretArn,
        CredentialLocation = agentcore.ApiKeyCredentialLocation.Header(new ApiKeyAdditionalConfiguration {
            CredentialParameterName = "X-API-Key"
        })
    }) }
});

// Add a Lambda target
var lambdaFunction = new Function(this, "MyFunction", new FunctionProps {
    Runtime = Runtime.NODEJS_22_X,
    Handler = "index.handler",
    Code = Code.FromInline(@"
        exports.handler = async (event) => {
          return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Hello from Lambda!' })
          };
        };
      ")
});

var lambdaTarget = gateway.AddLambdaTarget("MyLambdaTarget", new AddLambdaTargetOptions {
    GatewayTargetName = "my-lambda-target",
    Description = "Lambda function target",
    LambdaFunction = lambdaFunction,
    ToolSchema = agentcore.ToolSchema.FromInline(new [] { new ToolDefinition {
        Name = "hello_world",
        Description = "A simple hello world tool",
        InputSchema = new SchemaDefinition {
            Type = agentcore.SchemaDefinitionType.OBJECT,
            Properties = new Dictionary<string, SchemaDefinition> {
                { "name", new SchemaDefinition {
                    Type = agentcore.SchemaDefinitionType.STRING,
                    Description = "The name to greet"
                } }
            },
            Required = new [] { "name" }
        }
    } })
});

// Add a Smithy target
var smithySchema = agentcore.ApiSchema.FromS3File(bucket, "schemas/mymodel.json");
var smithyTarget = gateway.AddSmithyTarget("MySmithyTarget", new AddSmithyTargetOptions {
    GatewayTargetName = "my-smithy-target",
    Description = "Smithy model target",
    SmithyModel = smithySchema,
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.IamRole() }
});
```

### Snippet 42 (ID: 3293480b...)

```csharp
// Create a gateway first
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway"
});

var apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
var apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

var bucket = Bucket.FromBucketName(this, "ExistingBucket", "my-schema-bucket");
var s3Schema = agentcore.ApiSchema.FromS3File(bucket, "schemas/myschema.yaml");

// Create a gateway target with OpenAPI Schema
var openApitarget = agentcore.GatewayTarget.ForOpenApi(this, "MyTarget", new GatewayTargetOpenApiProps {
    GatewayTargetName = "my-api-target",
    Description = "Target for external API integration",
    Gateway = gateway,  // Note: you need to pass the gateway reference
    ApiSchema = s3Schema,
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.ApiKey(new ApiKeyCredentialProviderProps {
        ProviderArn = apiKeyIdentityArn,
        SecretArn = apiKeySecretArn,
        CredentialLocation = agentcore.ApiKeyCredentialLocation.Header(new ApiKeyAdditionalConfiguration {
            CredentialParameterName = "X-API-Key"
        })
    }) }
});

// Create a Lambda function
var lambdaFunction = new Function(this, "MyFunction", new FunctionProps {
    Runtime = Runtime.NODEJS_22_X,
    Handler = "index.handler",
    Code = Code.FromInline(@"
            exports.handler = async (event) => {
                return {
                    statusCode: 200,
                    body: JSON.stringify({ message: 'Hello from Lambda!' })
                };
            };
        ")
});

// Create a gateway target with Lambda and tool schema
var lambdaTarget = agentcore.GatewayTarget.ForLambda(this, "MyLambdaTarget", new GatewayTargetLambdaProps {
    GatewayTargetName = "my-lambda-target",
    Description = "Target for Lambda function integration",
    Gateway = gateway,
    LambdaFunction = lambdaFunction,
    ToolSchema = agentcore.ToolSchema.FromInline(new [] { new ToolDefinition {
        Name = "hello_world",
        Description = "A simple hello world tool",
        InputSchema = new SchemaDefinition {
            Type = agentcore.SchemaDefinitionType.OBJECT,
            Description = "Input schema for hello world tool",
            Properties = new Dictionary<string, SchemaDefinition> {
                { "name", new SchemaDefinition {
                    Type = agentcore.SchemaDefinitionType.STRING,
                    Description = "The name to greet"
                } }
            },
            Required = new [] { "name" }
        },
        OutputSchema = new SchemaDefinition {
            Type = agentcore.SchemaDefinitionType.OBJECT,
            Description = "Output schema for hello world tool",
            Properties = new Dictionary<string, SchemaDefinition> {
                { "message", new SchemaDefinition {
                    Type = agentcore.SchemaDefinitionType.STRING,
                    Description = "The greeting message"
                } }
            }
        }
    } }),
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.IamRole() }
});

// Create an OAuth identity
var oauthIdentityArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth123";
var oauthSecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

var schemaBucket = Bucket.FromBucketName(this, "SchemaBucket", "my-schema-bucket");
var s3SmithySchema = agentcore.ApiSchema.FromS3File(schemaBucket, "schemas/myschema.json");

// Create a gateway target with Smithy Model and OAuth
var target = agentcore.GatewayTarget.ForSmithy(this, "MySmithyTarget", new GatewayTargetSmithyProps {
    GatewayTargetName = "my-smithy-target",
    Description = "Target for Smithy model integration",
    Gateway = gateway,
    SmithyModel = s3SmithySchema,
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.Oauth(new OAuthConfiguration {
        ProviderArn = oauthIdentityArn,
        SecretArn = oauthSecretArn,
        Scopes = new [] { "read", "write" },
        CustomParameters = new Dictionary<string, string> {
            { "audience", "https://api.example.com" },
            { "response_type", "code" }
        }
    }) }
});
```

### Snippet 43 (ID: 7d741b0e...)

```csharp
// Create a gateway and target
var gateway = new agentcore.Gateway(this, "MyGateway", new GatewayProps {
    GatewayName = "my-gateway",
    ProtocolConfiguration = new agentcore.McpProtocolConfiguration(new McpConfiguration {
        Instructions = "Use this gateway to connect to external MCP tools",
        SearchType = agentcore.McpGatewaySearchType.SEMANTIC,
        SupportedVersions = new [] { agentcore.MCPProtocolVersion.MCP_2025_03_26 }
    }),
    AuthorizerConfiguration = agentcore.GatewayAuthorizer.UsingCustomJwt(new CustomJwtConfiguration {
        DiscoveryUrl = "https://auth.example.com/.well-known/openid-configuration",
        AllowedAudience = new [] { "my-app" },
        AllowedClients = new [] { "my-client-id" }
    })
});

var apiKeyIdentityArn = "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey";
var apiKeySecretArn = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123";

var bucket = Bucket.FromBucketName(this, "ExistingBucket", "my-schema-bucket");
var s3apiSchema = agentcore.ApiSchema.FromS3File(bucket, "schemas/myschema.yaml");

var target = agentcore.GatewayTarget.ForOpenApi(this, "MyTarget", new GatewayTargetOpenApiProps {
    GatewayTargetName = "my-target",
    Gateway = gateway,
    ApiSchema = s3apiSchema,
    CredentialProviderConfigurations = new [] { agentcore.GatewayCredentialProvider.ApiKey(new ApiKeyCredentialProviderProps {
        ProviderArn = apiKeyIdentityArn,
        SecretArn = apiKeySecretArn,
        CredentialLocation = agentcore.ApiKeyCredentialLocation.Header(new ApiKeyAdditionalConfiguration {
            CredentialParameterName = "X-API-Key"
        })
    }) }
});

// Create a role that needs access to the gateway target
var userRole = new Role(this, "UserRole", new RoleProps {
    AssumedBy = new ServicePrincipal("lambda.amazonaws.com")
});

// Grant read permissions (Get and List actions)
target.GrantRead(userRole);

// Grant manage permissions (Create, Update, Delete actions)
target.GrantManage(userRole);

// Grant specific custom permissions
target.Grant(userRole, "bedrock-agentcore:GetGatewayTarget");
```

### Snippet 44 (ID: fde53762...)

```csharp
// Create a basic code interpreter with public network access
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_code_interpreter",
    Description = "A code interpreter for Python execution"
});
```

### Snippet 45 (ID: fd30da56...)

```csharp
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_sandbox_interpreter",
    Description = "Code interpreter with isolated network access",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = new Vpc(this, "VPC", new VpcProps { RestrictDefaultSecurityGroup = false })
    })
});
```

### Snippet 46 (ID: 504a5940...)

```csharp
var vpc = new Vpc(this, "testVPC");

var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_sandbox_interpreter",
    Description = "Code interpreter with isolated network access",
    NetworkConfiguration = agentcore.BrowserNetworkConfiguration.UsingVpc(this, new VpcConfigProps {
        Vpc = vpc
    })
});

codeInterpreter.Connections.AddSecurityGroup(new SecurityGroup(this, "AdditionalGroup", new SecurityGroupProps { Vpc = vpc }));
```

### Snippet 47 (ID: aa6f2dda...)

```csharp
// Create code interpreter with sandbox network mode (isolated)
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_sandbox_interpreter",
    Description = "Code interpreter with isolated network access",
    NetworkConfiguration = agentcore.CodeInterpreterNetworkConfiguration.UsingSandboxNetwork()
});
```

### Snippet 48 (ID: a7071766...)

```csharp
// Create a custom execution role
var executionRole = new Role(this, "CodeInterpreterExecutionRole", new RoleProps {
    AssumedBy = new ServicePrincipal("bedrock-agentcore.amazonaws.com")
});

// Create code interpreter with custom execution role
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_code_interpreter",
    Description = "Code interpreter with custom execution role",
    NetworkConfiguration = agentcore.CodeInterpreterNetworkConfiguration.UsingPublicNetwork(),
    ExecutionRole = executionRole
});
```

### Snippet 49 (ID: cedd86ae...)

```csharp
// Create a code interpreter
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_code_interpreter",
    Description = "Code interpreter for Python execution",
    NetworkConfiguration = agentcore.CodeInterpreterNetworkConfiguration.UsingPublicNetwork()
});

// Create a role that needs access to the code interpreter
var userRole = new Role(this, "UserRole", new RoleProps {
    AssumedBy = new ServicePrincipal("lambda.amazonaws.com")
});

// Grant read permissions (Get and List actions)
codeInterpreter.GrantRead(userRole);

// Grant use permissions (Start, Invoke, Stop actions)
codeInterpreter.GrantUse(userRole);

// Grant specific custom permissions
codeInterpreter.Grant(userRole, "bedrock-agentcore:GetCodeInterpreterSession");
```

### Snippet 50 (ID: 65a79060...)

```csharp
// Create code interpreter with sandbox network mode (isolated)
var codeInterpreter = new agentcore.CodeInterpreterCustom(this, "MyCodeInterpreter", new CodeInterpreterCustomProps {
    CodeInterpreterCustomName = "my_sandbox_interpreter",
    Description = "Code interpreter with isolated network access",
    NetworkConfiguration = agentcore.CodeInterpreterNetworkConfiguration.UsingPublicNetwork(),
    Tags = new Dictionary<string, string> {
        { "Environment", "Production" },
        { "Team", "AI/ML" },
        { "Project", "AgentCore" }
    }
});
```

### Snippet 51 (ID: cae11061...)

```csharp
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123";
```

### Snippet 52 (ID: 0471d468...)

```csharp
"runtime-abc123";
```

### Snippet 53 (ID: 6b4f6935...)

```csharp
"2024-01-15T10:30:00Z";
```

### Snippet 54 (ID: 379fc387...)

```csharp
"2024-01-15T14:45:00Z";
```

### Snippet 55 (ID: 7e85b1e8...)

```csharp
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123";
```

---

## Go

**55 snippet(s) available**

### Snippet 1 (ID: 51c2184c...)

```go
// Create a new API key identity
apiKeyIdentityArn := "your-api-key-arn"
```

### Snippet 2 (ID: 6c86e96d...)

```go
oauthIdentityArn := "oauth-idp-arn"
```

### Snippet 3 (ID: 50e9623f...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})

// The runtime by default create ECR permission only for the repository available in the account the stack is being deployed
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

// Create runtime using the built image
runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
})
```

### Snippet 4 (ID: bd4fbd33...)

```go
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromAsset(path.join(__dirname, jsii.String("path to agent dockerfile directory")))

runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
})
```

### Snippet 5 (ID: 837f5f72...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})

//Initial Deployment - Automatically creates Version 1
runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0")),
})
// At this point: A DEFAULT endpoint is created which points to version 1

// You can create a new endpoint (production) which points to version1
prodEndpoint := runtime.AddEndpoint(jsii.String("production"), &AddEndpointOptions{
	Version: jsii.String("1"),
	Description: jsii.String("Stable production endpoint - pinned to v1"),
})

// When you update the runtime configuration e.g. new container image, protocol change, network settings
// a new version (Version 2) is automatically created

// After update: Version 2 is created automatically
// DEFAULT endpoint automatically updates to Version 2
// Production endpoint remains on Version 1 (explicitly pinned)

// Now that Version 2 exists, create a staging endpoint for testing
stagingEndpoint := runtime.AddEndpoint(jsii.String("staging"), &AddEndpointOptions{
	Version: jsii.String("2"),
	Description: jsii.String("Staging environment for testing new version"),
})
```

### Snippet 6 (ID: 97a9a76c...)

```go
// Reference an existing runtime by its ID
existingRuntimeId := "abc123-runtime-id" // The ID of an existing runtime

// Create a standalone endpoint
endpoint := agentcore.NewRuntimeEndpoint(this, jsii.String("MyEndpoint"), &RuntimeEndpointProps{
	EndpointName: jsii.String("production"),
	AgentRuntimeId: existingRuntimeId,
	AgentRuntimeVersion: jsii.String("1"),
	 // Specify which version to use
	Description: jsii.String("Production endpoint for existing runtime"),
})
```

### Snippet 7 (ID: d4ae6d28...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	AuthorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration_UsingCognito(jsii.String("us-west-2_ABC123"), jsii.String("client123"), jsii.String("us-west-2")),
})
```

### Snippet 8 (ID: 8bced5c5...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	AuthorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration_UsingJWT(jsii.String("https://example.com/.well-known/openid-configuration"), []*string{
		jsii.String("client1"),
		jsii.String("client2"),
	}, []*string{
		jsii.String("audience1"),
	}),
})
```

### Snippet 9 (ID: 2271afce...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	AuthorizerConfiguration: agentcore.RuntimeAuthorizerConfiguration_UsingOAuth(jsii.String("https://github.com/.well-known/openid-configuration"), jsii.String("oauth_client_123")),
})
```

### Snippet 10 (ID: b84b740e...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

// Explicitly using public network (this is the default)
runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	NetworkConfiguration: agentcore.RuntimeNetworkConfiguration_UsingPublicNetwork(),
})
```

### Snippet 11 (ID: b72e3ac0...)

```go
repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

// Create or use an existing VPC
vpc := ec2.NewVpc(this, jsii.String("MyVpc"), &VpcProps{
	MaxAzs: jsii.Number(2),
})

// Configure runtime with VPC
runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	NetworkConfiguration: agentcore.RuntimeNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: vpc,
		VpcSubnets: &SubnetSelection{
			SubnetType: ec2.SubnetType_PRIVATE_WITH_EGRESS,
		},
	}),
})
```

### Snippet 12 (ID: 545b0fa6...)

```go
vpc := ec2.NewVpc(this, jsii.String("MyVpc"), &VpcProps{
	MaxAzs: jsii.Number(2),
})

repository := ecr.NewRepository(this, jsii.String("TestRepository"), &RepositoryProps{
	RepositoryName: jsii.String("test-agent-runtime"),
})
agentRuntimeArtifact := agentcore.AgentRuntimeArtifact_FromEcrRepository(repository, jsii.String("v1.0.0"))

// Create runtime with VPC configuration
runtime := agentcore.NewRuntime(this, jsii.String("MyAgentRuntime"), &RuntimeProps{
	RuntimeName: jsii.String("myAgent"),
	AgentRuntimeArtifact: agentRuntimeArtifact,
	NetworkConfiguration: agentcore.RuntimeNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: vpc,
		VpcSubnets: &SubnetSelection{
			SubnetType: ec2.SubnetType_PRIVATE_WITH_EGRESS,
		},
	}),
})

// Now you can manage network access using the connections property
// Allow inbound HTTPS traffic from a specific security group
webServerSecurityGroup := ec2.NewSecurityGroup(this, jsii.String("WebServerSG"), &SecurityGroupProps{
	Vpc: Vpc,
})
runtime.connections.AllowFrom(webServerSecurityGroup, ec2.Port_Tcp(jsii.Number(443)), jsii.String("Allow HTTPS from web servers"))

// Allow outbound connections to a database
databaseSecurityGroup := ec2.NewSecurityGroup(this, jsii.String("DatabaseSG"), &SecurityGroupProps{
	Vpc: Vpc,
})
runtime.connections.AllowTo(databaseSecurityGroup, ec2.Port_Tcp(jsii.Number(5432)), jsii.String("Allow PostgreSQL connection"))

// Allow outbound HTTPS to anywhere (for external API calls)
runtime.connections.AllowToAnyIpv4(ec2.Port_Tcp(jsii.Number(443)), jsii.String("Allow HTTPS outbound"))
```

### Snippet 13 (ID: 920d31a1...)

```go
// Create a basic memory with default settings, no LTM strategies
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my_memory"),
	Description: jsii.String("A memory for storing user interactions for a period of 90 days"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
})
```

### Snippet 14 (ID: de9dfac6...)

```go
// Create a custom KMS key for encryption
encryptionKey := kms.NewKey(this, jsii.String("MemoryEncryptionKey"), &KeyProps{
	EnableKeyRotation: jsii.Boolean(true),
	Description: jsii.String("KMS key for memory encryption"),
})

// Create memory with custom encryption
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my_encrypted_memory"),
	Description: jsii.String("Memory with custom KMS encryption"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
	KmsKey: encryptionKey,
})
```

### Snippet 15 (ID: b638db3f...)

```go
// Create memory with built-in strategies
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my_memory"),
	Description: jsii.String("Memory with built-in strategies"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
	MemoryStrategies: []iMemoryStrategy{
		agentcore.MemoryStrategy_UsingBuiltInSummarization(),
		agentcore.MemoryStrategy_UsingBuiltInSemantic(),
		agentcore.MemoryStrategy_UsingBuiltInUserPreference(),
	},
})
```

### Snippet 16 (ID: c943056b...)

```go
// Create memory with built-in strategies
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my_memory"),
	Description: jsii.String("Memory with built-in strategies"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
	MemoryStrategies: []iMemoryStrategy{
		agentcore.MemoryStrategy_UsingUserPreference(&MemoryStrategyCommonProps{
			Name: jsii.String("CustomerPreferences"),
			Namespaces: []*string{
				jsii.String("support/customer/{actorId}/preferences"),
			},
		}),
		agentcore.MemoryStrategy_UsingSemantic(&MemoryStrategyCommonProps{
			Name: jsii.String("CustomerSupportSemantic"),
			Namespaces: []*string{
				jsii.String("support/customer/{actorId}/semantic"),
			},
		}),
	},
})
```

### Snippet 17 (ID: 3b589e6a...)

```go
// Create a custom execution role
executionRole := iam.NewRole(this, jsii.String("MemoryExecutionRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("bedrock-agentcore.amazonaws.com")),
	ManagedPolicies: []iManagedPolicy{
		iam.ManagedPolicy_FromAwsManagedPolicyName(jsii.String("AmazonBedrockAgentCoreMemoryBedrockModelInferenceExecutionRolePolicy")),
	},
})

// Create memory with custom execution role
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my_memory"),
	Description: jsii.String("Memory with custom execution role"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
})
```

### Snippet 18 (ID: 853451ae...)

```go
// Create a custom semantic memory strategy
customSemanticStrategy := agentcore.MemoryStrategy_UsingSemanticOverride(&OverrideStrategyProps{
	Name: jsii.String("customSemanticStrategy"),
	Description: jsii.String("Custom semantic memory strategy"),
	Namespaces: []*string{
		jsii.String("/custom/strategies/{memoryStrategyId}/actors/{actorId}"),
	},
	CustomConsolidation: &OverrideConfig{
		Model: bedrock.BedrockFoundationModel_ANTHROPIC_CLAUDE_3_5_SONNET_V1_0(),
		AppendToPrompt: jsii.String("Custom consolidation prompt for semantic memory"),
	},
	CustomExtraction: &OverrideConfig{
		Model: bedrock.BedrockFoundationModel_ANTHROPIC_CLAUDE_3_5_SONNET_V1_0(),
		AppendToPrompt: jsii.String("Custom extraction prompt for semantic memory"),
	},
})

// Create memory with custom strategy
memory := agentcore.NewMemory(this, jsii.String("MyMemory"), &MemoryProps{
	MemoryName: jsii.String("my-custom-memory"),
	Description: jsii.String("Memory with custom strategy"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
	MemoryStrategies: []iMemoryStrategy{
		customSemanticStrategy,
	},
})
```

### Snippet 19 (ID: aa0231c9...)

```go
// Create memory without initial strategies
memory := agentcore.NewMemory(this, jsii.String("test-memory"), &MemoryProps{
	MemoryName: jsii.String("test_memory_add_strategy"),
	Description: jsii.String("A test memory for testing addMemoryStrategy method"),
	ExpirationDuration: cdk.Duration_Days(jsii.Number(90)),
})

// Add strategies after instantiation
memory.AddMemoryStrategy(agentcore.MemoryStrategy_UsingBuiltInSummarization())
memory.AddMemoryStrategy(agentcore.MemoryStrategy_UsingBuiltInSemantic())
```

### Snippet 20 (ID: aef59cfa...)

```go
// Create a basic browser with public network access
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("A browser for web automation"),
})
```

### Snippet 21 (ID: 15980722...)

```go
// Create a browser with custom tags
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("A browser for web automation with tags"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingPublicNetwork(),
	Tags: map[string]*string{
		"Environment": jsii.String("Production"),
		"Team": jsii.String("AI/ML"),
		"Project": jsii.String("AgentCore"),
	},
})
```

### Snippet 22 (ID: 5db8ac38...)

```go
browser := agentcore.NewBrowserCustom(this, jsii.String("BrowserVpcWithRecording"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("browser_recording"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: ec2.NewVpc(this, jsii.String("VPC"), &VpcProps{
			RestrictDefaultSecurityGroup: jsii.Boolean(false),
		}),
	}),
})
```

### Snippet 23 (ID: 3611091a...)

```go
vpc := ec2.NewVpc(this, jsii.String("testVPC"))

browser := agentcore.NewBrowserCustom(this, jsii.String("test-browser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("test_browser"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: vpc,
	}),
})

browser.connections.AddSecurityGroup(ec2.NewSecurityGroup(this, jsii.String("AdditionalGroup"), &SecurityGroupProps{
	Vpc: Vpc,
}))
```

### Snippet 24 (ID: 5177993c...)

```go
// Create an S3 bucket for recordings
recordingBucket := s3.NewBucket(this, jsii.String("RecordingBucket"), &BucketProps{
	BucketName: jsii.String("my-browser-recordings"),
	RemovalPolicy: awscdk.RemovalPolicy_DESTROY,
})

// Create browser with recording enabled
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("Browser with recording enabled"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingPublicNetwork(),
	RecordingConfig: &RecordingConfig{
		Enabled: jsii.Boolean(true),
		S3Location: &Location{
			BucketName: recordingBucket.BucketName,
			ObjectKey: jsii.String("browser-recordings/"),
		},
	},
})
```

### Snippet 25 (ID: 27976676...)

```go
// Create a custom execution role
executionRole := iam.NewRole(this, jsii.String("BrowserExecutionRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("bedrock-agentcore.amazonaws.com")),
	ManagedPolicies: []iManagedPolicy{
		iam.ManagedPolicy_FromAwsManagedPolicyName(jsii.String("AmazonBedrockAgentCoreBrowserExecutionRolePolicy")),
	},
})

// Create browser with custom execution role
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("Browser with custom execution role"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingPublicNetwork(),
	ExecutionRole: executionRole,
})
```

### Snippet 26 (ID: ac3e1e5e...)

```go
// Create an S3 bucket for recordings
recordingBucket := s3.NewBucket(this, jsii.String("RecordingBucket"), &BucketProps{
	BucketName: jsii.String("my-browser-recordings"),
	RemovalPolicy: awscdk.RemovalPolicy_DESTROY,
})

// Create browser with recording enabled
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("Browser with recording enabled"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingPublicNetwork(),
	RecordingConfig: &RecordingConfig{
		Enabled: jsii.Boolean(true),
		S3Location: &Location{
			BucketName: recordingBucket.BucketName,
			ObjectKey: jsii.String("browser-recordings/"),
		},
	},
})
```

### Snippet 27 (ID: 444b170b...)

```go
// Create a browser
browser := agentcore.NewBrowserCustom(this, jsii.String("MyBrowser"), &BrowserCustomProps{
	BrowserCustomName: jsii.String("my_browser"),
	Description: jsii.String("Browser for web automation"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingPublicNetwork(),
})

// Create a role that needs access to the browser
userRole := iam.NewRole(this, jsii.String("UserRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("lambda.amazonaws.com")),
})

// Grant read permissions (Get and List actions)
browser.GrantRead(userRole)

// Grant use permissions (Start, Update, Stop actions)
browser.GrantUse(userRole)

// Grant specific custom permissions
browser.Grant(userRole, jsii.String("bedrock-agentcore:GetBrowserSession"))
```

### Snippet 28 (ID: a016e911...)

```go
// Create a basic gateway with default MCP protocol and Cognito authorizer
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
})
```

### Snippet 29 (ID: cddccfcc...)

```go
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
})
```

### Snippet 30 (ID: 2cf05827...)

```go
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
})
```

### Snippet 31 (ID: cdfb1cbb...)

```go
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_AwsIam(),
})

// Grant access to a Lambda function's role
lambdaRole := iam.NewRole(this, jsii.String("LambdaRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("lambda.amazonaws.com")),
})

// The Lambda needs permission to invoke the gateway
gateway.GrantInvoke(lambdaRole)
```

### Snippet 32 (ID: 1b96e6d2...)

```go
// Create a KMS key for encryption
encryptionKey := kms.NewKey(this, jsii.String("GatewayEncryptionKey"), &KeyProps{
	EnableKeyRotation: jsii.Boolean(true),
	Description: jsii.String("KMS key for gateway encryption"),
})

// Create gateway with KMS encryption
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-encrypted-gateway"),
	Description: jsii.String("Gateway with KMS encryption"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
	KmsKey: encryptionKey,
	ExceptionLevel: agentcore.GatewayExceptionLevel_DEBUG,
})
```

### Snippet 33 (ID: 2fae250c...)

```go
// Create a custom execution role
executionRole := iam.NewRole(this, jsii.String("GatewayExecutionRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("bedrock-agentcore.amazonaws.com")),
	ManagedPolicies: []iManagedPolicy{
		iam.ManagedPolicy_FromAwsManagedPolicyName(jsii.String("AmazonBedrockAgentCoreGatewayExecutionRolePolicy")),
	},
})

// Create gateway with custom execution role
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	Description: jsii.String("Gateway with custom execution role"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
	Role: executionRole,
})
```

### Snippet 34 (ID: a47f4a02...)

```go
// Create a gateway
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	Description: jsii.String("Gateway for external service integration"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
})

// Create a role that needs access to the gateway
userRole := iam.NewRole(this, jsii.String("UserRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("lambda.amazonaws.com")),
})

// Grant read permissions (Get and List actions)
gateway.GrantRead(userRole)

// Grant manage permissions (Create, Update, Delete actions)
gateway.GrantManage(userRole)

// Grant specific custom permissions
gateway.Grant(userRole, jsii.String("bedrock-agentcore:GetGateway"))
```

### Snippet 35 (ID: 52d6584e...)

```go
toolSchema := agentcore.ToolSchema_FromLocalAsset(path.join(__dirname, jsii.String("schemas"), jsii.String("my-tool-schema.json")))
```

### Snippet 36 (ID: 14041e87...)

```go
toolSchema := agentcore.ToolSchema_FromS3File(s3.Bucket_FromBucketName(this, jsii.String("SchemasBucket"), jsii.String("my-schemas-bucket")), jsii.String("tools/complex-tool-schema.json"), jsii.String("123456789012"))
```

### Snippet 37 (ID: 11b5c8ff...)

```go
toolSchema := agentcore.ToolSchema_FromInline([]toolDefinition{
	&toolDefinition{
		Name: jsii.String("hello_world"),
		Description: jsii.String("A simple hello world tool"),
		InputSchema: &SchemaDefinition{
			Type: agentcore.SchemaDefinitionType_OBJECT,
			Properties: map[string]schemaDefinition{
				"name": &schemaDefinition{
					"type": agentcore.SchemaDefinitionType_STRING,
					"description": jsii.String("The name to greet"),
				},
			},
			Required: []*string{
				jsii.String("name"),
			},
		},
	},
})
```

### Snippet 38 (ID: bf7d63e6...)

```go
// When using ApiSchema.fromLocalAsset, you must bind the schema to a scope
schema := agentcore.ApiSchema_FromLocalAsset(path.join(__dirname, jsii.String("mySchema.yml")))
schema.Bind(this)
```

### Snippet 39 (ID: dad78422...)

```go
inlineSchema := agentcore.ApiSchema_FromInline(jsii.String(`
openapi: 3.0.3
info:
  title: Library API
  version: 1.0.0
paths:
  /search:
    get:
      summary: Search for books
      operationId: searchBooks
      parameters:
        - name: query
          in: query
          required: true
          schema:
            type: string
`))
```

### Snippet 40 (ID: 23c2fae5...)

```go
bucket := s3.Bucket_FromBucketName(this, jsii.String("ExistingBucket"), jsii.String("my-schema-bucket"))
s3Schema := agentcore.ApiSchema_FromS3File(bucket, jsii.String("schemas/action-group.yaml"))
```

### Snippet 41 (ID: 5fbfe426...)

```go
// Create a gateway first
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
})

// These ARNs are returned when creating the API key credential provider via Console or API
apiKeyProviderArn := "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
apiKeySecretArn := "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket := s3.Bucket_FromBucketName(this, jsii.String("ExistingBucket"), jsii.String("my-schema-bucket"))
s3mySchema := agentcore.ApiSchema_FromS3File(bucket, jsii.String("schemas/myschema.yaml"))

// Add an OpenAPI target directly to the gateway
target := gateway.AddOpenApiTarget(jsii.String("MyTarget"), &AddOpenApiTargetOptions{
	GatewayTargetName: jsii.String("my-api-target"),
	Description: jsii.String("Target for external API integration"),
	ApiSchema: s3mySchema,
	CredentialProviderConfigurations: []iCredentialProvider{
		agentcore.GatewayCredentialProvider_ApiKey(&ApiKeyCredentialProviderProps{
			ProviderArn: apiKeyProviderArn,
			SecretArn: apiKeySecretArn,
			CredentialLocation: agentcore.ApiKeyCredentialLocation_Header(&ApiKeyAdditionalConfiguration{
				CredentialParameterName: jsii.String("X-API-Key"),
			}),
		}),
	},
})

// Add a Lambda target
lambdaFunction := lambda.NewFunction(this, jsii.String("MyFunction"), &FunctionProps{
	Runtime: lambda.Runtime_NODEJS_22_X(),
	Handler: jsii.String("index.handler"),
	Code: lambda.Code_FromInline(jsii.String(`
	    exports.handler = async (event) => {
	      return {
	        statusCode: 200,
	        body: JSON.stringify({ message: 'Hello from Lambda!' })
	      };
	    };
	  `)),
})

lambdaTarget := gateway.AddLambdaTarget(jsii.String("MyLambdaTarget"), &AddLambdaTargetOptions{
	GatewayTargetName: jsii.String("my-lambda-target"),
	Description: jsii.String("Lambda function target"),
	LambdaFunction: lambdaFunction,
	ToolSchema: agentcore.ToolSchema_FromInline([]toolDefinition{
		&toolDefinition{
			Name: jsii.String("hello_world"),
			Description: jsii.String("A simple hello world tool"),
			InputSchema: &SchemaDefinition{
				Type: agentcore.SchemaDefinitionType_OBJECT,
				Properties: map[string]schemaDefinition{
					"name": &schemaDefinition{
						"type": agentcore.SchemaDefinitionType_STRING,
						"description": jsii.String("The name to greet"),
					},
				},
				Required: []*string{
					jsii.String("name"),
				},
			},
		},
	}),
})

// Add a Smithy target
smithySchema := agentcore.ApiSchema_FromS3File(bucket, jsii.String("schemas/mymodel.json"))
smithyTarget := gateway.AddSmithyTarget(jsii.String("MySmithyTarget"), &AddSmithyTargetOptions{
	GatewayTargetName: jsii.String("my-smithy-target"),
	Description: jsii.String("Smithy model target"),
	SmithyModel: smithySchema,
	CredentialProviderConfigurations: []*iCredentialProvider{
		agentcore.GatewayCredentialProvider_IamRole(),
	},
})
```

### Snippet 42 (ID: 3293480b...)

```go
// Create a gateway first
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
})

apiKeyIdentityArn := "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
apiKeySecretArn := "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket := s3.Bucket_FromBucketName(this, jsii.String("ExistingBucket"), jsii.String("my-schema-bucket"))
s3Schema := agentcore.ApiSchema_FromS3File(bucket, jsii.String("schemas/myschema.yaml"))

// Create a gateway target with OpenAPI Schema
openApitarget := agentcore.GatewayTarget_ForOpenApi(this, jsii.String("MyTarget"), &GatewayTargetOpenApiProps{
	GatewayTargetName: jsii.String("my-api-target"),
	Description: jsii.String("Target for external API integration"),
	Gateway: gateway,
	 // Note: you need to pass the gateway reference
	ApiSchema: s3Schema,
	CredentialProviderConfigurations: []iCredentialProvider{
		agentcore.GatewayCredentialProvider_ApiKey(&ApiKeyCredentialProviderProps{
			ProviderArn: apiKeyIdentityArn,
			SecretArn: apiKeySecretArn,
			CredentialLocation: agentcore.ApiKeyCredentialLocation_Header(&ApiKeyAdditionalConfiguration{
				CredentialParameterName: jsii.String("X-API-Key"),
			}),
		}),
	},
})

// Create a Lambda function
lambdaFunction := lambda.NewFunction(this, jsii.String("MyFunction"), &FunctionProps{
	Runtime: lambda.Runtime_NODEJS_22_X(),
	Handler: jsii.String("index.handler"),
	Code: lambda.Code_FromInline(jsii.String(`
	        exports.handler = async (event) => {
	            return {
	                statusCode: 200,
	                body: JSON.stringify({ message: 'Hello from Lambda!' })
	            };
	        };
	    `)),
})

// Create a gateway target with Lambda and tool schema
lambdaTarget := agentcore.GatewayTarget_ForLambda(this, jsii.String("MyLambdaTarget"), &GatewayTargetLambdaProps{
	GatewayTargetName: jsii.String("my-lambda-target"),
	Description: jsii.String("Target for Lambda function integration"),
	Gateway: gateway,
	LambdaFunction: lambdaFunction,
	ToolSchema: agentcore.ToolSchema_FromInline([]toolDefinition{
		&toolDefinition{
			Name: jsii.String("hello_world"),
			Description: jsii.String("A simple hello world tool"),
			InputSchema: &SchemaDefinition{
				Type: agentcore.SchemaDefinitionType_OBJECT,
				Description: jsii.String("Input schema for hello world tool"),
				Properties: map[string]schemaDefinition{
					"name": &schemaDefinition{
						"type": agentcore.SchemaDefinitionType_STRING,
						"description": jsii.String("The name to greet"),
					},
				},
				Required: []*string{
					jsii.String("name"),
				},
			},
			OutputSchema: &schemaDefinition{
				Type: agentcore.SchemaDefinitionType_OBJECT,
				Description: jsii.String("Output schema for hello world tool"),
				Properties: map[string]*schemaDefinition{
					"message": &schemaDefinition{
						"type": agentcore.SchemaDefinitionType_STRING,
						"description": jsii.String("The greeting message"),
					},
				},
			},
		},
	}),
	CredentialProviderConfigurations: []*iCredentialProvider{
		agentcore.GatewayCredentialProvider_IamRole(),
	},
})

// Create an OAuth identity
oauthIdentityArn := "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-oauth123"
oauthSecretArn := "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

schemaBucket := s3.Bucket_FromBucketName(this, jsii.String("SchemaBucket"), jsii.String("my-schema-bucket"))
s3SmithySchema := agentcore.ApiSchema_FromS3File(schemaBucket, jsii.String("schemas/myschema.json"))

// Create a gateway target with Smithy Model and OAuth
target := agentcore.GatewayTarget_ForSmithy(this, jsii.String("MySmithyTarget"), &GatewayTargetSmithyProps{
	GatewayTargetName: jsii.String("my-smithy-target"),
	Description: jsii.String("Target for Smithy model integration"),
	Gateway: gateway,
	SmithyModel: s3SmithySchema,
	CredentialProviderConfigurations: []*iCredentialProvider{
		agentcore.GatewayCredentialProvider_Oauth(&OAuthConfiguration{
			ProviderArn: oauthIdentityArn,
			SecretArn: oauthSecretArn,
			Scopes: []*string{
				jsii.String("read"),
				jsii.String("write"),
			},
			CustomParameters: map[string]*string{
				"audience": jsii.String("https://api.example.com"),
				"response_type": jsii.String("code"),
			},
		}),
	},
})
```

### Snippet 43 (ID: 7d741b0e...)

```go
// Create a gateway and target
gateway := agentcore.NewGateway(this, jsii.String("MyGateway"), &GatewayProps{
	GatewayName: jsii.String("my-gateway"),
	ProtocolConfiguration: agentcore.NewMcpProtocolConfiguration(&McpConfiguration{
		Instructions: jsii.String("Use this gateway to connect to external MCP tools"),
		SearchType: agentcore.McpGatewaySearchType_SEMANTIC,
		SupportedVersions: []mCPProtocolVersion{
			agentcore.*mCPProtocolVersion_MCP_2025_03_26,
		},
	}),
	AuthorizerConfiguration: agentcore.GatewayAuthorizer_UsingCustomJwt(&CustomJwtConfiguration{
		DiscoveryUrl: jsii.String("https://auth.example.com/.well-known/openid-configuration"),
		AllowedAudience: []*string{
			jsii.String("my-app"),
		},
		AllowedClients: []*string{
			jsii.String("my-client-id"),
		},
	}),
})

apiKeyIdentityArn := "arn:aws:bedrock-agentcore:us-east-1:123456789012:token-vault/abc123/apikeycredentialprovider/my-apikey"
apiKeySecretArn := "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-apikey-secret-abc123"

bucket := s3.Bucket_FromBucketName(this, jsii.String("ExistingBucket"), jsii.String("my-schema-bucket"))
s3apiSchema := agentcore.ApiSchema_FromS3File(bucket, jsii.String("schemas/myschema.yaml"))

target := agentcore.GatewayTarget_ForOpenApi(this, jsii.String("MyTarget"), &GatewayTargetOpenApiProps{
	GatewayTargetName: jsii.String("my-target"),
	Gateway: gateway,
	ApiSchema: s3apiSchema,
	CredentialProviderConfigurations: []iCredentialProvider{
		agentcore.GatewayCredentialProvider_ApiKey(&ApiKeyCredentialProviderProps{
			ProviderArn: apiKeyIdentityArn,
			SecretArn: apiKeySecretArn,
			CredentialLocation: agentcore.ApiKeyCredentialLocation_Header(&ApiKeyAdditionalConfiguration{
				CredentialParameterName: jsii.String("X-API-Key"),
			}),
		}),
	},
})

// Create a role that needs access to the gateway target
userRole := iam.NewRole(this, jsii.String("UserRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("lambda.amazonaws.com")),
})

// Grant read permissions (Get and List actions)
target.GrantRead(userRole)

// Grant manage permissions (Create, Update, Delete actions)
target.GrantManage(userRole)

// Grant specific custom permissions
target.Grant(userRole, jsii.String("bedrock-agentcore:GetGatewayTarget"))
```

### Snippet 44 (ID: fde53762...)

```go
// Create a basic code interpreter with public network access
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_code_interpreter"),
	Description: jsii.String("A code interpreter for Python execution"),
})
```

### Snippet 45 (ID: fd30da56...)

```go
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_sandbox_interpreter"),
	Description: jsii.String("Code interpreter with isolated network access"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: ec2.NewVpc(this, jsii.String("VPC"), &VpcProps{
			RestrictDefaultSecurityGroup: jsii.Boolean(false),
		}),
	}),
})
```

### Snippet 46 (ID: 504a5940...)

```go
vpc := ec2.NewVpc(this, jsii.String("testVPC"))

codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_sandbox_interpreter"),
	Description: jsii.String("Code interpreter with isolated network access"),
	NetworkConfiguration: agentcore.BrowserNetworkConfiguration_UsingVpc(this, &VpcConfigProps{
		Vpc: vpc,
	}),
})

codeInterpreter.connections.AddSecurityGroup(ec2.NewSecurityGroup(this, jsii.String("AdditionalGroup"), &SecurityGroupProps{
	Vpc: Vpc,
}))
```

### Snippet 47 (ID: aa6f2dda...)

```go
// Create code interpreter with sandbox network mode (isolated)
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_sandbox_interpreter"),
	Description: jsii.String("Code interpreter with isolated network access"),
	NetworkConfiguration: agentcore.CodeInterpreterNetworkConfiguration_UsingSandboxNetwork(),
})
```

### Snippet 48 (ID: a7071766...)

```go
// Create a custom execution role
executionRole := iam.NewRole(this, jsii.String("CodeInterpreterExecutionRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("bedrock-agentcore.amazonaws.com")),
})

// Create code interpreter with custom execution role
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_code_interpreter"),
	Description: jsii.String("Code interpreter with custom execution role"),
	NetworkConfiguration: agentcore.CodeInterpreterNetworkConfiguration_UsingPublicNetwork(),
	ExecutionRole: executionRole,
})
```

### Snippet 49 (ID: cedd86ae...)

```go
// Create a code interpreter
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_code_interpreter"),
	Description: jsii.String("Code interpreter for Python execution"),
	NetworkConfiguration: agentcore.CodeInterpreterNetworkConfiguration_UsingPublicNetwork(),
})

// Create a role that needs access to the code interpreter
userRole := iam.NewRole(this, jsii.String("UserRole"), &RoleProps{
	AssumedBy: iam.NewServicePrincipal(jsii.String("lambda.amazonaws.com")),
})

// Grant read permissions (Get and List actions)
codeInterpreter.GrantRead(userRole)

// Grant use permissions (Start, Invoke, Stop actions)
codeInterpreter.GrantUse(userRole)

// Grant specific custom permissions
codeInterpreter.Grant(userRole, jsii.String("bedrock-agentcore:GetCodeInterpreterSession"))
```

### Snippet 50 (ID: 65a79060...)

```go
// Create code interpreter with sandbox network mode (isolated)
codeInterpreter := agentcore.NewCodeInterpreterCustom(this, jsii.String("MyCodeInterpreter"), &CodeInterpreterCustomProps{
	CodeInterpreterCustomName: jsii.String("my_sandbox_interpreter"),
	Description: jsii.String("Code interpreter with isolated network access"),
	NetworkConfiguration: agentcore.CodeInterpreterNetworkConfiguration_UsingPublicNetwork(),
	Tags: map[string]*string{
		"Environment": jsii.String("Production"),
		"Team": jsii.String("AI/ML"),
		"Project": jsii.String("AgentCore"),
	},
})
```

### Snippet 51 (ID: cae11061...)

```go
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123"
```

### Snippet 52 (ID: 0471d468...)

```go
"runtime-abc123"
```

### Snippet 53 (ID: 6b4f6935...)

```go
"2024-01-15T10:30:00Z"
```

### Snippet 54 (ID: 379fc387...)

```go
"2024-01-15T14:45:00Z"
```

### Snippet 55 (ID: 7e85b1e8...)

```go
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123"
```

---

