# Developer Guide

AWS AgentCore CDK Constructs are built in TypeScript using Projen (http://projen.io/). This is to support all the associated testing, code checking, and compilation for TypeScript and Python client. At the moment, there is no dedicated development container, thus you need to configure your local development environment following the steps described below.

## Tables of contents

- [Pre-requisites](#pre-requisites)
- [Preparing your Build Environment](#preparing-your-build-environment)
- [Working on Your Construct](#working-on-your-construct)
- [Testing](#testing)
- [Testing Your Construct Locally](#testing-your-construct-locally)
- [Project structure](#project-structure)

### Pre-requisites

- An AWS account. We recommend you deploy this solution in a new account
- [AWS CLI](https://aws.amazon.com/cli/): configure your credentials

```
aws configure --profile [your-profile] 
AWS Access Key ID [None]: xxxxxx
AWS Secret Access Key [None]:yyyyyyyyyy
Default region name [None]: us-east-1 
Default output format [None]: json
```

- [Node](https://nodejs.org/en) >= v20.9.0
- [AWS CDK](https://github.com/aws/aws-cdk/releases/tag/v2.220.0) >= 2.220.0
- [Projen](https://github.com/projen/projen/releases/tag/v0.98.0) >= 0.98.0
- [Yarn](https://classic.yarnpkg.com/lang/en/docs/cli/install/) >= 1.22.19
- [Docker](https://www.docker.com/) >= 27.3.1

You can use the command below to install the dependencies listed above

```
npm install -g npm aws-cdk yarn projen
```

## Preparing your Build Environment

| Action                                                                                                               |                                                                                                                                                                                                                                  |
| :--------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Open the [repository](https://github.com/krokoko/agent-core-cdk-constructs). | As you are reading this file from the repo, you are probably already there.                                                                                                                       |
| Using the "fork" button in the upper right, fork the repo into your GitHub account.                                    | Some git/GitHub expertise is assumed.                                                                            |
| Clone forked repo to your local development environment.                                                              | If you wish to work off a branch in your repository, create and clone that branch. You will create a PR back to `main` in the agent-core-cdk-constructs repository eventually, you can do that from fork/main or fork/*branch* |
| `cd agent-core-cdk-constructs`                                                                        | This is the home directory of the repo and where you will open your text editor, run builds, etc.                                                                                                                           |
| `code .`                                                                                                             | Opens the project in VSCode. You can use the editor of your choice, just adapt this step to your specific use case.                                                                                                              |
| `npx projen install`                                                                                                         | This command will generate project files (dependencies, etc.) from the configuration file and install them.                                                                                                                      |


## Working on Your Construct


| Action                                            | Explanation                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| :-------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| (optional)<br/>`git checkout -b your-branch-name` | If you're working in a different branch than main in your forked repo and haven't changed your local branch, now is a good time to do so.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `mkdir src/cdk-lib/<primitive name>/`                     | Creates a dedicated folder to work on your construct.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `cd src/cdk-lib/<primitive name>/`                         | Change directory to the folder where you want to change code.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| *Do all your code editing*                        | Open your code editor and create the construct or perform your edits on an existing construct. Your construct code must be located in the src folder. Put only the TypeScript files related to your construct in that folder. If you need to bundle additional code, add it to a separate folder in the root folder of this repo (see existing examples, like `lambda`.) Use an existing construct as an example of the structure that is expected. Finally, export your construct in the src/index.ts file.                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `npx projen build`                                | This is the build command for the library. It will build, lint, add license header files, and run the unit and integration tests. If you make any substantive changes to the code, you will almost certainly see some or all of the tests fail. The next section will describe how testing works in AWS AgentCore CDK Constructs and how to write, refresh, and execute tests. In the meantime, you can at least check if your code transpiles correctly without running the tests by running `npm run build`. If you've edited any modules in /core in addition to a construct, be sure to build /core before building your construct. This command also packages the constructs locally to the /dist folder. |

## Testing

AWS AgentCore CDK Constructs use three types of testing: unit testing, integration testing and documentation testing. 

- Unit testing targets specific aspects of a construct or one of the functions in the core library. The unit tests check that certain aspects of the results are correct. You can learn more about unit testing CDK constructs [here](https://docs.aws.amazon.com/cdk/latest/guide/testing.html) and [here](https://aws.amazon.com/blogs/developer/testing-infrastructure-with-the-aws-cloud-development-kit-cdk/).
- Documentation tests are verifying that the code snippets present in the main README file compile. This prevents common issues where documentation examples become outdated or contain errors. For more information, please refer to the [DOCUMENTATION_TESTING](./DOCUMENTATION_TESTING.md) guide.

All test files can be found in the /test directory under each construct (or core). You'll find two types of files in this directory:

* \*.test.ts files - these are the unit test files. All the unit tests for a construct are in a single file.
* integ.\*.ts files - these the integration test files. Each integration test gets a separate file.


| Action            | Explanation                                |
| :------------------ | :------------------------------------------- |
| `npx projen test` | This will run all tests (unit+integration) |

---

## Testing Your Construct Locally

AgentCore CDK constructs are building blocks. To test a deployment, you need to create a CDK application with a stack.

### Pre-requisites

Create a new CDK application or use an existing one. 
To create a new application, you can use [cdk init](https://docs.aws.amazon.com/cdk/v2/guide/ref-cli-cmd-init.html).

For instance:

```bash
cdk init lib --language=typescript
```


### Step 1: Building the AgentCore CDK Constructs

Follow the step above to build the constructs.

### Step 2: Packaging the Constructs

1. Run ```projen package:js```:
    - Execute ```projen package:js```.
      - This command creates a new .tgz package of all constructs in the dist/js folder.
    - If you want to build a package for a different language, please refer to the existing ```projen package:X``` commands after running ```projen --help```

2. Locate the TGZ File:
    - Find the generated .tgz file, typically named something like dist/js/agentcore-cdk-constructs@0.0.0.jsii


### Step 3: Integrating with Sample Application

1. Drag and Drop the TGZ File:
    - Drag and drop the .tgz file into your sample application, ideally at the root like "/mysample".

2. Install the package

```bash
npm i ./agentcore-cdk-constructs@0.0.0.jsii
```

Make sure the package is added to your package.json (under dependencies) and available in node_modules/@krokoko/agentcore-cdk-constructs

Package.json example:

```json
"dependencies": {
    "@krokoko/agentcore-cdk-constructs": "file:agentcore-cdk-constructs@0.0.0.jsii.tgz",
    "aws-cdk-lib": "2.211.0",
    "constructs": "^10.0.0"
  }
```

### Step 4: Deploying to AWS

1. Navigate to Sample Repo Directory:
  - Change directory to your samples repository.
  - Now you can import the constructs from the custom artifact.
2. AWS CDK Deployment:
  - Ensure you are authenticated to AWS with the necessary permissions.
  - Run ```cdk deploy``` to deploy the new backend with your AgentCore constructs into the AWS Cloud.
3. Verify Deployment:
  - Log into your AWS console and verify that the resources have been deployed successfully.
  - Check for any errors in the AWS CloudFormation console and address them as necessary.

### Testing and Verification

- After deployment, you may want to test the functionalities of the agent-core-cdk-constructs in the AWS environment.
- Ensure all integrations and functionalities are working as expected.

## Project structure

```
.
|--API.md (api doc)
|--lib/ (Build output)
|--lambda/ (Lambda custom resources functions code)
|--projenrc (Folder containing utilities for the main projenrc file)
|--src/ (Source .ts files)
    |--cdk-lib/
        |--bedrock-agentcore
            |-- each folder contains the implementation of the primitives
    |--index.ts (Constructs need to be exported from this index.ts file)
|--test/
    |--cdk-lib/ (unit tests)
        |-- each folder contains tests related to the specific primitive
            |-- *.test.ts (Helper source file)
    |--integ/ (integration tests)
        |--*.integ.ts (construct test files)
```


&copy; Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
