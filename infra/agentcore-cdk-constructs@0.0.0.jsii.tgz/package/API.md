# API Reference <a name="API Reference" id="api-reference"></a>

## Constructs <a name="Constructs" id="Constructs"></a>

### BrowserCustom <a name="BrowserCustom" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom"></a>

Browser resource for AWS Bedrock Agent Core.

Provides a browser environment for web automation and interaction.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/browser.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/browser.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.BrowserCustom(scope: Construct, id: string, props: BrowserCustomProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantRead">grantRead</a></code> | Grant read permissions on this browser to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantUse">grantUse</a></code> | Grant invoke permissions on this browser to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metric">metric</a></code> | Return the given named metric for this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricForApiOperation">metricForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser api operations.. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser invocations. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser latencies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSessionDuration">metricSessionDuration</a></code> | Creates a CloudWatch metric for tracking browser session duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser system errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverCount">metricTakeOverCount</a></code> | Creates a CloudWatch metric for tracking browser user takeovers. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverDuration">metricTakeOverDuration</a></code> | Creates a CloudWatch metric for tracking browser user takeovers duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverReleaseCount">metricTakeOverReleaseCount</a></code> | Creates a CloudWatch metric for tracking browser user takeovers released. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser throttles. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser user errors. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant read permissions on this browser to an IAM principal.

This includes both read permissions on the specific browser and list permissions on all browsers.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grant invoke permissions on this browser to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this browser.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser api operations..

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser invocations.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser latencies.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser session duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser system errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverCount` <a name="metricTakeOverCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverCount"></a>

```typescript
public metricTakeOverCount(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverDuration` <a name="metricTakeOverDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverDuration"></a>

```typescript
public metricTakeOverDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverReleaseCount` <a name="metricTakeOverReleaseCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverReleaseCount"></a>

```typescript
public metricTakeOverReleaseCount(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers released.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricTakeOverReleaseCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser throttles.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes">fromBrowserCustomAttributes</a></code> | Creates an Browser Custom reference from an existing browser's attributes. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustom.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustom.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustom.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromBrowserCustomAttributes` <a name="fromBrowserCustomAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes(scope: Construct, id: string, attrs: BrowserCustomAttributes)
```

Creates an Browser Custom reference from an existing browser's attributes.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes.parameter.id"></a>

- *Type:* string

Identifier of the construct.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.fromBrowserCustomAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes

Attributes of the existing browser custom.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.browserArn">browserArn</a></code> | <code>string</code> | The ARN of the browser resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.browserId">browserId</a></code> | <code>string</code> | The id of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Browser does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role associated to the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The last updated timestamp of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.status">status</a></code> | <code>string</code> | The status of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.name">name</a></code> | <code>string</code> | The name of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.networkConfiguration">networkConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration</code> | The network configuration of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.description">description</a></code> | <code>string</code> | The description of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.failureReason">failureReason</a></code> | <code>string</code> | The failure reason of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.recordingConfig">recordingConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig</code> | The recording configuration of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags applied to this browser resource A map of key-value pairs for resource tagging. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `browserArn`<sup>Required</sup> <a name="browserArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.browserArn"></a>

```typescript
public readonly browserArn: string;
```

- *Type:* string

The ARN of the browser resource.

---

##### `browserId`<sup>Required</sup> <a name="browserId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.browserId"></a>

```typescript
public readonly browserId: string;
```

- *Type:* string

The id of the browser.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Browser does not have a VPC configured.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role associated to the browser.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The created timestamp of the browser.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

The last updated timestamp of the browser.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the browser.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the browser.

---

##### `networkConfiguration`<sup>Required</sup> <a name="networkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.networkConfiguration"></a>

```typescript
public readonly networkConfiguration: BrowserNetworkConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration

The network configuration of the browser.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the browser.

---

##### `failureReason`<sup>Optional</sup> <a name="failureReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.failureReason"></a>

```typescript
public readonly failureReason: string;
```

- *Type:* string

The failure reason of the browser.

---

##### `recordingConfig`<sup>Optional</sup> <a name="recordingConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.recordingConfig"></a>

```typescript
public readonly recordingConfig: RecordingConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig

The recording configuration of the browser.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No tags applied

Tags applied to this browser resource A map of key-value pairs for resource tagging.

---


### BrowserCustomBase <a name="BrowserCustomBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom

Abstract base class for a Browser.

Contains methods and attributes valid for Browsers either created with CDK or imported.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.BrowserCustomBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantRead">grantRead</a></code> | Grant read permissions on this browser to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantUse">grantUse</a></code> | Grant invoke permissions on this browser to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metric">metric</a></code> | Return the given named metric for this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricForApiOperation">metricForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser api operations.. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser invocations. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser latencies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSessionDuration">metricSessionDuration</a></code> | Creates a CloudWatch metric for tracking browser session duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser system errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverCount">metricTakeOverCount</a></code> | Creates a CloudWatch metric for tracking browser user takeovers. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverDuration">metricTakeOverDuration</a></code> | Creates a CloudWatch metric for tracking browser user takeovers duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverReleaseCount">metricTakeOverReleaseCount</a></code> | Creates a CloudWatch metric for tracking browser user takeovers released. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser throttles. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking browser user errors. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant read permissions on this browser to an IAM principal.

This includes both read permissions on the specific browser and list permissions on all browsers.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grant invoke permissions on this browser to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this browser.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser api operations..

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser invocations.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser latencies.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser session duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser system errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverCount` <a name="metricTakeOverCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverCount"></a>

```typescript
public metricTakeOverCount(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverDuration` <a name="metricTakeOverDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverDuration"></a>

```typescript
public metricTakeOverDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricTakeOverReleaseCount` <a name="metricTakeOverReleaseCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverReleaseCount"></a>

```typescript
public metricTakeOverReleaseCount(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user takeovers released.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricTakeOverReleaseCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser throttles.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking browser user errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustomBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustomBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserCustomBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.browserArn">browserArn</a></code> | <code>string</code> | The ARN of the browser resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.browserId">browserId</a></code> | <code>string</code> | The id of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Browser does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the browser to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the browser was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | Timestamp when the browser was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.status">status</a></code> | <code>string</code> | The status of the browser. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `browserArn`<sup>Required</sup> <a name="browserArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.browserArn"></a>

```typescript
public readonly browserArn: string;
```

- *Type:* string

The ARN of the browser resource.

---

##### `browserId`<sup>Required</sup> <a name="browserId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.browserId"></a>

```typescript
public readonly browserId: string;
```

- *Type:* string

The id of the browser.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Browser does not have a VPC configured.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the browser to access AWS services.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the browser was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

Timestamp when the browser was last updated.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the browser.

---


### CodeInterpreterCustom <a name="CodeInterpreterCustom" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom"></a>

Custom code interpreter resource for AWS Bedrock Agent Core.

Provides a sandboxed environment for code execution with configurable network access.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.CodeInterpreterCustom(scope: Construct, id: string, props: CodeInterpreterCustomProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantInvoke">grantInvoke</a></code> | Grant invoke permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantRead">grantRead</a></code> | Grant read permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantUse">grantUse</a></code> | Grant invoke permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metric">metric</a></code> | Return the given named metric for this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricForApiOperation">metricForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter api operations.. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter invocations. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter latencies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSessionDuration">metricSessionDuration</a></code> | Creates a CloudWatch metric for tracking code interpreter session duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter system errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter throttles. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter user errors. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Grant invoke permissions on this code interpreter to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant read permissions on this code interpreter to an IAM principal.

This includes both read permissions on the specific code interpreter and list permissions on all code interpreters.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grant invoke permissions on this code interpreter to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this code interpreter.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter api operations..

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter invocations.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter latencies.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter session duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter system errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter throttles.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter user errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes">fromCodeInterpreterCustomAttributes</a></code> | Creates an Code Interpreter Custom reference from an existing code interpreter's attributes. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustom.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustom.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustom.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromCodeInterpreterCustomAttributes` <a name="fromCodeInterpreterCustomAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes(scope: Construct, id: string, attrs: CodeInterpreterCustomAttributes)
```

Creates an Code Interpreter Custom reference from an existing code interpreter's attributes.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes.parameter.id"></a>

- *Type:* string

Identifier of the construct.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.fromCodeInterpreterCustomAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes

Attributes of the existing code interpreter custom.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.codeInterpreterArn">codeInterpreterArn</a></code> | <code>string</code> | The ARN of the code interpreter resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.codeInterpreterId">codeInterpreterId</a></code> | <code>string</code> | The id of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Browser does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the code interpreter to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The last updated timestamp of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.status">status</a></code> | <code>string</code> | The status of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.name">name</a></code> | <code>string</code> | The name of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.networkConfiguration">networkConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration</code> | The network configuration of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.description">description</a></code> | <code>string</code> | The description of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.failureReason">failureReason</a></code> | <code>string</code> | The failure reason of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags applied to this code interpreter resource A map of key-value pairs for resource tagging. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `codeInterpreterArn`<sup>Required</sup> <a name="codeInterpreterArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.codeInterpreterArn"></a>

```typescript
public readonly codeInterpreterArn: string;
```

- *Type:* string

The ARN of the code interpreter resource.

---

##### `codeInterpreterId`<sup>Required</sup> <a name="codeInterpreterId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.codeInterpreterId"></a>

```typescript
public readonly codeInterpreterId: string;
```

- *Type:* string

The id of the code interpreter.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Browser does not have a VPC configured.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the code interpreter to access AWS services.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The created timestamp of the code interpreter.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

The last updated timestamp of the code interpreter.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the code interpreter.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the code interpreter.

---

##### `networkConfiguration`<sup>Required</sup> <a name="networkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.networkConfiguration"></a>

```typescript
public readonly networkConfiguration: CodeInterpreterNetworkConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration

The network configuration of the code interpreter.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the code interpreter.

---

##### `failureReason`<sup>Optional</sup> <a name="failureReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.failureReason"></a>

```typescript
public readonly failureReason: string;
```

- *Type:* string

The failure reason of the code interpreter.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No tags applied

Tags applied to this code interpreter resource A map of key-value pairs for resource tagging.

---


### CodeInterpreterCustomBase <a name="CodeInterpreterCustomBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom

Abstract base class for a Code Interpreter.

Contains methods and attributes valid for Code Interpreters either created with CDK or imported.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.CodeInterpreterCustomBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantInvoke">grantInvoke</a></code> | Grant invoke permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantRead">grantRead</a></code> | Grant read permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantUse">grantUse</a></code> | Grant invoke permissions on this code interpreter to an IAM principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metric">metric</a></code> | Return the given named metric for this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricForApiOperation">metricForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter api operations.. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter invocations. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter latencies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSessionDuration">metricSessionDuration</a></code> | Creates a CloudWatch metric for tracking code interpreter session duration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter system errors. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter throttles. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Creates a CloudWatch metric for tracking code interpreter user errors. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Grant invoke permissions on this code interpreter to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant read permissions on this code interpreter to an IAM principal.

This includes both read permissions on the specific code interpreter and list permissions on all code interpreters.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grant invoke permissions on this code interpreter to an IAM principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant invoke permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this code interpreter.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter api operations..

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter invocations.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter latencies.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter session duration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter system errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter throttles.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Creates a CloudWatch metric for tracking code interpreter user errors.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

Configuration options for the metric.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustomBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustomBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterCustomBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.codeInterpreterArn">codeInterpreterArn</a></code> | <code>string</code> | The ARN of the code interpreter resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.codeInterpreterId">codeInterpreterId</a></code> | <code>string</code> | The id of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Browser does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the code interpreter to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the code interpreter was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | Timestamp when the code interpreter was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.status">status</a></code> | <code>string</code> | The status of the code interpreter. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `codeInterpreterArn`<sup>Required</sup> <a name="codeInterpreterArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.codeInterpreterArn"></a>

```typescript
public readonly codeInterpreterArn: string;
```

- *Type:* string

The ARN of the code interpreter resource.

---

##### `codeInterpreterId`<sup>Required</sup> <a name="codeInterpreterId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.codeInterpreterId"></a>

```typescript
public readonly codeInterpreterId: string;
```

- *Type:* string

The id of the code interpreter.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Browser does not have a VPC configured.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the code interpreter to access AWS services.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the code interpreter was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

Timestamp when the code interpreter was last updated.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the code interpreter.

---


### Gateway <a name="Gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway"></a>

Gateway resource for AWS Bedrock Agent Core.

Serves as an integration point between your agent and external services.

> [https://docs.aws.amazon.com/bedrock-agentcore-control/latest/APIReference/API_CreateGateway.html](https://docs.aws.amazon.com/bedrock-agentcore-control/latest/APIReference/API_CreateGateway.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.Gateway(scope: Construct, id: string, props: GatewayProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantInvoke">grantInvoke</a></code> | Grants permission to invoke this Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metric">metric</a></code> | Return the given named metric for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricDuration">metricDuration</a></code> | Return a metric measuring the duration of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors (5xx status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetExecutionTime">metricTargetExecutionTime</a></code> | Return a metric measuring the target execution time for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetType">metricTargetType</a></code> | Return a metric containing the number of requests served by each target type for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests (429 status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addLambdaTarget">addLambdaTarget</a></code> | Add a Lambda target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addOpenApiTarget">addOpenApiTarget</a></code> | Add an OpenAPI target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addSmithyTarget">addSmithyTarget</a></code> | Add a Smithy target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Grants permission to invoke this Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this gateway.

*
By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricDuration` <a name="metricDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricDuration"></a>

```typescript
public metricDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of requests for this gateway.

The duration metric represents the total time elapsed between receiving the request
and sending the final response token, representing complete end-to-end processing time.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this gateway.

The latency metric represents the time elapsed between when the service receives
the request and when it begins sending the first response token.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors (5xx status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetExecutionTime` <a name="metricTargetExecutionTime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetExecutionTime"></a>

```typescript
public metricTargetExecutionTime(props?: MetricOptions): Metric
```

Return a metric measuring the target execution time for this gateway.

This metric helps determine the contribution of the target (Lambda, OpenAPI, etc.)
to the total latency.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetExecutionTime.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetType` <a name="metricTargetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetType"></a>

```typescript
public metricTargetType(targetType: string, props?: MetricOptions): Metric
```

Return a metric containing the number of requests served by each target type for this gateway.

###### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetType.parameter.targetType"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricTargetType.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests (429 status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `addLambdaTarget` <a name="addLambdaTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addLambdaTarget"></a>

```typescript
public addLambdaTarget(id: string, props: AddLambdaTargetOptions): GatewayTarget
```

Add a Lambda target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway.

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addLambdaTarget.parameter.id"></a>

- *Type:* string

The construct id for the target.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addLambdaTarget.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions

Properties for the Lambda target.

---

##### `addOpenApiTarget` <a name="addOpenApiTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addOpenApiTarget"></a>

```typescript
public addOpenApiTarget(id: string, props: AddOpenApiTargetOptions): GatewayTarget
```

Add an OpenAPI target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway.

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addOpenApiTarget.parameter.id"></a>

- *Type:* string

The construct id for the target.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addOpenApiTarget.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions

Properties for the OpenAPI target.

---

##### `addSmithyTarget` <a name="addSmithyTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addSmithyTarget"></a>

```typescript
public addSmithyTarget(id: string, props: AddSmithyTargetOptions): GatewayTarget
```

Add a Smithy target to this gateway This is a convenience method that creates a GatewayTarget associated with this gateway.

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addSmithyTarget.parameter.id"></a>

- *Type:* string

The construct id for the target.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.addSmithyTarget.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions

Properties for the Smithy target.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayArn">fromGatewayArn</a></code> | Import an existing Gateway using its ARN. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayAttributes">fromGatewayAttributes</a></code> | Import an existing Gateway using its attributes. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Gateway.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Gateway.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Gateway.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromGatewayArn` <a name="fromGatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayArn"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Gateway.fromGatewayArn(scope: Construct, id: string, gatewayArn: string)
```

Import an existing Gateway using its ARN.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayArn.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayArn.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `gatewayArn`<sup>Required</sup> <a name="gatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayArn.parameter.gatewayArn"></a>

- *Type:* string

The ARN of the existing Gateway.

---

##### `fromGatewayAttributes` <a name="fromGatewayAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Gateway.fromGatewayAttributes(scope: Construct, id: string, attrs: GatewayAttributes)
```

Import an existing Gateway using its attributes.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayAttributes.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.fromGatewayAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes

The attributes of the existing Gateway.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.authorizerConfiguration">authorizerConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer</code> | The authorizer configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayArn">gatewayArn</a></code> | <code>string</code> | The ARN of the gateway resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayId">gatewayId</a></code> | <code>string</code> | The id of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.name">name</a></code> | <code>string</code> | The name of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.protocolConfiguration">protocolConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol</code> | The protocol configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.description">description</a></code> | <code>string</code> | The description of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.exceptionLevel">exceptionLevel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel</code> | The exception level for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayUrl">gatewayUrl</a></code> | <code>string</code> | The URL endpoint for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | The KMS key used for encryption. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.status">status</a></code> | <code>string</code> | The status of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.statusReason">statusReason</a></code> | <code>string[]</code> | The status reasons for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags applied to the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.userPool">userPool</a></code> | <code>aws-cdk-lib.aws_cognito.IUserPool</code> | The Cognito User Pool created for the gateway (if using default Cognito authorizer). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.userPoolClient">userPoolClient</a></code> | <code>aws-cdk-lib.aws_cognito.IUserPoolClient</code> | The Cognito User Pool Client created for the gateway (if using default Cognito authorizer). |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `authorizerConfiguration`<sup>Required</sup> <a name="authorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.authorizerConfiguration"></a>

```typescript
public readonly authorizerConfiguration: IGatewayAuthorizer;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

The authorizer configuration for the gateway.

---

##### `gatewayArn`<sup>Required</sup> <a name="gatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayArn"></a>

```typescript
public readonly gatewayArn: string;
```

- *Type:* string

The ARN of the gateway resource.

---

##### `gatewayId`<sup>Required</sup> <a name="gatewayId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayId"></a>

```typescript
public readonly gatewayId: string;
```

- *Type:* string

The id of the gateway.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway.

---

##### `protocolConfiguration`<sup>Required</sup> <a name="protocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.protocolConfiguration"></a>

```typescript
public readonly protocolConfiguration: IGatewayProtocol;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol

The protocol configuration for the gateway.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role for the gateway.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway.

---

##### `exceptionLevel`<sup>Optional</sup> <a name="exceptionLevel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.exceptionLevel"></a>

```typescript
public readonly exceptionLevel: GatewayExceptionLevel;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel

The exception level for the gateway.

---

##### `gatewayUrl`<sup>Optional</sup> <a name="gatewayUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.gatewayUrl"></a>

```typescript
public readonly gatewayUrl: string;
```

- *Type:* string

The URL endpoint for the gateway.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

The KMS key used for encryption.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway.

---

##### `statusReason`<sup>Optional</sup> <a name="statusReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.statusReason"></a>

```typescript
public readonly statusReason: string[];
```

- *Type:* string[]

The status reasons for the gateway.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway was last updated.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}

Tags applied to the gateway.

---

##### `userPool`<sup>Optional</sup> <a name="userPool" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.userPool"></a>

```typescript
public readonly userPool: IUserPool;
```

- *Type:* aws-cdk-lib.aws_cognito.IUserPool

The Cognito User Pool created for the gateway (if using default Cognito authorizer).

---

##### `userPoolClient`<sup>Optional</sup> <a name="userPoolClient" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway.property.userPoolClient"></a>

```typescript
public readonly userPoolClient: IUserPoolClient;
```

- *Type:* aws-cdk-lib.aws_cognito.IUserPoolClient

The Cognito User Pool Client created for the gateway (if using default Cognito authorizer).

---


### GatewayBase <a name="GatewayBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

****************************************************************************                               Base Class ***************************************************************************.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantInvoke">grantInvoke</a></code> | Grants permission to invoke this Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metric">metric</a></code> | Return the given named metric for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricDuration">metricDuration</a></code> | Return a metric measuring the duration of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors (5xx status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetExecutionTime">metricTargetExecutionTime</a></code> | Return a metric measuring the target execution time for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetType">metricTargetType</a></code> | Return a metric containing the number of requests served by each target type for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests (429 status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Grants permission to invoke this Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this gateway.

*
By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricDuration` <a name="metricDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricDuration"></a>

```typescript
public metricDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of requests for this gateway.

The duration metric represents the total time elapsed between receiving the request
and sending the final response token, representing complete end-to-end processing time.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this gateway.

The latency metric represents the time elapsed between when the service receives
the request and when it begins sending the first response token.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors (5xx status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetExecutionTime` <a name="metricTargetExecutionTime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetExecutionTime"></a>

```typescript
public metricTargetExecutionTime(props?: MetricOptions): Metric
```

Return a metric measuring the target execution time for this gateway.

This metric helps determine the contribution of the target (Lambda, OpenAPI, etc.)
to the total latency.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetExecutionTime.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetType` <a name="metricTargetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetType"></a>

```typescript
public metricTargetType(targetType: string, props?: MetricOptions): Metric
```

Return a metric containing the number of requests served by each target type for this gateway.

###### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetType.parameter.targetType"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricTargetType.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests (429 status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.authorizerConfiguration">authorizerConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer</code> | The authorizer configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayArn">gatewayArn</a></code> | <code>string</code> | The ARN of the gateway resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayId">gatewayId</a></code> | <code>string</code> | The id of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.name">name</a></code> | <code>string</code> | The name of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.protocolConfiguration">protocolConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol</code> | The protocol configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the gateway to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.description">description</a></code> | <code>string</code> | The description of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.exceptionLevel">exceptionLevel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel</code> | The exception level for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayUrl">gatewayUrl</a></code> | <code>string</code> | The URL endpoint for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | The KMS key used for encryption. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.status">status</a></code> | <code>string</code> | The status of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.statusReason">statusReason</a></code> | <code>string[]</code> | The status reasons for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `authorizerConfiguration`<sup>Required</sup> <a name="authorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.authorizerConfiguration"></a>

```typescript
public readonly authorizerConfiguration: IGatewayAuthorizer;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

The authorizer configuration for the gateway.

---

##### `gatewayArn`<sup>Required</sup> <a name="gatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayArn"></a>

```typescript
public readonly gatewayArn: string;
```

- *Type:* string

The ARN of the gateway resource.

---

##### `gatewayId`<sup>Required</sup> <a name="gatewayId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayId"></a>

```typescript
public readonly gatewayId: string;
```

- *Type:* string

The id of the gateway.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway.

---

##### `protocolConfiguration`<sup>Required</sup> <a name="protocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.protocolConfiguration"></a>

```typescript
public readonly protocolConfiguration: IGatewayProtocol;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol

The protocol configuration for the gateway.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the gateway to access AWS services.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway.

---

##### `exceptionLevel`<sup>Optional</sup> <a name="exceptionLevel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.exceptionLevel"></a>

```typescript
public readonly exceptionLevel: GatewayExceptionLevel;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel

The exception level for the gateway.

---

##### `gatewayUrl`<sup>Optional</sup> <a name="gatewayUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.gatewayUrl"></a>

```typescript
public readonly gatewayUrl: string;
```

- *Type:* string

The URL endpoint for the gateway.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

The KMS key used for encryption.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway.

---

##### `statusReason`<sup>Optional</sup> <a name="statusReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.statusReason"></a>

```typescript
public readonly statusReason: string[];
```

- *Type:* string[]

The status reasons for the gateway.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway was last updated.

---


### GatewayTarget <a name="GatewayTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget

Defines tools that your gateway will host.

Supports multiple target types:
- Lambda: Wraps a Lambda function as MCP tools
- OpenAPI: Exposes an OpenAPI/REST API as MCP tools
- Smithy: Exposes a Smithy-modeled API as MCP tools

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-building-adding-targets.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-building-adding-targets.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayTarget(scope: Construct, id: string, props: GatewayTargetProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway Target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway Target. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forLambda">forLambda</a></code> | Create a Lambda-based MCP target Convenience method for creating a target that wraps a Lambda function. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forOpenApi">forOpenApi</a></code> | Create an OpenAPI-based MCP target Convenience method for creating a target that exposes an OpenAPI/REST API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forSmithy">forSmithy</a></code> | Create a Smithy-based MCP target Convenience method for creating a target that exposes a Smithy-modeled API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes">fromGatewayTargetAttributes</a></code> | Import an existing Gateway Target using its attributes This allows you to reference a Gateway Target that was created outside of CDK. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `forLambda` <a name="forLambda" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forLambda"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.forLambda(scope: Construct, id: string, props: GatewayTargetLambdaProps)
```

Create a Lambda-based MCP target Convenience method for creating a target that wraps a Lambda function.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forLambda.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forLambda.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forLambda.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps

The properties for the Lambda target.

---

##### `forOpenApi` <a name="forOpenApi" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forOpenApi"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.forOpenApi(scope: Construct, id: string, props: GatewayTargetOpenApiProps)
```

Create an OpenAPI-based MCP target Convenience method for creating a target that exposes an OpenAPI/REST API.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forOpenApi.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forOpenApi.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forOpenApi.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps

The properties for the OpenAPI target.

---

##### `forSmithy` <a name="forSmithy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forSmithy"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.forSmithy(scope: Construct, id: string, props: GatewayTargetSmithyProps)
```

Create a Smithy-based MCP target Convenience method for creating a target that exposes a Smithy-modeled API.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forSmithy.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forSmithy.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.forSmithy.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps

The properties for the Smithy target.

---

##### `fromGatewayTargetAttributes` <a name="fromGatewayTargetAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes(scope: Construct, id: string, attrs: GatewayTargetAttributes)
```

Import an existing Gateway Target using its attributes This allows you to reference a Gateway Target that was created outside of CDK.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.fromGatewayTargetAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes

The attributes of the existing Gateway Target.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | The credential providers for this target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.name">name</a></code> | <code>string</code> | The name of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetArn">targetArn</a></code> | <code>string</code> | The ARN of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetId">targetId</a></code> | <code>string</code> | The unique identifier of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetProtocolType">targetProtocolType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType</code> | The protocol type (always MCP for now). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway target was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.status">status</a></code> | <code>string</code> | The status of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.statusReasons">statusReasons</a></code> | <code>string[]</code> | The status reasons for the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway target was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The specific MCP target type (Lambda, OpenAPI, or Smithy). |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `credentialProviderConfigurations`<sup>Required</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]

The credential providers for this target.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway target.

---

##### `targetArn`<sup>Required</sup> <a name="targetArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetArn"></a>

```typescript
public readonly targetArn: string;
```

- *Type:* string

The ARN of the gateway target.

---

##### `targetId`<sup>Required</sup> <a name="targetId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetId"></a>

```typescript
public readonly targetId: string;
```

- *Type:* string

The unique identifier of the gateway target.

---

##### `targetProtocolType`<sup>Required</sup> <a name="targetProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetProtocolType"></a>

```typescript
public readonly targetProtocolType: GatewayTargetProtocolType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType

The protocol type (always MCP for now).

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway target was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

Optional description for the gateway target.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway target.

---

##### `statusReasons`<sup>Optional</sup> <a name="statusReasons" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.statusReasons"></a>

```typescript
public readonly statusReasons: string[];
```

- *Type:* string[]

The status reasons for the gateway target.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway target was last updated.

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The specific MCP target type (Lambda, OpenAPI, or Smithy).

---


### GatewayTargetBase <a name="GatewayTargetBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget

****************************************************************************                               Base Class ***************************************************************************.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayTargetBase(scope: Construct, id: string, props?: ResourceProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.props">props</a></code> | <code>aws-cdk-lib.ResourceProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.Initializer.parameter.props"></a>

- *Type:* aws-cdk-lib.ResourceProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway Target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway Target. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTargetBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTargetBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayTargetBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | The credential provider configuration for the target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway that this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.name">name</a></code> | <code>string</code> | The name of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetArn">targetArn</a></code> | <code>string</code> | The ARN of the gateway target resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetId">targetId</a></code> | <code>string</code> | The id of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetProtocolType">targetProtocolType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType</code> | The target protocol. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway target was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.description">description</a></code> | <code>string</code> | The description of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.status">status</a></code> | <code>string</code> | The status of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.statusReasons">statusReasons</a></code> | <code>string[]</code> | The status reasons for the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway target was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `credentialProviderConfigurations`<sup>Required</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]

The credential provider configuration for the target.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that this target belongs to.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway target.

---

##### `targetArn`<sup>Required</sup> <a name="targetArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetArn"></a>

```typescript
public readonly targetArn: string;
```

- *Type:* string

The ARN of the gateway target resource.

---

##### `targetId`<sup>Required</sup> <a name="targetId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetId"></a>

```typescript
public readonly targetId: string;
```

- *Type:* string

The id of the gateway target.

---

##### `targetProtocolType`<sup>Required</sup> <a name="targetProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.targetProtocolType"></a>

```typescript
public readonly targetProtocolType: GatewayTargetProtocolType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType

The target protocol.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway target was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway target.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway target.

---

##### `statusReasons`<sup>Optional</sup> <a name="statusReasons" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.statusReasons"></a>

```typescript
public readonly statusReasons: string[];
```

- *Type:* string[]

The status reasons for the gateway target.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway target was last updated.

---


### Memory <a name="Memory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory"></a>

Long-term memory store for extracted insights like user preferences, semantic facts and summaries.

Enables knowledge retention across sessions by storing user preferences (e.g. coding style),
semantic facts (e.g. learned info) and interaction summaries for context optimization.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.Memory(scope: Construct, id: string, props: MemoryProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantAdmin">grantAdmin</a></code> | Grant the given principal identity permissions to manage the control plane of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDelete">grantDelete</a></code> | Grant the given principal identity permissions to delete content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteLongTermMemory">grantDeleteLongTermMemory</a></code> | Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteShortTermMemory">grantDeleteShortTermMemory</a></code> | Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantFullAccess">grantFullAccess</a></code> | Grant the given principal identity permissions to do every action on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantRead">grantRead</a></code> | Grant the given principal identity permissions to read the contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadLongTermMemory">grantReadLongTermMemory</a></code> | Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadShortTermMemory">grantReadShortTermMemory</a></code> | Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantWrite">grantWrite</a></code> | Grant the given principal identity permissions to write content to short-term memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metric">metric</a></code> | Return the given named metric for this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Return a metric containing the number of errors for a specific API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricEventCreationCount">metricEventCreationCount</a></code> | Returns the metric containing the number of short-term memory events. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricForApiOperation">metricForApiOperation</a></code> | Return the given named metric related to the API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Return a metric containing the total number of API requests made for a specific memory operation like `CreateEvent`, `ListEvents`, `RetrieveMemoryRecords` ... |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Return a metric measuring the latency of a specific API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricMemoryRecordCreationCount">metricMemoryRecordCreationCount</a></code> | Returns the metric containing the number of long-term memory records created by the long-term extraction strategies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.addMemoryStrategy">addMemoryStrategy</a></code> | Add memory strategy to the memory. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantAdmin` <a name="grantAdmin" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantAdmin"></a>

```typescript
public grantAdmin(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to manage the control plane of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantAdmin.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant admin permissions to.

---

##### `grantDelete` <a name="grantDelete" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDelete"></a>

```typescript
public grantDelete(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete content on this memory.

Both Short-Term Memory (STM) and Long-Term Memory (LTM).

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDelete.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantDeleteLongTermMemory` <a name="grantDeleteLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteLongTermMemory"></a>

```typescript
public grantDeleteLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantDeleteShortTermMemory` <a name="grantDeleteShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteShortTermMemory"></a>

```typescript
public grantDeleteShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantDeleteShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantFullAccess` <a name="grantFullAccess" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantFullAccess"></a>

```typescript
public grantFullAccess(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to do every action on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantFullAccess.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant full access permissions to.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the contents of this memory.

Both Short-Term Memory (STM) and Long-Term Memory (LTM).

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantReadLongTermMemory` <a name="grantReadLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadLongTermMemory"></a>

```typescript
public grantReadLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantReadShortTermMemory` <a name="grantReadShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadShortTermMemory"></a>

```typescript
public grantReadShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantReadShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantWrite` <a name="grantWrite" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantWrite"></a>

```typescript
public grantWrite(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to write content to short-term memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.grantWrite.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this memory.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of errors for a specific API operation performed on this memory.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricEventCreationCount` <a name="metricEventCreationCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricEventCreationCount"></a>

```typescript
public metricEventCreationCount(props?: MetricOptions): Metric
```

Returns the metric containing the number of short-term memory events.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricEventCreationCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Return the given named metric related to the API operation performed on this memory.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the total number of API requests made for a specific memory operation like `CreateEvent`, `ListEvents`, `RetrieveMemoryRecords` ...

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric measuring the latency of a specific API operation performed on this memory.

The latency metric represents the total time elapsed between receiving the request and sending
the final response token, measuring complete end-to-end processing time.

For memory creation events specifically, this measures the time from the last CreateEvent
that met strategy criteria until memory storage is completed.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricMemoryRecordCreationCount` <a name="metricMemoryRecordCreationCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricMemoryRecordCreationCount"></a>

```typescript
public metricMemoryRecordCreationCount(props?: MetricOptions): Metric
```

Returns the metric containing the number of long-term memory records created by the long-term extraction strategies.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.metricMemoryRecordCreationCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `addMemoryStrategy` <a name="addMemoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.addMemoryStrategy"></a>

```typescript
public addMemoryStrategy(memoryStrategy: IMemoryStrategy): void
```

Add memory strategy to the memory.

###### `memoryStrategy`<sup>Required</sup> <a name="memoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.addMemoryStrategy.parameter.memoryStrategy"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.fromMemoryAttributes">fromMemoryAttributes</a></code> | Creates an Memory reference from an existing memory's attributes. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Memory.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Memory.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Memory.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromMemoryAttributes` <a name="fromMemoryAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.fromMemoryAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Memory.fromMemoryAttributes(scope: Construct, id: string, attrs: MemoryAttributes)
```

Creates an Memory reference from an existing memory's attributes.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.fromMemoryAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.fromMemoryAttributes.parameter.id"></a>

- *Type:* string

Identifier of the construct.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.fromMemoryAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes

Attributes of the existing browser custom.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryArn">memoryArn</a></code> | <code>string</code> | The ARN of the memory resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryId">memoryId</a></code> | <code>string</code> | The id of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The execution role of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | The KMS key used to encrypt the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.status">status</a></code> | <code>string</code> | The status of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.updatedAt">updatedAt</a></code> | <code>string</code> | The updated at timestamp of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryName">memoryName</a></code> | <code>string</code> | The name of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryStrategies">memoryStrategies</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy[]</code> | The memory strategies used by the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.description">description</a></code> | <code>string</code> | The description of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.expirationDuration">expirationDuration</a></code> | <code>aws-cdk-lib.Duration</code> | The expiration days of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.failureReason">failureReason</a></code> | <code>string</code> | The failure reason of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags applied to this browser resource A map of key-value pairs for resource tagging. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `memoryArn`<sup>Required</sup> <a name="memoryArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryArn"></a>

```typescript
public readonly memoryArn: string;
```

- *Type:* string

The ARN of the memory resource.

---

##### `memoryId`<sup>Required</sup> <a name="memoryId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryId"></a>

```typescript
public readonly memoryId: string;
```

- *Type:* string

The id of the memory.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The created timestamp of the memory.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The execution role of the memory.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

The KMS key used to encrypt the memory.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the memory.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

The updated at timestamp of the memory.

---

##### `memoryName`<sup>Required</sup> <a name="memoryName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryName"></a>

```typescript
public readonly memoryName: string;
```

- *Type:* string

The name of the memory.

---

##### `memoryStrategies`<sup>Required</sup> <a name="memoryStrategies" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.memoryStrategies"></a>

```typescript
public readonly memoryStrategies: IMemoryStrategy[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy[]

The memory strategies used by the memory.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the memory.

---

##### `expirationDuration`<sup>Optional</sup> <a name="expirationDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.expirationDuration"></a>

```typescript
public readonly expirationDuration: Duration;
```

- *Type:* aws-cdk-lib.Duration

The expiration days of the memory.

---

##### `failureReason`<sup>Optional</sup> <a name="failureReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.failureReason"></a>

```typescript
public readonly failureReason: string;
```

- *Type:* string

The failure reason of the browser.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No tags applied

Tags applied to this browser resource A map of key-value pairs for resource tagging.

---


### MemoryBase <a name="MemoryBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory

Abstract base class for a Memory.

Contains methods and attributes valid for Memories either created with CDK or imported.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.MemoryBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantAdmin">grantAdmin</a></code> | Grant the given principal identity permissions to manage the control plane of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDelete">grantDelete</a></code> | Grant the given principal identity permissions to delete content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteLongTermMemory">grantDeleteLongTermMemory</a></code> | Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteShortTermMemory">grantDeleteShortTermMemory</a></code> | Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantFullAccess">grantFullAccess</a></code> | Grant the given principal identity permissions to do every action on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantRead">grantRead</a></code> | Grant the given principal identity permissions to read the contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadLongTermMemory">grantReadLongTermMemory</a></code> | Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadShortTermMemory">grantReadShortTermMemory</a></code> | Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantWrite">grantWrite</a></code> | Grant the given principal identity permissions to write content to short-term memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metric">metric</a></code> | Return the given named metric for this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Return a metric containing the number of errors for a specific API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricEventCreationCount">metricEventCreationCount</a></code> | Returns the metric containing the number of short-term memory events. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricForApiOperation">metricForApiOperation</a></code> | Return the given named metric related to the API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Return a metric containing the total number of API requests made for a specific memory operation like `CreateEvent`, `ListEvents`, `RetrieveMemoryRecords` ... |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Return a metric measuring the latency of a specific API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricMemoryRecordCreationCount">metricMemoryRecordCreationCount</a></code> | Returns the metric containing the number of long-term memory records created by the long-term extraction strategies. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant permissions to.

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grant.parameter.actions"></a>

- *Type:* ...string[]

The actions to grant.

---

##### `grantAdmin` <a name="grantAdmin" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantAdmin"></a>

```typescript
public grantAdmin(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to manage the control plane of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantAdmin.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant admin permissions to.

---

##### `grantDelete` <a name="grantDelete" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDelete"></a>

```typescript
public grantDelete(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete content on this memory.

Both Short-Term Memory (STM) and Long-Term Memory (LTM).

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDelete.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantDeleteLongTermMemory` <a name="grantDeleteLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteLongTermMemory"></a>

```typescript
public grantDeleteLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantDeleteShortTermMemory` <a name="grantDeleteShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteShortTermMemory"></a>

```typescript
public grantDeleteShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantDeleteShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant delete permissions to.

---

##### `grantFullAccess` <a name="grantFullAccess" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantFullAccess"></a>

```typescript
public grantFullAccess(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to do every action on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantFullAccess.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant full access permissions to.

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the contents of this memory.

Both Short-Term Memory (STM) and Long-Term Memory (LTM).

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantReadLongTermMemory` <a name="grantReadLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadLongTermMemory"></a>

```typescript
public grantReadLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantReadShortTermMemory` <a name="grantReadShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadShortTermMemory"></a>

```typescript
public grantReadShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantReadShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `grantWrite` <a name="grantWrite" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantWrite"></a>

```typescript
public grantWrite(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to write content to short-term memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.grantWrite.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The IAM principal to grant read permissions to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this memory.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of errors for a specific API operation performed on this memory.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricEventCreationCount` <a name="metricEventCreationCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricEventCreationCount"></a>

```typescript
public metricEventCreationCount(props?: MetricOptions): Metric
```

Returns the metric containing the number of short-term memory events.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricEventCreationCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Return the given named metric related to the API operation performed on this memory.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the total number of API requests made for a specific memory operation like `CreateEvent`, `ListEvents`, `RetrieveMemoryRecords` ...

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric measuring the latency of a specific API operation performed on this memory.

The latency metric represents the total time elapsed between receiving the request and sending
the final response token, measuring complete end-to-end processing time.

For memory creation events specifically, this measures the time from the last CreateEvent
that met strategy criteria until memory storage is completed.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricMemoryRecordCreationCount` <a name="metricMemoryRecordCreationCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricMemoryRecordCreationCount"></a>

```typescript
public metricMemoryRecordCreationCount(props?: MetricOptions): Metric
```

Returns the metric containing the number of long-term memory records created by the long-term extraction strategies.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.metricMemoryRecordCreationCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.memoryArn">memoryArn</a></code> | <code>string</code> | The ARN of the memory resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.memoryId">memoryId</a></code> | <code>string</code> | The id of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the memory was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the memory to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | Custom KMS key for encryption (if provided). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.status">status</a></code> | <code>string</code> | The status of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the memory was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `memoryArn`<sup>Required</sup> <a name="memoryArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.memoryArn"></a>

```typescript
public readonly memoryArn: string;
```

- *Type:* string

The ARN of the memory resource.

---

##### `memoryId`<sup>Required</sup> <a name="memoryId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.memoryId"></a>

```typescript
public readonly memoryId: string;
```

- *Type:* string

The id of the memory.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the memory was created.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the memory to access AWS services.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

Custom KMS key for encryption (if provided).

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the memory.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the memory was last updated.

---


### Runtime <a name="Runtime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime"></a>

Bedrock Agent Core Runtime Enables running containerized agents with specific network configurations, security settings, and runtime artifacts.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.Runtime(scope: Construct, id: string, props: RuntimeProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addToRolePolicy">addToRolePolicy</a></code> | Adds a policy statement to the runtime's execution role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grant">grant</a></code> | Grant the runtime specific actions on AWS resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvoke">grantInvoke</a></code> | Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntime">grantInvokeRuntime</a></code> | Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntimeForUser">grantInvokeRuntimeForUser</a></code> | Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metric">metric</a></code> | Return the given named metric for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocationsAggregated">metricInvocationsAggregated</a></code> | Return a metric containing the total number of invocations across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionCount">metricSessionCount</a></code> | Return a metric containing the number of agent sessions for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionsAggregated">metricSessionsAggregated</a></code> | Return a metric containing the total number of sessions across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricTotalErrors">metricTotalErrors</a></code> | Return a metric containing the total number of errors (system + user) for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addEndpoint">addEndpoint</a></code> | Add an endpoint to this runtime This is a convenience method that creates a RuntimeEndpoint associated with this runtime. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `addToRolePolicy` <a name="addToRolePolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addToRolePolicy"></a>

```typescript
public addToRolePolicy(statement: PolicyStatement): IBedrockAgentRuntime
```

Adds a policy statement to the runtime's execution role.

###### `statement`<sup>Required</sup> <a name="statement" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addToRolePolicy.parameter.statement"></a>

- *Type:* aws-cdk-lib.aws_iam.PolicyStatement

The IAM policy statement to add.

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grant"></a>

```typescript
public grant(actions: string[], resources: string[]): Grant
```

Grant the runtime specific actions on AWS resources.

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grant.parameter.actions"></a>

- *Type:* string[]

The actions to grant.

---

###### `resources`<sup>Required</sup> <a name="resources" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grant.parameter.resources"></a>

- *Type:* string[]

The resource ARNs to grant access to.

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntime` <a name="grantInvokeRuntime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntime"></a>

```typescript
public grantInvokeRuntime(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntime.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntimeForUser` <a name="grantInvokeRuntimeForUser" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntimeForUser"></a>

```typescript
public grantInvokeRuntimeForUser(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.grantInvokeRuntimeForUser.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this agent runtime.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsAggregated` <a name="metricInvocationsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocationsAggregated"></a>

```typescript
public metricInvocationsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricInvocationsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this agent runtime.

The latency metric represents the total time elapsed between receiving the request
and sending the final response token, representing complete end-to-end processing time.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionCount` <a name="metricSessionCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionCount"></a>

```typescript
public metricSessionCount(props?: MetricOptions): Metric
```

Return a metric containing the number of agent sessions for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionsAggregated` <a name="metricSessionsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionsAggregated"></a>

```typescript
public metricSessionsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of sessions across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSessionsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTotalErrors` <a name="metricTotalErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricTotalErrors"></a>

```typescript
public metricTotalErrors(props?: MetricOptions): Metric
```

Return a metric containing the total number of errors (system + user) for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricTotalErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `addEndpoint` <a name="addEndpoint" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addEndpoint"></a>

```typescript
public addEndpoint(endpointName: string, options?: AddEndpointOptions): RuntimeEndpoint
```

Add an endpoint to this runtime This is a convenience method that creates a RuntimeEndpoint associated with this runtime.

###### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addEndpoint.parameter.endpointName"></a>

- *Type:* string

The name of the endpoint.

---

###### `options`<sup>Optional</sup> <a name="options" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.addEndpoint.parameter.options"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions

Optional configuration for the endpoint.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.fromAgentRuntimeAttributes">fromAgentRuntimeAttributes</a></code> | Import an existing Agent Runtime using attributes This allows you to reference an Agent Runtime that was created outside of CDK. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Runtime.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Runtime.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Runtime.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromAgentRuntimeAttributes` <a name="fromAgentRuntimeAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.fromAgentRuntimeAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.Runtime.fromAgentRuntimeAttributes(scope: Construct, id: string, attrs: AgentRuntimeAttributes)
```

Import an existing Agent Runtime using attributes This allows you to reference an Agent Runtime that was created outside of CDK.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.fromAgentRuntimeAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.fromAgentRuntimeAttributes.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.fromAgentRuntimeAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes

The attributes of the existing Agent Runtime.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The unique identifier of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeName">agentRuntimeName</a></code> | <code>string</code> | The name of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Runtime does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentStatus">agentStatus</a></code> | <code>string</code> | The status of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.createdAt">createdAt</a></code> | <code>string</code> | The timestamp when the agent runtime was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The timestamp when the agent runtime was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeArtifact">agentRuntimeArtifact</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact</code> | The artifact configuration for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.description">description</a></code> | <code>string</code> | Optional description for the agent runtime. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the agent runtime.

---

##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The unique identifier of the agent runtime.

---

##### `agentRuntimeName`<sup>Required</sup> <a name="agentRuntimeName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeName"></a>

```typescript
public readonly agentRuntimeName: string;
```

- *Type:* string

The name of the agent runtime.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Runtime does not have a VPC configured.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the agent runtime.

---

##### `agentRuntimeVersion`<sup>Optional</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string

The version of the agent runtime.

---

##### `agentStatus`<sup>Optional</sup> <a name="agentStatus" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentStatus"></a>

```typescript
public readonly agentStatus: string;
```

- *Type:* string

The status of the agent runtime.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The timestamp when the agent runtime was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

The timestamp when the agent runtime was last updated.

---

##### `agentRuntimeArtifact`<sup>Required</sup> <a name="agentRuntimeArtifact" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.agentRuntimeArtifact"></a>

```typescript
public readonly agentRuntimeArtifact: AgentRuntimeArtifact;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact

The artifact configuration for the agent runtime.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

Optional description for the agent runtime.

---


### RuntimeBase <a name="RuntimeBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime

Base class for Agent Runtime.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.RuntimeBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.addToRolePolicy">addToRolePolicy</a></code> | Adds a policy statement to the runtime's execution role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grant">grant</a></code> | Grant the runtime specific actions on AWS resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvoke">grantInvoke</a></code> | Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntime">grantInvokeRuntime</a></code> | Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntimeForUser">grantInvokeRuntimeForUser</a></code> | Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metric">metric</a></code> | Return the given named metric for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocationsAggregated">metricInvocationsAggregated</a></code> | Return a metric containing the total number of invocations across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionCount">metricSessionCount</a></code> | Return a metric containing the number of agent sessions for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionsAggregated">metricSessionsAggregated</a></code> | Return a metric containing the total number of sessions across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricTotalErrors">metricTotalErrors</a></code> | Return a metric containing the total number of errors (system + user) for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors for this agent runtime. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

##### `addToRolePolicy` <a name="addToRolePolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.addToRolePolicy"></a>

```typescript
public addToRolePolicy(statement: PolicyStatement): IBedrockAgentRuntime
```

Adds a policy statement to the runtime's execution role.

###### `statement`<sup>Required</sup> <a name="statement" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.addToRolePolicy.parameter.statement"></a>

- *Type:* aws-cdk-lib.aws_iam.PolicyStatement

The IAM policy statement to add.

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grant"></a>

```typescript
public grant(actions: string[], resources: string[]): Grant
```

Grant the runtime specific actions on AWS resources.

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grant.parameter.actions"></a>

- *Type:* string[]

The actions to grant.

---

###### `resources`<sup>Required</sup> <a name="resources" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grant.parameter.resources"></a>

- *Type:* string[]

The resource ARNs to grant access to.

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntime` <a name="grantInvokeRuntime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntime"></a>

```typescript
public grantInvokeRuntime(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntime.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntimeForUser` <a name="grantInvokeRuntimeForUser" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntimeForUser"></a>

```typescript
public grantInvokeRuntimeForUser(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.grantInvokeRuntimeForUser.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this agent runtime.

By default, the metric will be calculated as a sum over a period of 5 minutes.
You can customize this by using the `statistic` and `period` properties.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsAggregated` <a name="metricInvocationsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocationsAggregated"></a>

```typescript
public metricInvocationsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricInvocationsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this agent runtime.

The latency metric represents the total time elapsed between receiving the request
and sending the final response token, representing complete end-to-end processing time.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionCount` <a name="metricSessionCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionCount"></a>

```typescript
public metricSessionCount(props?: MetricOptions): Metric
```

Return a metric containing the number of agent sessions for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionsAggregated` <a name="metricSessionsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionsAggregated"></a>

```typescript
public metricSessionsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of sessions across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSessionsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTotalErrors` <a name="metricTotalErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricTotalErrors"></a>

```typescript
public metricTotalErrors(props?: MetricOptions): Metric
```

Return a metric containing the total number of errors (system + user) for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricTotalErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the agent runtime resource - Format `arn:${Partition}:bedrock-agentcore:${Region}:${Account}:runtime/${RuntimeId}`. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The ID of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeName">agentRuntimeName</a></code> | <code>string</code> | The name of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | An accessor for the Connections object that will fail if this Runtime does not have a VPC configured. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentStatus">agentStatus</a></code> | <code>string</code> | The current status of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.createdAt">createdAt</a></code> | <code>string</code> | The time at which the runtime was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The time at which the runtime was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the agent runtime resource - Format `arn:${Partition}:bedrock-agentcore:${Region}:${Account}:runtime/${RuntimeId}`.

---

##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The ID of the agent runtime.

---

##### `agentRuntimeName`<sup>Required</sup> <a name="agentRuntimeName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeName"></a>

```typescript
public readonly agentRuntimeName: string;
```

- *Type:* string

The name of the agent runtime.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

An accessor for the Connections object that will fail if this Runtime does not have a VPC configured.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the agent runtime.

---

##### `agentRuntimeVersion`<sup>Optional</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string

The version of the agent runtime.

---

##### `agentStatus`<sup>Optional</sup> <a name="agentStatus" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.agentStatus"></a>

```typescript
public readonly agentStatus: string;
```

- *Type:* string

The current status of the agent runtime.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The time at which the runtime was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

The time at which the runtime was last updated.

---


### RuntimeEndpoint <a name="RuntimeEndpoint" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint"></a>

Bedrock Agent Core Runtime Endpoint Provides a stable endpoint for invoking agent runtimes with versioning support.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-endpoint.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-endpoint.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.RuntimeEndpoint(scope: Construct, id: string, props: RuntimeEndpointProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.id"></a>

- *Type:* string

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isResource">isResource</a></code> | Check whether the given construct is a Resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes">fromRuntimeEndpointAttributes</a></code> | Import an existing Agent Runtime Endpoint using attributes This allows you to reference an Agent Runtime Endpoint that was created outside of CDK. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpoint.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpoint.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpoint.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `fromRuntimeEndpointAttributes` <a name="fromRuntimeEndpointAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes(scope: Construct, id: string, attrs: RuntimeEndpointAttributes)
```

Import an existing Agent Runtime Endpoint using attributes This allows you to reference an Agent Runtime Endpoint that was created outside of CDK.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes.parameter.id"></a>

- *Type:* string

The construct id.

---

###### `attrs`<sup>Required</sup> <a name="attrs" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.fromRuntimeEndpointAttributes.parameter.attrs"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes

The attributes of the existing Agent Runtime Endpoint.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the agent runtime associated with this endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeEndpointArn">agentRuntimeEndpointArn</a></code> | <code>string</code> | The ARN of the agent runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.endpointName">endpointName</a></code> | <code>string</code> | The name of the endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.createdAt">createdAt</a></code> | <code>string</code> | The timestamp when the endpoint was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.description">description</a></code> | <code>string</code> | Optional description for the endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.liveVersion">liveVersion</a></code> | <code>string</code> | The live version of the endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.status">status</a></code> | <code>string</code> | The status of the endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.targetVersion">targetVersion</a></code> | <code>string</code> | The target version of the endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The ID of the agent runtime associated with this endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime used by this endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.endpointId">endpointId</a></code> | <code>string</code> | The unique identifier of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | When this endpoint was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the agent runtime associated with this endpoint.

---

##### `agentRuntimeEndpointArn`<sup>Required</sup> <a name="agentRuntimeEndpointArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeEndpointArn"></a>

```typescript
public readonly agentRuntimeEndpointArn: string;
```

- *Type:* string

The ARN of the agent runtime endpoint.

---

##### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.endpointName"></a>

```typescript
public readonly endpointName: string;
```

- *Type:* string

The name of the endpoint.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The timestamp when the endpoint was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

Optional description for the endpoint.

---

##### `liveVersion`<sup>Optional</sup> <a name="liveVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.liveVersion"></a>

```typescript
public readonly liveVersion: string;
```

- *Type:* string

The live version of the endpoint.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the endpoint.

---

##### `targetVersion`<sup>Optional</sup> <a name="targetVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.targetVersion"></a>

```typescript
public readonly targetVersion: string;
```

- *Type:* string

The target version of the endpoint.

---

##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The ID of the agent runtime associated with this endpoint.

---

##### `agentRuntimeVersion`<sup>Required</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string

The version of the agent runtime used by this endpoint.

---

##### `endpointId`<sup>Required</sup> <a name="endpointId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.endpointId"></a>

```typescript
public readonly endpointId: string;
```

- *Type:* string

The unique identifier of the runtime endpoint.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

When this endpoint was last updated.

---


### RuntimeEndpointBase <a name="RuntimeEndpointBase" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint

Base class for Runtime Endpoint.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.RuntimeEndpointBase(scope: Construct, id: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.Initializer.parameter.id">id</a></code> | <code>string</code> | *No description.* |

---

##### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `id`<sup>Required</sup> <a name="id" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.Initializer.parameter.id"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.toString">toString</a></code> | Returns a string representation of this construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.applyRemovalPolicy">applyRemovalPolicy</a></code> | Apply the given removal policy to this resource. |

---

##### `toString` <a name="toString" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.toString"></a>

```typescript
public toString(): string
```

Returns a string representation of this construct.

##### `applyRemovalPolicy` <a name="applyRemovalPolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.applyRemovalPolicy"></a>

```typescript
public applyRemovalPolicy(policy: RemovalPolicy): void
```

Apply the given removal policy to this resource.

The Removal Policy controls what happens to this resource when it stops
being managed by CloudFormation, either because you've removed it from the
CDK application or because you've made a change that requires the resource
to be replaced.

The resource can be deleted (`RemovalPolicy.DESTROY`), or left in your AWS
account for data recovery and cleanup later (`RemovalPolicy.RETAIN`).

###### `policy`<sup>Required</sup> <a name="policy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.applyRemovalPolicy.parameter.policy"></a>

- *Type:* aws-cdk-lib.RemovalPolicy

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isConstruct">isConstruct</a></code> | Checks if `x` is a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isOwnedResource">isOwnedResource</a></code> | Returns true if the construct was created by CDK, and false otherwise. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isResource">isResource</a></code> | Check whether the given construct is a Resource. |

---

##### ~~`isConstruct`~~ <a name="isConstruct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isConstruct"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpointBase.isConstruct(x: any)
```

Checks if `x` is a construct.

###### `x`<sup>Required</sup> <a name="x" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isConstruct.parameter.x"></a>

- *Type:* any

Any object.

---

##### `isOwnedResource` <a name="isOwnedResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isOwnedResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpointBase.isOwnedResource(construct: IConstruct)
```

Returns true if the construct was created by CDK, and false otherwise.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isOwnedResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

##### `isResource` <a name="isResource" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isResource"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeEndpointBase.isResource(construct: IConstruct)
```

Check whether the given construct is a Resource.

###### `construct`<sup>Required</sup> <a name="construct" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.isResource.parameter.construct"></a>

- *Type:* constructs.IConstruct

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the parent agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.agentRuntimeEndpointArn">agentRuntimeEndpointArn</a></code> | <code>string</code> | The ARN of the runtime endpoint resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.endpointName">endpointName</a></code> | <code>string</code> | The name of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.createdAt">createdAt</a></code> | <code>string</code> | When the endpoint was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.description">description</a></code> | <code>string</code> | The description of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.liveVersion">liveVersion</a></code> | <code>string</code> | The live version of the agent runtime that is currently serving requests. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.status">status</a></code> | <code>string</code> | The current status of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.targetVersion">targetVersion</a></code> | <code>string</code> | The target version the endpoint is transitioning to (during updates). |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the parent agent runtime.

---

##### `agentRuntimeEndpointArn`<sup>Required</sup> <a name="agentRuntimeEndpointArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.agentRuntimeEndpointArn"></a>

```typescript
public readonly agentRuntimeEndpointArn: string;
```

- *Type:* string

The ARN of the runtime endpoint resource.

---

##### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.endpointName"></a>

```typescript
public readonly endpointName: string;
```

- *Type:* string

The name of the runtime endpoint.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

When the endpoint was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the runtime endpoint.

---

##### `liveVersion`<sup>Optional</sup> <a name="liveVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.liveVersion"></a>

```typescript
public readonly liveVersion: string;
```

- *Type:* string

The live version of the agent runtime that is currently serving requests.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The current status of the runtime endpoint.

---

##### `targetVersion`<sup>Optional</sup> <a name="targetVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase.property.targetVersion"></a>

```typescript
public readonly targetVersion: string;
```

- *Type:* string

The target version the endpoint is transitioning to (during updates).

---


## Structs <a name="Structs" id="Structs"></a>

### AddEndpointOptions <a name="AddEndpointOptions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions"></a>

Options for adding an endpoint to the runtime.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const addEndpointOptions: bedrock_agentcore.AddEndpointOptions = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions.property.description">description</a></code> | <code>string</code> | Description for the endpoint, Must be between 1 and 1200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions.property.version">version</a></code> | <code>string</code> | Override the runtime version for this endpoint. |

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Description for the endpoint, Must be between 1 and 1200 characters.

---

##### `version`<sup>Optional</sup> <a name="version" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddEndpointOptions.property.version"></a>

```typescript
public readonly version: string;
```

- *Type:* string
- *Default:* 1

Override the runtime version for this endpoint.

---

### AddLambdaTargetOptions <a name="AddLambdaTargetOptions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions"></a>

Options for adding a Lambda target to a gateway.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const addLambdaTargetOptions: bedrock_agentcore.AddLambdaTargetOptions = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.lambdaFunction">lambdaFunction</a></code> | <code>aws-cdk-lib.aws_lambda.IFunction</code> | The Lambda function to associate with this target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.toolSchema">toolSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema</code> | The tool schema defining the available tools. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen).

---

##### `lambdaFunction`<sup>Required</sup> <a name="lambdaFunction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.lambdaFunction"></a>

```typescript
public readonly lambdaFunction: IFunction;
```

- *Type:* aws-cdk-lib.aws_lambda.IFunction

The Lambda function to associate with this target.

---

##### `toolSchema`<sup>Required</sup> <a name="toolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.toolSchema"></a>

```typescript
public readonly toolSchema: ToolSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema

The tool schema defining the available tools.

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddLambdaTargetOptions.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target.

---

### AddOpenApiTargetOptions <a name="AddOpenApiTargetOptions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions"></a>

Options for adding an OpenAPI target to a gateway.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const addOpenApiTargetOptions: bedrock_agentcore.AddOpenApiTargetOptions = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.apiSchema">apiSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The OpenAPI schema defining the API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target. |

---

##### `apiSchema`<sup>Required</sup> <a name="apiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.apiSchema"></a>

```typescript
public readonly apiSchema: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The OpenAPI schema defining the API.

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen).

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddOpenApiTargetOptions.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target.

---

### AddSmithyTargetOptions <a name="AddSmithyTargetOptions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions"></a>

Options for adding a Smithy target to a gateway.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const addSmithyTargetOptions: bedrock_agentcore.AddSmithyTargetOptions = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.smithyModel">smithyModel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The Smithy model defining the API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen).

---

##### `smithyModel`<sup>Required</sup> <a name="smithyModel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.smithyModel"></a>

```typescript
public readonly smithyModel: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The Smithy model defining the API.

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AddSmithyTargetOptions.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target.

---

### AgentRuntimeAttributes <a name="AgentRuntimeAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes"></a>

Attributes for importing an existing Agent Runtime.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const agentRuntimeAttributes: bedrock_agentcore.AgentRuntimeAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The ID of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeName">agentRuntimeName</a></code> | <code>string</code> | The name of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.roleArn">roleArn</a></code> | <code>string</code> | The IAM role ARN. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime When importing a runtime and this is not specified or undefined, endpoints created on this runtime will point to version "1" unless explicitly overridden. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentStatus">agentStatus</a></code> | <code>string</code> | The current status of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | The time at which the runtime was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.description">description</a></code> | <code>string</code> | The description of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The time at which the runtime was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.securityGroups">securityGroups</a></code> | <code>aws-cdk-lib.aws_ec2.ISecurityGroup[]</code> | The security groups for this runtime, if in a VPC. |

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the agent runtime.

---

##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The ID of the agent runtime.

---

##### `agentRuntimeName`<sup>Required</sup> <a name="agentRuntimeName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeName"></a>

```typescript
public readonly agentRuntimeName: string;
```

- *Type:* string

The name of the agent runtime.

---

##### `roleArn`<sup>Required</sup> <a name="roleArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.roleArn"></a>

```typescript
public readonly roleArn: string;
```

- *Type:* string

The IAM role ARN.

---

##### `agentRuntimeVersion`<sup>Optional</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string
- *Default:* undefined

The version of the agent runtime When importing a runtime and this is not specified or undefined, endpoints created on this runtime will point to version "1" unless explicitly overridden.

---

##### `agentStatus`<sup>Optional</sup> <a name="agentStatus" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.agentStatus"></a>

```typescript
public readonly agentStatus: string;
```

- *Type:* string
- *Default:* Status not available

The current status of the agent runtime.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* Creation time not available

The time at which the runtime was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

The description of the agent runtime.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string
- *Default:* Last update time not available

The time at which the runtime was last updated.

---

##### `securityGroups`<sup>Optional</sup> <a name="securityGroups" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeAttributes.property.securityGroups"></a>

```typescript
public readonly securityGroups: ISecurityGroup[];
```

- *Type:* aws-cdk-lib.aws_ec2.ISecurityGroup[]
- *Default:* By default, the runtime is not in a VPC.

The security groups for this runtime, if in a VPC.

---

### ApiKeyAdditionalConfiguration <a name="ApiKeyAdditionalConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration"></a>

API Key additional configuration.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const apiKeyAdditionalConfiguration: bedrock_agentcore.ApiKeyAdditionalConfiguration = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration.property.credentialParameterName">credentialParameterName</a></code> | <code>string</code> | The name of the credential parameter for the API key. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration.property.credentialPrefix">credentialPrefix</a></code> | <code>string</code> | The prefix for the API key credential. |

---

##### `credentialParameterName`<sup>Optional</sup> <a name="credentialParameterName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration.property.credentialParameterName"></a>

```typescript
public readonly credentialParameterName: string;
```

- *Type:* string
- *Default:* 'Authorization' for HEADER, 'api_key' for QUERY_PARAMETER

The name of the credential parameter for the API key.

This parameter name is used when sending the API key to the target endpoint.

Length Constraints: Minimum length of 1. Maximum length of 64.

---

##### `credentialPrefix`<sup>Optional</sup> <a name="credentialPrefix" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration.property.credentialPrefix"></a>

```typescript
public readonly credentialPrefix: string;
```

- *Type:* string
- *Default:* 'Bearer ' for HEADER, no prefix for QUERY_PARAMETER

The prefix for the API key credential.

This prefix is added to the API key when sending it to the target endpoint.

Length Constraints: Minimum length of 1. Maximum length of 64.

---

### ApiKeyCredentialProviderProps <a name="ApiKeyCredentialProviderProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps"></a>

API Key configuration.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const apiKeyCredentialProviderProps: bedrock_agentcore.ApiKeyCredentialProviderProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.providerArn">providerArn</a></code> | <code>string</code> | The API key credential provider ARN. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.secretArn">secretArn</a></code> | <code>string</code> | The ARN of the Secrets Manager secret containing the API key. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.credentialLocation">credentialLocation</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation</code> | The location of the API key credential. |

---

##### `providerArn`<sup>Required</sup> <a name="providerArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.providerArn"></a>

```typescript
public readonly providerArn: string;
```

- *Type:* string

The API key credential provider ARN.

This is returned when creating the API key credential provider via Console or API.
Format: arn:aws:bedrock-agentcore:region:account:token-vault/id/apikeycredentialprovider/name

---

##### `secretArn`<sup>Required</sup> <a name="secretArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.secretArn"></a>

```typescript
public readonly secretArn: string;
```

- *Type:* string

The ARN of the Secrets Manager secret containing the API key.

This is returned when creating the API key credential provider via Console or API.
Format: arn:aws:secretsmanager:region:account:secret:name

---

##### `credentialLocation`<sup>Optional</sup> <a name="credentialLocation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps.property.credentialLocation"></a>

```typescript
public readonly credentialLocation: ApiKeyCredentialLocation;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation
- *Default:* HEADER

The location of the API key credential.

This field specifies where in the request the API key should be placed.

---

### BrowserCustomAttributes <a name="BrowserCustomAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes"></a>

Attributes for specifying an imported Browser Custom.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const browserCustomAttributes: bedrock_agentcore.BrowserCustomAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.browserArn">browserArn</a></code> | <code>string</code> | The ARN of the agent. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.roleArn">roleArn</a></code> | <code>string</code> | The ARN of the IAM role associated to the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | When this browser was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.securityGroups">securityGroups</a></code> | <code>aws-cdk-lib.aws_ec2.ISecurityGroup[]</code> | The security groups for this browser, if in a VPC. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.status">status</a></code> | <code>string</code> | The status of the browser. |

---

##### `browserArn`<sup>Required</sup> <a name="browserArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.browserArn"></a>

```typescript
public readonly browserArn: string;
```

- *Type:* string

The ARN of the agent.

---

##### `roleArn`<sup>Required</sup> <a name="roleArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.roleArn"></a>

```typescript
public readonly roleArn: string;
```

- *Type:* string

The ARN of the IAM role associated to the browser.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* undefined - No created timestamp is provided

The created timestamp of the browser.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string
- *Default:* undefined - No last updated timestamp is provided

When this browser was last updated.

---

##### `securityGroups`<sup>Optional</sup> <a name="securityGroups" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.securityGroups"></a>

```typescript
public readonly securityGroups: ISecurityGroup[];
```

- *Type:* aws-cdk-lib.aws_ec2.ISecurityGroup[]
- *Default:* By default, the browser is not in a VPC.

The security groups for this browser, if in a VPC.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomAttributes.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string
- *Default:* undefined - No status is provided

The status of the browser.

---

### BrowserCustomProps <a name="BrowserCustomProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps"></a>

Properties for creating a Browser resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const browserCustomProps: bedrock_agentcore.BrowserCustomProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.browserCustomName">browserCustomName</a></code> | <code>string</code> | The name of the browser Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.description">description</a></code> | <code>string</code> | Optional description for the browser Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the browser to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.networkConfiguration">networkConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration</code> | Network configuration for browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.recordingConfig">recordingConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig</code> | Recording configuration for browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags (optional) A list of key:value pairs of tags to apply to this Browser resource. |

---

##### `browserCustomName`<sup>Required</sup> <a name="browserCustomName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.browserCustomName"></a>

```typescript
public readonly browserCustomName: string;
```

- *Type:* string

The name of the browser Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the browser Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole
- *Default:* A new role will be created

The IAM role that provides permissions for the browser to access AWS services.

---

##### `networkConfiguration`<sup>Optional</sup> <a name="networkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.networkConfiguration"></a>

```typescript
public readonly networkConfiguration: BrowserNetworkConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration
- *Default:* PUBLIC network mode

Network configuration for browser.

---

##### `recordingConfig`<sup>Optional</sup> <a name="recordingConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.recordingConfig"></a>

```typescript
public readonly recordingConfig: RecordingConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig
- *Default:* No recording configuration

Recording configuration for browser.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* {} - no tags

Tags (optional) A list of key:value pairs of tags to apply to this Browser resource.

---

### CodeInterpreterCustomAttributes <a name="CodeInterpreterCustomAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes"></a>

Attributes for specifying an imported Code Interpreter Custom.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const codeInterpreterCustomAttributes: bedrock_agentcore.CodeInterpreterCustomAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.codeInterpreterArn">codeInterpreterArn</a></code> | <code>string</code> | The ARN of the agent. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.roleArn">roleArn</a></code> | <code>string</code> | The ARN of the IAM role associated to the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | When this code interpreter was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.securityGroups">securityGroups</a></code> | <code>aws-cdk-lib.aws_ec2.ISecurityGroup[]</code> | The security groups for this code interpreter, if in a VPC. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.status">status</a></code> | <code>string</code> | The status of the code interpreter. |

---

##### `codeInterpreterArn`<sup>Required</sup> <a name="codeInterpreterArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.codeInterpreterArn"></a>

```typescript
public readonly codeInterpreterArn: string;
```

- *Type:* string

The ARN of the agent.

---

##### `roleArn`<sup>Required</sup> <a name="roleArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.roleArn"></a>

```typescript
public readonly roleArn: string;
```

- *Type:* string

The ARN of the IAM role associated to the code interpreter.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* undefined - No created timestamp is provided

The created timestamp of the code interpreter.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string
- *Default:* undefined - No last updated timestamp is provided

When this code interpreter was last updated.

---

##### `securityGroups`<sup>Optional</sup> <a name="securityGroups" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.securityGroups"></a>

```typescript
public readonly securityGroups: ISecurityGroup[];
```

- *Type:* aws-cdk-lib.aws_ec2.ISecurityGroup[]
- *Default:* By default, the code interpreter is not in a VPC.

The security groups for this code interpreter, if in a VPC.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomAttributes.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string
- *Default:* undefined - No status is provided

The status of the code interpreter.

---

### CodeInterpreterCustomProps <a name="CodeInterpreterCustomProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps"></a>

Properties for creating a CodeInterpreter resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const codeInterpreterCustomProps: bedrock_agentcore.CodeInterpreterCustomProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.codeInterpreterCustomName">codeInterpreterCustomName</a></code> | <code>string</code> | The name of the code interpreter Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.description">description</a></code> | <code>string</code> | Optional description for the code interpreter Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the code interpreter to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.networkConfiguration">networkConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration</code> | Network configuration for code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags (optional) A list of key:value pairs of tags to apply to this Code Interpreter resource. |

---

##### `codeInterpreterCustomName`<sup>Required</sup> <a name="codeInterpreterCustomName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.codeInterpreterCustomName"></a>

```typescript
public readonly codeInterpreterCustomName: string;
```

- *Type:* string

The name of the code interpreter Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the code interpreter Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole
- *Default:* A new role will be created.

The IAM role that provides permissions for the code interpreter to access AWS services.

---

##### `networkConfiguration`<sup>Optional</sup> <a name="networkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.networkConfiguration"></a>

```typescript
public readonly networkConfiguration: CodeInterpreterNetworkConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration
- *Default:* PUBLIC network mode

Network configuration for code interpreter.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* {} - no tags

Tags (optional) A list of key:value pairs of tags to apply to this Code Interpreter resource.

---

### CognitoAuthorizerProps <a name="CognitoAuthorizerProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps"></a>

****************************************************************************                              Factory ***************************************************************************.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const cognitoAuthorizerProps: bedrock_agentcore.CognitoAuthorizerProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.userPool">userPool</a></code> | <code>aws-cdk-lib.aws_cognito.UserPool</code> | The Cognito User Pool to use for authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.allowedAudiences">allowedAudiences</a></code> | <code>string[]</code> | The allowed audiences for JWT validation. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.allowedClients">allowedClients</a></code> | <code>aws-cdk-lib.aws_cognito.IUserPoolClient[]</code> | The allowed User Pool clients. |

---

##### `userPool`<sup>Required</sup> <a name="userPool" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.userPool"></a>

```typescript
public readonly userPool: UserPool;
```

- *Type:* aws-cdk-lib.aws_cognito.UserPool

The Cognito User Pool to use for authentication.

---

##### `allowedAudiences`<sup>Optional</sup> <a name="allowedAudiences" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.allowedAudiences"></a>

```typescript
public readonly allowedAudiences: string[];
```

- *Type:* string[]
- *Default:* No audience validation

The allowed audiences for JWT validation.

---

##### `allowedClients`<sup>Optional</sup> <a name="allowedClients" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps.property.allowedClients"></a>

```typescript
public readonly allowedClients: IUserPoolClient[];
```

- *Type:* aws-cdk-lib.aws_cognito.IUserPoolClient[]
- *Default:* All clients are allowed

The allowed User Pool clients.

---

### CustomJwtConfiguration <a name="CustomJwtConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration"></a>

Custom JWT authorizer configuration.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const customJwtConfiguration: bedrock_agentcore.CustomJwtConfiguration = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.discoveryUrl">discoveryUrl</a></code> | <code>string</code> | This URL is used to fetch OpenID Connect configuration or authorization server metadata for validating incoming tokens. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.allowedAudience">allowedAudience</a></code> | <code>string[]</code> | Represents individual audience values that are validated in the incoming JWT token validation process. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.allowedClients">allowedClients</a></code> | <code>string[]</code> | Represents individual client IDs that are validated in the incoming JWT token validation process. |

---

##### `discoveryUrl`<sup>Required</sup> <a name="discoveryUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.discoveryUrl"></a>

```typescript
public readonly discoveryUrl: string;
```

- *Type:* string

This URL is used to fetch OpenID Connect configuration or authorization server metadata for validating incoming tokens.

Pattern: .+/\.well-known/openid-configuration
Required: Yes

---

##### `allowedAudience`<sup>Optional</sup> <a name="allowedAudience" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.allowedAudience"></a>

```typescript
public readonly allowedAudience: string[];
```

- *Type:* string[]
- *Default:* No audience validation

Represents individual audience values that are validated in the incoming JWT token validation process.

*

---

##### `allowedClients`<sup>Optional</sup> <a name="allowedClients" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration.property.allowedClients"></a>

```typescript
public readonly allowedClients: string[];
```

- *Type:* string[]
- *Default:* No client ID validation

Represents individual client IDs that are validated in the incoming JWT token validation process.

*

---

### GatewayAttributes <a name="GatewayAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes"></a>

Attributes for importing an existing Gateway.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayAttributes: bedrock_agentcore.GatewayAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayArn">gatewayArn</a></code> | <code>string</code> | The ARN of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayId">gatewayId</a></code> | <code>string</code> | The ID of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayName">gatewayName</a></code> | <code>string</code> | The name of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the gateway. |

---

##### `gatewayArn`<sup>Required</sup> <a name="gatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayArn"></a>

```typescript
public readonly gatewayArn: string;
```

- *Type:* string

The ARN of the gateway.

---

##### `gatewayId`<sup>Required</sup> <a name="gatewayId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayId"></a>

```typescript
public readonly gatewayId: string;
```

- *Type:* string

The ID of the gateway.

---

##### `gatewayName`<sup>Required</sup> <a name="gatewayName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.gatewayName"></a>

```typescript
public readonly gatewayName: string;
```

- *Type:* string

The name of the gateway.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAttributes.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the gateway.

---

### GatewayProps <a name="GatewayProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps"></a>

Properties for defining a Gateway.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayProps: bedrock_agentcore.GatewayProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.gatewayName">gatewayName</a></code> | <code>string</code> | The name of the gateway Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen) The name must be unique within your account. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.authorizerConfiguration">authorizerConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer</code> | The authorizer configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.exceptionLevel">exceptionLevel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel</code> | The verbosity of exception messages Use DEBUG mode to see granular exception messages from a Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | The AWS KMS key used to encrypt data associated with the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.protocolConfiguration">protocolConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol</code> | The protocol configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the gateway to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags for the gateway A list of key:value pairs of tags to apply to this Gateway resource. |

---

##### `gatewayName`<sup>Required</sup> <a name="gatewayName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.gatewayName"></a>

```typescript
public readonly gatewayName: string;
```

- *Type:* string

The name of the gateway Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen) The name must be unique within your account.

---

##### `authorizerConfiguration`<sup>Optional</sup> <a name="authorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.authorizerConfiguration"></a>

```typescript
public readonly authorizerConfiguration: IGatewayAuthorizer;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer
- *Default:* A default authorizer will be created using Cognito

The authorizer configuration for the gateway.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters.

---

##### `exceptionLevel`<sup>Optional</sup> <a name="exceptionLevel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.exceptionLevel"></a>

```typescript
public readonly exceptionLevel: GatewayExceptionLevel;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel
- *Default:* Exception messages are sanitized for presentation to end users

The verbosity of exception messages Use DEBUG mode to see granular exception messages from a Gateway.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey
- *Default:* No encryption

The AWS KMS key used to encrypt data associated with the gateway.

---

##### `protocolConfiguration`<sup>Optional</sup> <a name="protocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.protocolConfiguration"></a>

```typescript
public readonly protocolConfiguration: IGatewayProtocol;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol
- *Default:* A default protocol configuration will be created using MCP with following params supportedVersions: [MCPProtocolVersion.MCP_2025_03_26], searchType: McpGatewaySearchType.SEMANTIC, instructions: "Default gateway to connect to external MCP tools",

The protocol configuration for the gateway.

---

##### `role`<sup>Optional</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole
- *Default:* A new role will be created

The IAM role that provides permissions for the gateway to access AWS services.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No tags

Tags for the gateway A list of key:value pairs of tags to apply to this Gateway resource.

---

### GatewayTargetAttributes <a name="GatewayTargetAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes"></a>

Attributes for importing an existing Gateway Target.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayTargetAttributes: bedrock_agentcore.GatewayTargetAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.targetArn">targetArn</a></code> | <code>string</code> | The ARN of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.targetId">targetId</a></code> | <code>string</code> | The ID of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | Optional creation timestamp. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.status">status</a></code> | <code>string</code> | Optional status of the target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.updatedAt">updatedAt</a></code> | <code>string</code> | Optional last update timestamp. |

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target.

---

##### `targetArn`<sup>Required</sup> <a name="targetArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.targetArn"></a>

```typescript
public readonly targetArn: string;
```

- *Type:* string

The ARN of the gateway target.

---

##### `targetId`<sup>Required</sup> <a name="targetId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.targetId"></a>

```typescript
public readonly targetId: string;
```

- *Type:* string

The ID of the gateway target.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* No creation timestamp

Optional creation timestamp.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string
- *Default:* No status

Optional status of the target.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetAttributes.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string
- *Default:* No update timestamp

Optional last update timestamp.

---

### GatewayTargetLambdaProps <a name="GatewayTargetLambdaProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps"></a>

Properties for creating a Lambda-based Gateway Target Convenience interface for the most common use case.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayTargetLambdaProps: bedrock_agentcore.GatewayTargetLambdaProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.lambdaFunction">lambdaFunction</a></code> | <code>aws-cdk-lib.aws_lambda.IFunction</code> | The Lambda function to associate with this target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.toolSchema">toolSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema</code> | The tool schema defining the available tools. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target The description can have up to 200 characters.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `lambdaFunction`<sup>Required</sup> <a name="lambdaFunction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.lambdaFunction"></a>

```typescript
public readonly lambdaFunction: IFunction;
```

- *Type:* aws-cdk-lib.aws_lambda.IFunction

The Lambda function to associate with this target.

---

##### `toolSchema`<sup>Required</sup> <a name="toolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.toolSchema"></a>

```typescript
public readonly toolSchema: ToolSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema

The tool schema defining the available tools.

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetLambdaProps.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

### GatewayTargetOpenApiProps <a name="GatewayTargetOpenApiProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps"></a>

Properties for creating an OpenAPI-based Gateway Target.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayTargetOpenApiProps: bedrock_agentcore.GatewayTargetOpenApiProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.apiSchema">apiSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The OpenAPI schema defining the API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target The description can have up to 200 characters.

---

##### `apiSchema`<sup>Required</sup> <a name="apiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.apiSchema"></a>

```typescript
public readonly apiSchema: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The OpenAPI schema defining the API.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetOpenApiProps.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

### GatewayTargetProps <a name="GatewayTargetProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps"></a>

Properties for creating a Gateway Target resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayTargetProps: bedrock_agentcore.GatewayTargetProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.targetConfiguration">targetConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration</code> | The target configuration (Lambda, OpenAPI, or Smithy) Use one of the configuration helper classes: - LambdaTargetConfiguration.create() - OpenApiTargetConfiguration.create() - SmithyTargetConfiguration.create(). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target The description can have up to 200 characters.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `targetConfiguration`<sup>Required</sup> <a name="targetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.targetConfiguration"></a>

```typescript
public readonly targetConfiguration: ITargetConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration

The target configuration (Lambda, OpenAPI, or Smithy) Use one of the configuration helper classes: - LambdaTargetConfiguration.create() - OpenApiTargetConfiguration.create() - SmithyTargetConfiguration.create().

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProps.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

### GatewayTargetSmithyProps <a name="GatewayTargetSmithyProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps"></a>

Properties for creating a Smithy-based Gateway Target.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const gatewayTargetSmithyProps: bedrock_agentcore.GatewayTargetSmithyProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.smithyModel">smithyModel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The Smithy model defining the API. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | Credential providers for authentication. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target The description can have up to 200 characters.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway this target belongs to.

---

##### `smithyModel`<sup>Required</sup> <a name="smithyModel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.smithyModel"></a>

```typescript
public readonly smithyModel: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The Smithy model defining the API.

---

##### `credentialProviderConfigurations`<sup>Optional</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetSmithyProps.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]
- *Default:* [GatewayCredentialProvider.iamRole()]

Credential providers for authentication.

---

### McpConfiguration <a name="McpConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration"></a>

MCP protocol configuration The configuration for the Model Context Protocol (MCP).

This protocol enables communication between Amazon Bedrock Agent and external tools.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const mcpConfiguration: bedrock_agentcore.McpConfiguration = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.instructions">instructions</a></code> | <code>string</code> | The instructions for using the Model Context Protocol gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.searchType">searchType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewaySearchType</code> | The search type for the Model Context Protocol gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.supportedVersions">supportedVersions</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion[]</code> | The supported versions of the Model Context Protocol. |

---

##### `instructions`<sup>Optional</sup> <a name="instructions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.instructions"></a>

```typescript
public readonly instructions: string;
```

- *Type:* string
- *Default:* No instructions provided

The instructions for using the Model Context Protocol gateway.

These instructions provide guidance on how to interact with the gateway.

---

##### `searchType`<sup>Optional</sup> <a name="searchType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.searchType"></a>

```typescript
public readonly searchType: McpGatewaySearchType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewaySearchType
- *Default:* No search type specified

The search type for the Model Context Protocol gateway.

This field specifies how the gateway handles search operations.

---

##### `supportedVersions`<sup>Optional</sup> <a name="supportedVersions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration.property.supportedVersions"></a>

```typescript
public readonly supportedVersions: MCPProtocolVersion[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion[]
- *Default:* No specific versions specified

The supported versions of the Model Context Protocol.

This field specifies which versions of the protocol the gateway can use.

---

### McpGatewayTargetCommonProps <a name="McpGatewayTargetCommonProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps"></a>

Common properties for all Gateway Target types.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const mcpGatewayTargetCommonProps: bedrock_agentcore.McpGatewayTargetCommonProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps.property.gatewayTargetName">gatewayTargetName</a></code> | <code>string</code> | The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps.property.description">description</a></code> | <code>string</code> | Optional description for the gateway target The description can have up to 200 characters. |

---

##### `gatewayTargetName`<sup>Required</sup> <a name="gatewayTargetName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps.property.gatewayTargetName"></a>

```typescript
public readonly gatewayTargetName: string;
```

- *Type:* string

The name of the gateway target The name must be unique within the gateway Pattern: ^([0-9a-zA-Z][-]?){1,100}$.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewayTargetCommonProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the gateway target The description can have up to 200 characters.

---

### MemoryAttributes <a name="MemoryAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes"></a>

Attributes for specifying an imported Memory.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const memoryAttributes: bedrock_agentcore.MemoryAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.memoryArn">memoryArn</a></code> | <code>string</code> | The ARN of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.roleArn">roleArn</a></code> | <code>string</code> | The ARN of the IAM role associated to the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | The created timestamp of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.kmsKeyArn">kmsKeyArn</a></code> | <code>string</code> | Optional KMS encryption key associated with this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.status">status</a></code> | <code>string</code> | The status of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.updatedAt">updatedAt</a></code> | <code>string</code> | When this memory was last updated. |

---

##### `memoryArn`<sup>Required</sup> <a name="memoryArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.memoryArn"></a>

```typescript
public readonly memoryArn: string;
```

- *Type:* string

The ARN of the memory.

---

##### `roleArn`<sup>Required</sup> <a name="roleArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.roleArn"></a>

```typescript
public readonly roleArn: string;
```

- *Type:* string

The ARN of the IAM role associated to the memory.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* undefined - No created timestamp is provided

The created timestamp of the memory.

---

##### `kmsKeyArn`<sup>Optional</sup> <a name="kmsKeyArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.kmsKeyArn"></a>

```typescript
public readonly kmsKeyArn: string;
```

- *Type:* string
- *Default:* undefined - An AWS managed key is used

Optional KMS encryption key associated with this memory.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string
- *Default:* undefined - No status is provided

The status of the memory.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryAttributes.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string
- *Default:* undefined - No last updated timestamp is provided

When this memory was last updated.

---

### MemoryProps <a name="MemoryProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps"></a>

Properties for creating a Memory resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const memoryProps: bedrock_agentcore.MemoryProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.memoryName">memoryName</a></code> | <code>string</code> | The name of the memory Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.description">description</a></code> | <code>string</code> | Optional description for the memory Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the memory to access AWS services when using custom strategies. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.expirationDuration">expirationDuration</a></code> | <code>aws-cdk-lib.Duration</code> | Short-term memory expiration in days (between 7 and 365). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | Custom KMS key to use for encryption. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.memoryStrategies">memoryStrategies</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy[]</code> | If you need long-term memory for context recall across sessions, you can setup memory extraction strategies to extract the relevant memory from the raw events. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags (optional) A list of key:value pairs of tags to apply to this memory resource. |

---

##### `memoryName`<sup>Required</sup> <a name="memoryName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.memoryName"></a>

```typescript
public readonly memoryName: string;
```

- *Type:* string

The name of the memory Valid characters are a-z, A-Z, 0-9, _ (underscore) The name must start with a letter and can be up to 48 characters long Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the memory Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces The description can have up to 200 characters.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole
- *Default:* A new role will be created.

The IAM role that provides permissions for the memory to access AWS services when using custom strategies.

---

##### `expirationDuration`<sup>Optional</sup> <a name="expirationDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.expirationDuration"></a>

```typescript
public readonly expirationDuration: Duration;
```

- *Type:* aws-cdk-lib.Duration
- *Default:* 90

Short-term memory expiration in days (between 7 and 365).

Sets the short-term (raw event) memory retention.
Events older than the specified duration will expire and no longer be stored.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey
- *Default:* Your data is encrypted with a key that AWS owns and manages for you

Custom KMS key to use for encryption.

---

##### `memoryStrategies`<sup>Optional</sup> <a name="memoryStrategies" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.memoryStrategies"></a>

```typescript
public readonly memoryStrategies: IMemoryStrategy[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy[]
- *Default:* No extraction strategies (short term memory only)

If you need long-term memory for context recall across sessions, you can setup memory extraction strategies to extract the relevant memory from the raw events.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* {} - no tags

Tags (optional) A list of key:value pairs of tags to apply to this memory resource.

---

### MemoryStrategyCommonProps <a name="MemoryStrategyCommonProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps"></a>

Configuration parameters common for any memory strategy.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const memoryStrategyCommonProps: bedrock_agentcore.MemoryStrategyCommonProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.name">name</a></code> | <code>string</code> | The name for the strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.namespaces">namespaces</a></code> | <code>string[]</code> | The namespaces for the strategy Represents a namespace for organizing memory data Use a hierarchical format separated by forward slashes (/). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.description">description</a></code> | <code>string</code> | The description of the strategy. |

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name for the strategy.

---

##### `namespaces`<sup>Required</sup> <a name="namespaces" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.namespaces"></a>

```typescript
public readonly namespaces: string[];
```

- *Type:* string[]

The namespaces for the strategy Represents a namespace for organizing memory data Use a hierarchical format separated by forward slashes (/).

Use a hierarchical format separated by forward slashes (/) to organize namespaces logically.
You can include these defined variables:

- {sessionId} - the user identifier to be created in the CreateEvent API
- {memoryStrategyId} - an identifier for an extraction strategy
- {sessionId} - an identifier for each session

Example namespace path:
/strategies/{memoryStrategyId}/actions/{actionId}/sessions/{sessionId}

After memory creation, this namespace might look like:
/actor/actor-3afc5aa8fef9/strategy/summarization-fy5c5fwc7/session/session-qj7tpd1kvr8

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the strategy.

---

### OAuthConfiguration <a name="OAuthConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration"></a>

OAuth configuration.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const oAuthConfiguration: bedrock_agentcore.OAuthConfiguration = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.providerArn">providerArn</a></code> | <code>string</code> | The OAuth credential provider ARN. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.scopes">scopes</a></code> | <code>string[]</code> | The OAuth scopes for the credential provider. These scopes define the level of access requested from the OAuth provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.secretArn">secretArn</a></code> | <code>string</code> | The ARN of the Secrets Manager secret containing OAuth credentials (client ID and secret). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.customParameters">customParameters</a></code> | <code>{[ key: string ]: string}</code> | Custom parameters for the OAuth flow. |

---

##### `providerArn`<sup>Required</sup> <a name="providerArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.providerArn"></a>

```typescript
public readonly providerArn: string;
```

- *Type:* string

The OAuth credential provider ARN.

This is returned when creating the OAuth credential provider via Console or API.
Format: arn:aws:bedrock-agentcore:region:account:token-vault/id/oauth2credentialprovider/name
Required: Yes

---

##### `scopes`<sup>Required</sup> <a name="scopes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.scopes"></a>

```typescript
public readonly scopes: string[];
```

- *Type:* string[]

The OAuth scopes for the credential provider. These scopes define the level of access requested from the OAuth provider.

Array Members: Minimum number of 0 items. Maximum number of 100 items.
Length Constraints: Minimum length of 1. Maximum length of 64.
Required: Yes

---

##### `secretArn`<sup>Required</sup> <a name="secretArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.secretArn"></a>

```typescript
public readonly secretArn: string;
```

- *Type:* string

The ARN of the Secrets Manager secret containing OAuth credentials (client ID and secret).

This is returned when creating the OAuth credential provider via Console or API.
Format: arn:aws:secretsmanager:region:account:secret:name
Required: Yes

---

##### `customParameters`<sup>Optional</sup> <a name="customParameters" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration.property.customParameters"></a>

```typescript
public readonly customParameters: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No custom parameters

Custom parameters for the OAuth flow.

---

### OverrideConfig <a name="OverrideConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig"></a>

Configuration for overriding model and prompt template.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const overrideConfig: bedrock_agentcore.OverrideConfig = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig.property.appendToPrompt">appendToPrompt</a></code> | <code>string</code> | The prompt that will be appended to the system prompt to define the model's memory consolidation/extraction strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig.property.model">model</a></code> | <code>@aws-cdk/aws-bedrock-alpha.IBedrockInvokable</code> | The model to use for consolidation/extraction. |

---

##### `appendToPrompt`<sup>Required</sup> <a name="appendToPrompt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig.property.appendToPrompt"></a>

```typescript
public readonly appendToPrompt: string;
```

- *Type:* string

The prompt that will be appended to the system prompt to define the model's memory consolidation/extraction strategy.

This configuration provides customization to how the model identifies and extracts
relevant information for memory storage. You can use the default user prompt or create a customized one.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/system-prompts.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/system-prompts.html)

---

##### `model`<sup>Required</sup> <a name="model" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig.property.model"></a>

```typescript
public readonly model: IBedrockInvokable;
```

- *Type:* @aws-cdk/aws-bedrock-alpha.IBedrockInvokable

The model to use for consolidation/extraction.

---

### OverrideStrategyProps <a name="OverrideStrategyProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps"></a>

Configuration parameters for a memory strategy that overrides existing built-in default prompts/models.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const overrideStrategyProps: bedrock_agentcore.OverrideStrategyProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.name">name</a></code> | <code>string</code> | The name for the strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.namespaces">namespaces</a></code> | <code>string[]</code> | The namespaces for the strategy Represents a namespace for organizing memory data Use a hierarchical format separated by forward slashes (/). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.description">description</a></code> | <code>string</code> | The description of the strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.customConsolidation">customConsolidation</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig</code> | The configuration for the custom consolidation. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.customExtraction">customExtraction</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig</code> | The configuration for the custom extraction. |

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name for the strategy.

---

##### `namespaces`<sup>Required</sup> <a name="namespaces" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.namespaces"></a>

```typescript
public readonly namespaces: string[];
```

- *Type:* string[]

The namespaces for the strategy Represents a namespace for organizing memory data Use a hierarchical format separated by forward slashes (/).

Use a hierarchical format separated by forward slashes (/) to organize namespaces logically.
You can include these defined variables:

- {sessionId} - the user identifier to be created in the CreateEvent API
- {memoryStrategyId} - an identifier for an extraction strategy
- {sessionId} - an identifier for each session

Example namespace path:
/strategies/{memoryStrategyId}/actions/{actionId}/sessions/{sessionId}

After memory creation, this namespace might look like:
/actor/actor-3afc5aa8fef9/strategy/summarization-fy5c5fwc7/session/session-qj7tpd1kvr8

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the strategy.

---

##### `customConsolidation`<sup>Optional</sup> <a name="customConsolidation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.customConsolidation"></a>

```typescript
public readonly customConsolidation: OverrideConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig
- *Default:* No custom extraction

The configuration for the custom consolidation.

This configuration provides customization to how the model identifies
and extracts relevant information for memory storage.

---

##### `customExtraction`<sup>Optional</sup> <a name="customExtraction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps.property.customExtraction"></a>

```typescript
public readonly customExtraction: OverrideConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig
- *Default:* No custom extraction

The configuration for the custom extraction.

This configuration provides customization to how the model identifies
and extracts relevant information for memory storage.

---

### RecordingConfig <a name="RecordingConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig"></a>

Recording configuration for browser.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const recordingConfig: bedrock_agentcore.RecordingConfig = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig.property.enabled">enabled</a></code> | <code>boolean</code> | Whether recording is enabled. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig.property.s3Location">s3Location</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | S3 Location Configuration. |

---

##### `enabled`<sup>Optional</sup> <a name="enabled" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig.property.enabled"></a>

```typescript
public readonly enabled: boolean;
```

- *Type:* boolean
- *Default:* false

Whether recording is enabled.

---

##### `s3Location`<sup>Optional</sup> <a name="s3Location" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RecordingConfig.property.s3Location"></a>

```typescript
public readonly s3Location: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location
- *Default:* undefined

S3 Location Configuration.

---

### RuntimeEndpointAttributes <a name="RuntimeEndpointAttributes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes"></a>

Attributes for importing an existing Runtime Endpoint.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const runtimeEndpointAttributes: bedrock_agentcore.RuntimeEndpointAttributes = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the parent agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.agentRuntimeEndpointArn">agentRuntimeEndpointArn</a></code> | <code>string</code> | The ARN of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.endpointName">endpointName</a></code> | <code>string</code> | The name of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.createdAt">createdAt</a></code> | <code>string</code> | When the endpoint was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.description">description</a></code> | <code>string</code> | The description of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.endpointId">endpointId</a></code> | <code>string</code> | The unique identifier of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | When the endpoint was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.liveVersion">liveVersion</a></code> | <code>string</code> | The live version of the agent runtime that is currently serving requests. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.status">status</a></code> | <code>string</code> | The current status of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.targetVersion">targetVersion</a></code> | <code>string</code> | The target version the endpoint is transitioning to (during updates). |

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the parent agent runtime.

---

##### `agentRuntimeEndpointArn`<sup>Required</sup> <a name="agentRuntimeEndpointArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.agentRuntimeEndpointArn"></a>

```typescript
public readonly agentRuntimeEndpointArn: string;
```

- *Type:* string

The ARN of the runtime endpoint.

---

##### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.endpointName"></a>

```typescript
public readonly endpointName: string;
```

- *Type:* string

The name of the runtime endpoint.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string
- *Default:* Creation time not available

When the endpoint was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

The description of the runtime endpoint.

---

##### `endpointId`<sup>Optional</sup> <a name="endpointId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.endpointId"></a>

```typescript
public readonly endpointId: string;
```

- *Type:* string
- *Default:* Endpoint ID not available

The unique identifier of the runtime endpoint.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string
- *Default:* Last update time not available

When the endpoint was last updated.

---

##### `liveVersion`<sup>Optional</sup> <a name="liveVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.liveVersion"></a>

```typescript
public readonly liveVersion: string;
```

- *Type:* string
- *Default:* Live version not available

The live version of the agent runtime that is currently serving requests.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string
- *Default:* Status not available

The current status of the runtime endpoint.

---

##### `targetVersion`<sup>Optional</sup> <a name="targetVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointAttributes.property.targetVersion"></a>

```typescript
public readonly targetVersion: string;
```

- *Type:* string
- *Default:* Target version not available

The target version the endpoint is transitioning to (during updates).

---

### RuntimeEndpointProps <a name="RuntimeEndpointProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps"></a>

Properties for creating a Bedrock Agent Core Runtime Endpoint resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const runtimeEndpointProps: bedrock_agentcore.RuntimeEndpointProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The ID of the agent runtime to associate with this endpoint This is the unique identifier of the runtime resource Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,99}-[a-zA-Z0-9]{10}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.endpointName">endpointName</a></code> | <code>string</code> | The name of the agent runtime endpoint Valid characters are a-z, A-Z, 0-9, _ (underscore) Must start with a letter and can be up to 48 characters long Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime to use for this endpoint If not specified, the endpoint will point to version "1" of the runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.description">description</a></code> | <code>string</code> | Optional description for the agent runtime endpoint Length Minimum: 1 ,  Maximum: 256. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags for the agent runtime endpoint A list of key:value pairs of tags to apply to this RuntimeEndpoint resource Pattern: ^[a-zA-Z0-9\s._:/=+@-]*$. |

---

##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The ID of the agent runtime to associate with this endpoint This is the unique identifier of the runtime resource Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,99}-[a-zA-Z0-9]{10}$.

---

##### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.endpointName"></a>

```typescript
public readonly endpointName: string;
```

- *Type:* string

The name of the agent runtime endpoint Valid characters are a-z, A-Z, 0-9, _ (underscore) Must start with a letter and can be up to 48 characters long Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$.

---

##### `agentRuntimeVersion`<sup>Optional</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string
- *Default:* "1"

The version of the agent runtime to use for this endpoint If not specified, the endpoint will point to version "1" of the runtime.

Pattern: ^([1-9][0-9]{0,4})$

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

Optional description for the agent runtime endpoint Length Minimum: 1 ,  Maximum: 256.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* {} - no tags

Tags for the agent runtime endpoint A list of key:value pairs of tags to apply to this RuntimeEndpoint resource Pattern: ^[a-zA-Z0-9\s._:/=+@-]*$.

---

### RuntimeProps <a name="RuntimeProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps"></a>

Properties for creating a Bedrock Agent Core Runtime resource.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const runtimeProps: bedrock_agentcore.RuntimeProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.agentRuntimeArtifact">agentRuntimeArtifact</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact</code> | The artifact configuration for the agent runtime Contains the container configuration with ECR URI. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.runtimeName">runtimeName</a></code> | <code>string</code> | The name of the agent runtime Valid characters are a-z, A-Z, 0-9, _ (underscore) Must start with a letter and can be up to 48 characters long Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.authorizerConfiguration">authorizerConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration</code> | Authorizer configuration for the agent runtime Use RuntimeAuthorizerConfiguration static methods to create the configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.description">description</a></code> | <code>string</code> | Optional description for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.environmentVariables">environmentVariables</a></code> | <code>{[ key: string ]: string}</code> | Environment variables for the agent runtime - Maximum 50 environment variables - Key: Must be 1-100 characters, start with letter or underscore, contain only letters, numbers, and underscores - Value: Must be 0-2048 characters (per CloudFormation specification). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the agent runtime If not provided, a role will be created automatically. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.networkConfiguration">networkConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration</code> | Network configuration for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.protocolConfiguration">protocolConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType</code> | Protocol configuration for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.tags">tags</a></code> | <code>{[ key: string ]: string}</code> | Tags for the agent runtime A list of key:value pairs of tags to apply to this Runtime resource. |

---

##### `agentRuntimeArtifact`<sup>Required</sup> <a name="agentRuntimeArtifact" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.agentRuntimeArtifact"></a>

```typescript
public readonly agentRuntimeArtifact: AgentRuntimeArtifact;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact

The artifact configuration for the agent runtime Contains the container configuration with ECR URI.

---

##### `runtimeName`<sup>Required</sup> <a name="runtimeName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.runtimeName"></a>

```typescript
public readonly runtimeName: string;
```

- *Type:* string

The name of the agent runtime Valid characters are a-z, A-Z, 0-9, _ (underscore) Must start with a letter and can be up to 48 characters long Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$.

---

##### `authorizerConfiguration`<sup>Optional</sup> <a name="authorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.authorizerConfiguration"></a>

```typescript
public readonly authorizerConfiguration: RuntimeAuthorizerConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration
- *Default:* RuntimeAuthorizerConfiguration.iam() (IAM authentication)

Authorizer configuration for the agent runtime Use RuntimeAuthorizerConfiguration static methods to create the configuration.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description Length Minimum: 1 , Maximum: 1200

Optional description for the agent runtime.

---

##### `environmentVariables`<sup>Optional</sup> <a name="environmentVariables" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.environmentVariables"></a>

```typescript
public readonly environmentVariables: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* No environment variables

Environment variables for the agent runtime - Maximum 50 environment variables - Key: Must be 1-100 characters, start with letter or underscore, contain only letters, numbers, and underscores - Value: Must be 0-2048 characters (per CloudFormation specification).

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole
- *Default:* A new role will be created

The IAM role that provides permissions for the agent runtime If not provided, a role will be created automatically.

---

##### `networkConfiguration`<sup>Optional</sup> <a name="networkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.networkConfiguration"></a>

```typescript
public readonly networkConfiguration: RuntimeNetworkConfiguration;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration
- *Default:* RuntimeNetworkConfiguration.usingPublicNetwork()

Network configuration for the agent runtime.

---

##### `protocolConfiguration`<sup>Optional</sup> <a name="protocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.protocolConfiguration"></a>

```typescript
public readonly protocolConfiguration: ProtocolType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType
- *Default:* ProtocolType.HTTP

Protocol configuration for the agent runtime.

---

##### `tags`<sup>Optional</sup> <a name="tags" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeProps.property.tags"></a>

```typescript
public readonly tags: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}
- *Default:* {} - no tags

Tags for the agent runtime A list of key:value pairs of tags to apply to this Runtime resource.

---

### SchemaDefinition <a name="SchemaDefinition" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition"></a>

Schema definition for tool input/output.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const schemaDefinition: bedrock_agentcore.SchemaDefinition = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.type">type</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType</code> | The type of the schema definition. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.description">description</a></code> | <code>string</code> | The description of the schema definition. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.items">items</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition</code> | The items in the schema definition. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.properties">properties</a></code> | <code>{[ key: string ]: @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition}</code> | The properties of the schema definition. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.required">required</a></code> | <code>string[]</code> | The required fields in the schema definition. |

---

##### `type`<sup>Required</sup> <a name="type" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.type"></a>

```typescript
public readonly type: SchemaDefinitionType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType

The type of the schema definition.

This field specifies the data type of the schema.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string
- *Default:* No description

The description of the schema definition.

This description provides information about the purpose and usage of the schema.

---

##### `items`<sup>Optional</sup> <a name="items" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.items"></a>

```typescript
public readonly items: SchemaDefinition;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition
- *Default:* No items definition

The items in the schema definition.

This field is used for array types to define the structure of the array elements.

---

##### `properties`<sup>Optional</sup> <a name="properties" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.properties"></a>

```typescript
public readonly properties: {[ key: string ]: SchemaDefinition};
```

- *Type:* {[ key: string ]: @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition}
- *Default:* No properties

The properties of the schema definition.

These properties define the fields in the schema.

---

##### `required`<sup>Optional</sup> <a name="required" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition.property.required"></a>

```typescript
public readonly required: string[];
```

- *Type:* string[]
- *Default:* No required fields

The required fields in the schema definition.

These fields must be provided when using the schema.

---

### TargetConfigurationConfig <a name="TargetConfigurationConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.TargetConfigurationConfig"></a>

Configuration returned by binding a target configuration.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.TargetConfigurationConfig.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const targetConfigurationConfig: bedrock_agentcore.TargetConfigurationConfig = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.TargetConfigurationConfig.property.bound">bound</a></code> | <code>boolean</code> | Indicates that the configuration has been successfully bound. |

---

##### `bound`<sup>Required</sup> <a name="bound" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.TargetConfigurationConfig.property.bound"></a>

```typescript
public readonly bound: boolean;
```

- *Type:* boolean

Indicates that the configuration has been successfully bound.

---

### ToolDefinition <a name="ToolDefinition" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition"></a>

Tool definition for inline payload.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const toolDefinition: bedrock_agentcore.ToolDefinition = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.description">description</a></code> | <code>string</code> | The description of the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.inputSchema">inputSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition</code> | The input schema for the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.name">name</a></code> | <code>string</code> | The name of the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.outputSchema">outputSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition</code> | The output schema for the tool. |

---

##### `description`<sup>Required</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the tool.

This description provides information about the purpose and usage of the tool.

---

##### `inputSchema`<sup>Required</sup> <a name="inputSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.inputSchema"></a>

```typescript
public readonly inputSchema: SchemaDefinition;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition

The input schema for the tool.

This schema defines the structure of the input that the tool accepts.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the tool.

This name identifies the tool in the Model Context Protocol.

---

##### `outputSchema`<sup>Optional</sup> <a name="outputSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition.property.outputSchema"></a>

```typescript
public readonly outputSchema: SchemaDefinition;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinition
- *Default:* No output schema

The output schema for the tool.

This schema defines the structure of the output that the tool produces.

---

### VpcConfigProps <a name="VpcConfigProps" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps"></a>

VPC configuration properties.

Only used when network mode is VPC.

#### Initializer <a name="Initializer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

const vpcConfigProps: bedrock_agentcore.VpcConfigProps = { ... }
```

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.vpc">vpc</a></code> | <code>aws-cdk-lib.aws_ec2.IVpc</code> | The VPC to deploy the resource to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.allowAllOutbound">allowAllOutbound</a></code> | <code>boolean</code> | Whether to allow the resource to send all network traffic (except ipv6). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.securityGroups">securityGroups</a></code> | <code>aws-cdk-lib.aws_ec2.ISecurityGroup[]</code> | The list of security groups to associate with the resource's network interfaces. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.vpcSubnets">vpcSubnets</a></code> | <code>aws-cdk-lib.aws_ec2.SubnetSelection</code> | Where to place the network interfaces within the VPC. |

---

##### `vpc`<sup>Required</sup> <a name="vpc" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.vpc"></a>

```typescript
public readonly vpc: IVpc;
```

- *Type:* aws-cdk-lib.aws_ec2.IVpc

The VPC to deploy the resource to.

---

##### `allowAllOutbound`<sup>Optional</sup> <a name="allowAllOutbound" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.allowAllOutbound"></a>

```typescript
public readonly allowAllOutbound: boolean;
```

- *Type:* boolean
- *Default:* true

Whether to allow the resource to send all network traffic (except ipv6).

If set to false, you must individually add traffic rules to allow the
resource to connect to network targets.

Do not specify this property if the `securityGroups` property is set.
Instead, configure `allowAllOutbound` directly on the security group.

---

##### `securityGroups`<sup>Optional</sup> <a name="securityGroups" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.securityGroups"></a>

```typescript
public readonly securityGroups: ISecurityGroup[];
```

- *Type:* aws-cdk-lib.aws_ec2.ISecurityGroup[]
- *Default:* If the resource is placed within a VPC and a security group is not specified by this prop, a dedicated security group will be created for this resource.

The list of security groups to associate with the resource's network interfaces.

Only used if 'vpc' is supplied.

---

##### `vpcSubnets`<sup>Optional</sup> <a name="vpcSubnets" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps.property.vpcSubnets"></a>

```typescript
public readonly vpcSubnets: SubnetSelection;
```

- *Type:* aws-cdk-lib.aws_ec2.SubnetSelection
- *Default:* the Vpc default strategy if not specified

Where to place the network interfaces within the VPC.

This requires `vpc` to be specified in order for interfaces to actually be
placed in the subnets. If `vpc` is not specify, this will raise an error.

---

## Classes <a name="Classes" id="Classes"></a>

### AgentRuntimeArtifact <a name="AgentRuntimeArtifact" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact"></a>

Abstract base class for agent runtime artifacts.

Provides methods to reference container images from ECR repositories or local assets.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.AgentRuntimeArtifact()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.bind">bind</a></code> | Called when the image is used by a Runtime to handle side effects like permissions. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.bind"></a>

```typescript
public bind(scope: Construct, runtime: Runtime): void
```

Called when the image is used by a Runtime to handle side effects like permissions.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

###### `runtime`<sup>Required</sup> <a name="runtime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.bind.parameter.runtime"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromAsset">fromAsset</a></code> | Reference an agent runtime artifact that's constructed directly from sources on disk. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromEcrRepository">fromEcrRepository</a></code> | Reference an image in an ECR repository. |

---

##### `fromAsset` <a name="fromAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AgentRuntimeArtifact.fromAsset(directory: string, options?: DockerImageAssetOptions)
```

Reference an agent runtime artifact that's constructed directly from sources on disk.

###### `directory`<sup>Required</sup> <a name="directory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromAsset.parameter.directory"></a>

- *Type:* string

The directory where the Dockerfile is stored.

---

###### `options`<sup>Optional</sup> <a name="options" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromAsset.parameter.options"></a>

- *Type:* aws-cdk-lib.aws_ecr_assets.DockerImageAssetOptions

The options to further configure the selected image.

---

##### `fromEcrRepository` <a name="fromEcrRepository" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromEcrRepository"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AgentRuntimeArtifact.fromEcrRepository(repository: IRepository, tag?: string)
```

Reference an image in an ECR repository.

###### `repository`<sup>Required</sup> <a name="repository" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromEcrRepository.parameter.repository"></a>

- *Type:* aws-cdk-lib.aws_ecr.IRepository

---

###### `tag`<sup>Optional</sup> <a name="tag" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AgentRuntimeArtifact.fromEcrRepository.parameter.tag"></a>

- *Type:* string

---



### ApiKeyCredentialLocation <a name="ApiKeyCredentialLocation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation"></a>

API Key location within the request.


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.header">header</a></code> | Create a header-based API key credential location. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.queryParameter">queryParameter</a></code> | Create a query parameter-based API key credential location. |

---

##### `header` <a name="header" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.header"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ApiKeyCredentialLocation.header(config?: ApiKeyAdditionalConfiguration)
```

Create a header-based API key credential location.

###### `config`<sup>Optional</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.header.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration

Optional configuration for the credential location.

---

##### `queryParameter` <a name="queryParameter" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.queryParameter"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ApiKeyCredentialLocation.queryParameter(config?: ApiKeyAdditionalConfiguration)
```

Create a query parameter-based API key credential location.

###### `config`<sup>Optional</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.queryParameter.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyAdditionalConfiguration

Optional configuration for the credential location.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialLocationType">credentialLocationType</a></code> | <code>string</code> | The type of credential location (HEADER or QUERY_PARAMETER). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialParameterName">credentialParameterName</a></code> | <code>string</code> | The name of the credential parameter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialPrefix">credentialPrefix</a></code> | <code>string</code> | The prefix for the credential value. |

---

##### `credentialLocationType`<sup>Required</sup> <a name="credentialLocationType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialLocationType"></a>

```typescript
public readonly credentialLocationType: string;
```

- *Type:* string

The type of credential location (HEADER or QUERY_PARAMETER).

---

##### `credentialParameterName`<sup>Required</sup> <a name="credentialParameterName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialParameterName"></a>

```typescript
public readonly credentialParameterName: string;
```

- *Type:* string

The name of the credential parameter.

---

##### `credentialPrefix`<sup>Optional</sup> <a name="credentialPrefix" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation.property.credentialPrefix"></a>

```typescript
public readonly credentialPrefix: string;
```

- *Type:* string

The prefix for the credential value.

---


### ApiKeyCredentialProviderConfiguration <a name="ApiKeyCredentialProviderConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider

API Key credential provider configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.ApiKeyCredentialProviderConfiguration(configuration: ApiKeyCredentialProviderProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.Initializer.parameter.configuration">configuration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps</code> | *No description.* |

---

##### `configuration`<sup>Required</sup> <a name="configuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.Initializer.parameter.configuration"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.grantNeededPermissionsToRole">grantNeededPermissionsToRole</a></code> | Grant the needed permissions to the role for API key authentication. |

---

##### `grantNeededPermissionsToRole` <a name="grantNeededPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.grantNeededPermissionsToRole"></a>

```typescript
public grantNeededPermissionsToRole(role: IRole): Grant
```

Grant the needed permissions to the role for API key authentication.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.grantNeededPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.credentialLocation">credentialLocation</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation</code> | The location configuration for the API key credential. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.credentialProviderType">credentialProviderType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType</code> | The credential provider type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.providerArn">providerArn</a></code> | <code>string</code> | The ARN of the API key provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.secretArn">secretArn</a></code> | <code>string</code> | The ARN of the Secrets Manager secret. |

---

##### `credentialLocation`<sup>Required</sup> <a name="credentialLocation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.credentialLocation"></a>

```typescript
public readonly credentialLocation: ApiKeyCredentialLocation;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialLocation

The location configuration for the API key credential.

---

##### `credentialProviderType`<sup>Required</sup> <a name="credentialProviderType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.credentialProviderType"></a>

```typescript
public readonly credentialProviderType: CredentialProviderType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType

The credential provider type.

---

##### `providerArn`<sup>Required</sup> <a name="providerArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.providerArn"></a>

```typescript
public readonly providerArn: string;
```

- *Type:* string

The ARN of the API key provider.

---

##### `secretArn`<sup>Required</sup> <a name="secretArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration.property.secretArn"></a>

```typescript
public readonly secretArn: string;
```

- *Type:* string

The ARN of the Secrets Manager secret.

---


### ApiSchema <a name="ApiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema"></a>

Represents the concept of an API Schema for a Gateway Target.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.ApiSchema(s3File?: Location, bucketOwnerAccountId?: string, inlineSchema?: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.inlineSchema">inlineSchema</a></code> | <code>string</code> | *No description.* |

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.s3File"></a>

- *Type:* aws-cdk-lib.aws_s3.Location

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.bucketOwnerAccountId"></a>

- *Type:* string

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.Initializer.parameter.inlineSchema"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromInline">fromInline</a></code> | Creates an API Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates an API Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromS3File">fromS3File</a></code> | Creates an API Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ApiSchema.fromInline(schema: string)
```

Creates an API Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromInline.parameter.schema"></a>

- *Type:* string

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ApiSchema.fromLocalAsset(path: string)
```

Creates an API Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the OpenAPI schema for the action group.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ApiSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates an API Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.inlineSchema">inlineSchema</a></code> | <code>string</code> | The inline OpenAPI schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the API schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: string;
```

- *Type:* string

The inline OpenAPI schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the API schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### AssetApiSchema <a name="AssetApiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema"></a>

API Schema from a local asset.

The asset is uploaded to an S3 staging bucket, then moved to its final location
by CloudFormation during deployment.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.AssetApiSchema(path: string, options?: AssetOptions)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.Initializer.parameter.path">path</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.Initializer.parameter.options">options</a></code> | <code>aws-cdk-lib.aws_s3_assets.AssetOptions</code> | *No description.* |

---

##### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.Initializer.parameter.path"></a>

- *Type:* string

---

##### `options`<sup>Optional</sup> <a name="options" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.Initializer.parameter.options"></a>

- *Type:* aws-cdk-lib.aws_s3_assets.AssetOptions

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.bind">bind</a></code> | Binds this API schema to a construct scope. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Binds this API schema to a construct scope.

This method initializes the S3 asset if it hasn't been initialized yet.
Must be called before rendering the schema as CFN properties.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope to bind to.

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromInline">fromInline</a></code> | Creates an API Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates an API Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromS3File">fromS3File</a></code> | Creates an API Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetApiSchema.fromInline(schema: string)
```

Creates an API Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromInline.parameter.schema"></a>

- *Type:* string

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetApiSchema.fromLocalAsset(path: string)
```

Creates an API Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the OpenAPI schema for the action group.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetApiSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates an API Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.inlineSchema">inlineSchema</a></code> | <code>string</code> | The inline OpenAPI schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the API schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: string;
```

- *Type:* string

The inline OpenAPI schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetApiSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the API schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### AssetToolSchema <a name="AssetToolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema"></a>

Tool Schema from a local asset.

The asset is uploaded to an S3 staging bucket, then moved to its final location
by CloudFormation during deployment.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.AssetToolSchema(path: string, options?: AssetOptions)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.Initializer.parameter.path">path</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.Initializer.parameter.options">options</a></code> | <code>aws-cdk-lib.aws_s3_assets.AssetOptions</code> | *No description.* |

---

##### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.Initializer.parameter.path"></a>

- *Type:* string

---

##### `options`<sup>Optional</sup> <a name="options" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.Initializer.parameter.options"></a>

- *Type:* aws-cdk-lib.aws_s3_assets.AssetOptions

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.bind">bind</a></code> | Binds this tool schema to a construct scope. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Binds this tool schema to a construct scope.

This method initializes the S3 asset if it hasn't been initialized yet.
Must be called before rendering the schema as CFN properties.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope to bind to.

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromInline">fromInline</a></code> | Creates a Tool Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates a tool Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromS3File">fromS3File</a></code> | Creates a Tool Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetToolSchema.fromInline(schema: ToolDefinition[])
```

Creates a Tool Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromInline.parameter.schema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetToolSchema.fromLocalAsset(path: string)
```

Creates a tool Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the function schema for the tool.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.AssetToolSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates a Tool Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.inlineSchema">inlineSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | The inline tool schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the tool schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: ToolDefinition[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

The inline tool schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.AssetToolSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the tool schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### BrowserNetworkConfiguration <a name="BrowserNetworkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration"></a>

Network configuration for the Browser tool.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.BrowserNetworkConfiguration(mode: string, scope?: Construct, vpcConfig?: VpcConfigProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.mode">mode</a></code> | <code>string</code> | - the network mode to use for the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.vpcConfig">vpcConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps</code> | *No description.* |

---

##### `mode`<sup>Required</sup> <a name="mode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.mode"></a>

- *Type:* string

the network mode to use for the tool.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `vpcConfig`<sup>Optional</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.Initializer.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingPublicNetwork">usingPublicNetwork</a></code> | Creates a public network configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingVpc">usingVpc</a></code> | Creates a network configuration from a VPC configuration. |

---

##### `usingPublicNetwork` <a name="usingPublicNetwork" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingPublicNetwork"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserNetworkConfiguration.usingPublicNetwork()
```

Creates a public network configuration.

PUBLIC is the default network mode.

##### `usingVpc` <a name="usingVpc" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingVpc"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.BrowserNetworkConfiguration.usingVpc(scope: Construct, vpcConfig: VpcConfigProps)
```

Creates a network configuration from a VPC configuration.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingVpc.parameter.scope"></a>

- *Type:* constructs.Construct

---

###### `vpcConfig`<sup>Required</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.usingVpc.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

The VPC configuration.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.networkMode">networkMode</a></code> | <code>string</code> | The network mode to use. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The connections object to the network. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.scope">scope</a></code> | <code>constructs.Construct</code> | The scope to create the resource in. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.vpcSubnets">vpcSubnets</a></code> | <code>aws-cdk-lib.aws_ec2.SubnetSelection</code> | The VPC subnets to use. |

---

##### `networkMode`<sup>Required</sup> <a name="networkMode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.networkMode"></a>

```typescript
public readonly networkMode: string;
```

- *Type:* string

The network mode to use.

Configure the security level for agent
execution to control access, isolate resources, and protect sensitive data.

---

##### `connections`<sup>Optional</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The connections object to the network.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.scope"></a>

```typescript
public readonly scope: Construct;
```

- *Type:* constructs.Construct

The scope to create the resource in.

---

##### `vpcSubnets`<sup>Optional</sup> <a name="vpcSubnets" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserNetworkConfiguration.property.vpcSubnets"></a>

```typescript
public readonly vpcSubnets: SubnetSelection;
```

- *Type:* aws-cdk-lib.aws_ec2.SubnetSelection

The VPC subnets to use.

---


### BuiltInMemoryStrategy <a name="BuiltInMemoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy

If you need long-term memory for context recall across sessions, you can setup memory extraction strategies to extract the relevant memory from the raw events.

Use built-in strategies for quick setup

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.BuiltInMemoryStrategy(strategyType: MemoryStrategyType, props: MemoryStrategyCommonProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.Initializer.parameter.strategyType">strategyType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType</code> | The type of memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps</code> | *No description.* |

---

##### `strategyType`<sup>Required</sup> <a name="strategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.Initializer.parameter.strategyType"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType

The type of memory strategy.

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.grant">grant</a></code> | Grants the necessary permissions to the role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.render">render</a></code> | Renders the network configuration as a CloudFormation property. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.grant"></a>

```typescript
public grant(_role: IRole): Grant
```

Grants the necessary permissions to the role.

###### `_role`<sup>Required</sup> <a name="_role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.grant.parameter._role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

The role to grant permissions to.

---

##### `render` <a name="render" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.render"></a>

```typescript
public render(): MemoryStrategyProperty
```

Renders the network configuration as a CloudFormation property.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.name">name</a></code> | <code>string</code> | The name of the memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.namespaces">namespaces</a></code> | <code>string[]</code> | The namespaces of the memory strategy to store extracted memories. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.strategyClassType">strategyClassType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType</code> | The class of memory strategy (built-in or custom). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.strategyType">strategyType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType</code> | The type of memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.description">description</a></code> | <code>string</code> | The description of the memory strategy. |

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the memory strategy.

---

##### `namespaces`<sup>Required</sup> <a name="namespaces" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.namespaces"></a>

```typescript
public readonly namespaces: string[];
```

- *Type:* string[]

The namespaces of the memory strategy to store extracted memories.

---

##### `strategyClassType`<sup>Required</sup> <a name="strategyClassType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.strategyClassType"></a>

```typescript
public readonly strategyClassType: MemoryStrategyClassType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType

The class of memory strategy (built-in or custom).

---

##### `strategyType`<sup>Required</sup> <a name="strategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.strategyType"></a>

```typescript
public readonly strategyType: MemoryStrategyType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType

The type of memory strategy.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the memory strategy.

---


### CodeInterpreterNetworkConfiguration <a name="CodeInterpreterNetworkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration"></a>

Network configuration for the Code Interpreter tool.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.CodeInterpreterNetworkConfiguration(mode: string, scope?: Construct, vpcConfig?: VpcConfigProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.mode">mode</a></code> | <code>string</code> | - the network mode to use for the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.vpcConfig">vpcConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps</code> | *No description.* |

---

##### `mode`<sup>Required</sup> <a name="mode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.mode"></a>

- *Type:* string

the network mode to use for the tool.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `vpcConfig`<sup>Optional</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.Initializer.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork">usingPublicNetwork</a></code> | Creates a public network configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingSandboxNetwork">usingSandboxNetwork</a></code> | Creates a sandbox network configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingVpc">usingVpc</a></code> | Creates a network configuration from a VPC configuration. |

---

##### `usingPublicNetwork` <a name="usingPublicNetwork" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingPublicNetwork()
```

Creates a public network configuration.

##### `usingSandboxNetwork` <a name="usingSandboxNetwork" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingSandboxNetwork"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingSandboxNetwork()
```

Creates a sandbox network configuration.

##### `usingVpc` <a name="usingVpc" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingVpc"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingVpc(scope: Construct, vpcConfig: VpcConfigProps)
```

Creates a network configuration from a VPC configuration.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingVpc.parameter.scope"></a>

- *Type:* constructs.Construct

---

###### `vpcConfig`<sup>Required</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.usingVpc.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

The VPC configuration.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.networkMode">networkMode</a></code> | <code>string</code> | The network mode to use. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The connections object to the network. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.scope">scope</a></code> | <code>constructs.Construct</code> | The scope to create the resource in. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.vpcSubnets">vpcSubnets</a></code> | <code>aws-cdk-lib.aws_ec2.SubnetSelection</code> | The VPC subnets to use. |

---

##### `networkMode`<sup>Required</sup> <a name="networkMode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.networkMode"></a>

```typescript
public readonly networkMode: string;
```

- *Type:* string

The network mode to use.

Configure the security level for agent
execution to control access, isolate resources, and protect sensitive data.

---

##### `connections`<sup>Optional</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The connections object to the network.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.scope"></a>

```typescript
public readonly scope: Construct;
```

- *Type:* constructs.Construct

The scope to create the resource in.

---

##### `vpcSubnets`<sup>Optional</sup> <a name="vpcSubnets" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterNetworkConfiguration.property.vpcSubnets"></a>

```typescript
public readonly vpcSubnets: SubnetSelection;
```

- *Type:* aws-cdk-lib.aws_ec2.SubnetSelection

The VPC subnets to use.

---


### CustomJwtAuthorizer <a name="CustomJwtAuthorizer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

Custom JWT authorizer configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.CustomJwtAuthorizer(config: CustomJwtConfiguration)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.Initializer.parameter.config">config</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration</code> | *No description.* |

---

##### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.Initializer.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.fromCognito">fromCognito</a></code> | Create a JWT authorizer from Cognito User Pool. |

---

##### `fromCognito` <a name="fromCognito" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.fromCognito"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.CustomJwtAuthorizer.fromCognito(props: CognitoAuthorizerProps)
```

Create a JWT authorizer from Cognito User Pool.

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.fromCognito.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps

The Cognito configuration.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.property.authorizerType">authorizerType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType</code> | The authorizer type. |

---

##### `authorizerType`<sup>Required</sup> <a name="authorizerType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer.property.authorizerType"></a>

```typescript
public readonly authorizerType: GatewayAuthorizerType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType

The authorizer type.

---


### GatewayAuthorizer <a name="GatewayAuthorizer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer"></a>

Factory class for creating Gateway Authorizers.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayAuthorizer()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCognito">usingCognito</a></code> | Static method for creating a Cognito authorizer. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCustomJwt">usingCustomJwt</a></code> | Create a custom JWT authorizer. |

---

##### `usingCognito` <a name="usingCognito" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCognito"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayAuthorizer.usingCognito(props: CognitoAuthorizerProps)
```

Static method for creating a Cognito authorizer.

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCognito.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CognitoAuthorizerProps

---

##### `usingCustomJwt` <a name="usingCustomJwt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCustomJwt"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayAuthorizer.usingCustomJwt(configuration: CustomJwtConfiguration)
```

Create a custom JWT authorizer.

###### `configuration`<sup>Required</sup> <a name="configuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.usingCustomJwt.parameter.configuration"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtConfiguration

The JWT configuration.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.property.awsIam">awsIam</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer</code> | AWS IAM authorizer instance. |

---

##### `awsIam`<sup>Required</sup> <a name="awsIam" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizer.property.awsIam"></a>

```typescript
public readonly awsIam: IamAuthorizer;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer

AWS IAM authorizer instance.

---


### GatewayCredentialProvider <a name="GatewayCredentialProvider" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider"></a>

Factory class for creating different Gateway Credential Providers.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayCredentialProvider()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.apiKey">apiKey</a></code> | Create an API key credential provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.iamRole">iamRole</a></code> | Create an IAM role credential provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.oauth">oauth</a></code> | Create an OAuth credential provider. |

---

##### `apiKey` <a name="apiKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.apiKey"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayCredentialProvider.apiKey(props: ApiKeyCredentialProviderProps)
```

Create an API key credential provider.

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.apiKey.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderProps

Configuration for the API key provider.

---

##### `iamRole` <a name="iamRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.iamRole"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayCredentialProvider.iamRole()
```

Create an IAM role credential provider.

##### `oauth` <a name="oauth" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.oauth"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayCredentialProvider.oauth(props: OAuthConfiguration)
```

Create an OAuth credential provider.

###### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayCredentialProvider.oauth.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration

Configuration for the OAuth provider.

---



### GatewayIamRoleCredentialProvider <a name="GatewayIamRoleCredentialProvider" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider

Gateway IAM Role credential provider configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayIamRoleCredentialProvider()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.grantNeededPermissionsToRole">grantNeededPermissionsToRole</a></code> | Grant needed permissions to the provided role. |

---

##### `grantNeededPermissionsToRole` <a name="grantNeededPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.grantNeededPermissionsToRole"></a>

```typescript
public grantNeededPermissionsToRole(role: IRole): Grant
```

Grant needed permissions to the provided role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.grantNeededPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

The role to grant permissions to.

---


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.property.credentialProviderType">credentialProviderType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType</code> | The credential provider type. |

---

##### `credentialProviderType`<sup>Required</sup> <a name="credentialProviderType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider.property.credentialProviderType"></a>

```typescript
public readonly credentialProviderType: CredentialProviderType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType

The credential provider type.

---


### GatewayProtocol <a name="GatewayProtocol" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProtocol"></a>

Factory class for instantiating Gateway Protocols.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProtocol.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.GatewayProtocol()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProtocol.mcp">mcp</a></code> | Create an MCP protocol configuration. |

---

##### `mcp` <a name="mcp" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProtocol.mcp"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.GatewayProtocol.mcp(props?: McpConfiguration)
```

Create an MCP protocol configuration.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayProtocol.mcp.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration

Optional MCP configuration properties.

---



### IamAuthorizer <a name="IamAuthorizer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

AWS IAM authorizer configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.IamAuthorizer()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---



#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer.property.authorizerType">authorizerType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType</code> | The authorizer type. |

---

##### `authorizerType`<sup>Required</sup> <a name="authorizerType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer.property.authorizerType"></a>

```typescript
public readonly authorizerType: GatewayAuthorizerType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType

The authorizer type.

---


### InlineApiSchema <a name="InlineApiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema"></a>

Class to define an API Schema from an inline string.

The schema can be provided directly as a string in either JSON or YAML format.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.InlineApiSchema(schema: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.Initializer.parameter.schema">schema</a></code> | <code>string</code> | *No description.* |

---

##### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.Initializer.parameter.schema"></a>

- *Type:* string

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(_role: IRole): void
```

Grant permissions to the role.

###### `_role`<sup>Required</sup> <a name="_role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.grantPermissionsToRole.parameter._role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromInline">fromInline</a></code> | Creates an API Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates an API Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromS3File">fromS3File</a></code> | Creates an API Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineApiSchema.fromInline(schema: string)
```

Creates an API Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromInline.parameter.schema"></a>

- *Type:* string

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineApiSchema.fromLocalAsset(path: string)
```

Creates an API Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the OpenAPI schema for the action group.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineApiSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates an API Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.inlineSchema">inlineSchema</a></code> | <code>string</code> | The inline OpenAPI schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the API schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: string;
```

- *Type:* string

The inline OpenAPI schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineApiSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the API schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### InlineToolSchema <a name="InlineToolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema"></a>

Class to define a Tool Schema from an inline string.

The schema can be provided directly as a string in either JSON or YAML format.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.InlineToolSchema(schema: ToolDefinition[])
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.Initializer.parameter.schema">schema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | *No description.* |

---

##### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.Initializer.parameter.schema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(_role: IRole): void
```

Grant permissions to the role.

###### `_role`<sup>Required</sup> <a name="_role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.grantPermissionsToRole.parameter._role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromInline">fromInline</a></code> | Creates a Tool Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates a tool Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromS3File">fromS3File</a></code> | Creates a Tool Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineToolSchema.fromInline(schema: ToolDefinition[])
```

Creates a Tool Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromInline.parameter.schema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineToolSchema.fromLocalAsset(path: string)
```

Creates a tool Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the function schema for the tool.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.InlineToolSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates a Tool Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.inlineSchema">inlineSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | The inline tool schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the tool schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: ToolDefinition[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

The inline tool schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.InlineToolSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the tool schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### LambdaTargetConfiguration <a name="LambdaTargetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration"></a>

Configuration for Lambda-based MCP targets.

This configuration wraps a Lambda function as MCP tools,
allowing the gateway to invoke the function to provide tool capabilities.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.LambdaTargetConfiguration(lambdaFunction: IFunction, toolSchema: ToolSchema)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.Initializer.parameter.lambdaFunction">lambdaFunction</a></code> | <code>aws-cdk-lib.aws_lambda.IFunction</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.Initializer.parameter.toolSchema">toolSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema</code> | *No description.* |

---

##### `lambdaFunction`<sup>Required</sup> <a name="lambdaFunction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.Initializer.parameter.lambdaFunction"></a>

- *Type:* aws-cdk-lib.aws_lambda.IFunction

---

##### `toolSchema`<sup>Required</sup> <a name="toolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.Initializer.parameter.toolSchema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.bind">bind</a></code> | Binds this configuration to a construct scope Sets up necessary permissions for the gateway to invoke the Lambda function. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.bind"></a>

```typescript
public bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig
```

Binds this configuration to a construct scope Sets up necessary permissions for the gateway to invoke the Lambda function.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.bind.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.bind.parameter.gateway"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that will use this target.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.create">create</a></code> | Create a Lambda target configuration. |

---

##### `create` <a name="create" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.create"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.LambdaTargetConfiguration.create(lambdaFunction: IFunction, toolSchema: ToolSchema)
```

Create a Lambda target configuration.

###### `lambdaFunction`<sup>Required</sup> <a name="lambdaFunction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.create.parameter.lambdaFunction"></a>

- *Type:* aws-cdk-lib.aws_lambda.IFunction

The Lambda function to invoke.

---

###### `toolSchema`<sup>Required</sup> <a name="toolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.create.parameter.toolSchema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema

The schema defining the tools.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The target type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.lambdaFunction">lambdaFunction</a></code> | <code>aws-cdk-lib.aws_lambda.IFunction</code> | The Lambda function that implements the MCP server logic. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.toolSchema">toolSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema</code> | The tool schema that defines the available tools. |

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The target type.

---

##### `lambdaFunction`<sup>Required</sup> <a name="lambdaFunction" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.lambdaFunction"></a>

```typescript
public readonly lambdaFunction: IFunction;
```

- *Type:* aws-cdk-lib.aws_lambda.IFunction

The Lambda function that implements the MCP server logic.

---

##### `toolSchema`<sup>Required</sup> <a name="toolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration.property.toolSchema"></a>

```typescript
public readonly toolSchema: ToolSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema

The tool schema that defines the available tools.

---


### McpProtocolConfiguration <a name="McpProtocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol

MCP (Model Context Protocol) configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.McpProtocolConfiguration(props?: McpConfiguration)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration</code> | *No description.* |

---

##### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpConfiguration

---



#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.protocolType">protocolType</a></code> | <code>string</code> | The protocol type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.instructions">instructions</a></code> | <code>string</code> | Instructions for using the MCP gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.searchType">searchType</a></code> | <code>string</code> | The search type for the MCP gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.supportedVersions">supportedVersions</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion[]</code> | The supported MCP protocol versions. |

---

##### `protocolType`<sup>Required</sup> <a name="protocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.protocolType"></a>

```typescript
public readonly protocolType: string;
```

- *Type:* string

The protocol type.

---

##### `instructions`<sup>Optional</sup> <a name="instructions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.instructions"></a>

```typescript
public readonly instructions: string;
```

- *Type:* string

Instructions for using the MCP gateway.

---

##### `searchType`<sup>Optional</sup> <a name="searchType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.searchType"></a>

```typescript
public readonly searchType: string;
```

- *Type:* string

The search type for the MCP gateway.

---

##### `supportedVersions`<sup>Optional</sup> <a name="supportedVersions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration.property.supportedVersions"></a>

```typescript
public readonly supportedVersions: MCPProtocolVersion[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion[]

The supported MCP protocol versions.

---


### McpTargetConfiguration <a name="McpTargetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration

Abstract base class for MCP target configurations Provides common functionality for all MCP target types.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.McpTargetConfiguration()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.bind">bind</a></code> | Binds the configuration to a construct scope Sets up permissions and dependencies. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.bind"></a>

```typescript
public bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig
```

Binds the configuration to a construct scope Sets up permissions and dependencies.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

###### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.bind.parameter.gateway"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

---


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The target type. |

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The target type.

---


### MemoryStrategy <a name="MemoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy"></a>

Factory class for creating memory strategies If you need long-term memory for context recall across sessions, you can setup memory extraction strategies to extract the relevant memory from the raw events.

Use built-in strategies for quick setup, use built-in strategies with override to specify models and prompt templates.

> [https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory-strategies.html](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory-strategies.html)

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.MemoryStrategy()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInSemantic">usingBuiltInSemantic</a></code> | Default strategies for organizing and extracting memory data, each optimized for specific use cases. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInSummarization">usingBuiltInSummarization</a></code> | Default strategies for organizing and extracting memory data, each optimized for specific use cases. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInUserPreference">usingBuiltInUserPreference</a></code> | Default strategies for organizing and extracting memory data, each optimized for specific use cases. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemantic">usingSemantic</a></code> | Creates a semantic memory strategy with custom configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemanticOverride">usingSemanticOverride</a></code> | Creates a custom semantic memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarization">usingSummarization</a></code> | Creates a summarization memory strategy with custom configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarizationOverride">usingSummarizationOverride</a></code> | Creates a custom summarization memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreference">usingUserPreference</a></code> | Creates a user preference memory strategy with custom configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreferenceOverride">usingUserPreferenceOverride</a></code> | Creates a custom user preference memory strategy. |

---

##### `usingBuiltInSemantic` <a name="usingBuiltInSemantic" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInSemantic"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingBuiltInSemantic()
```

Default strategies for organizing and extracting memory data, each optimized for specific use cases.

Distills general facts, concepts, and underlying meanings from raw conversational data, presenting the information in a context-independent format.
Extracted memory example: In-context learning = task-solving via examples, no training needed.

##### `usingBuiltInSummarization` <a name="usingBuiltInSummarization" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInSummarization"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingBuiltInSummarization()
```

Default strategies for organizing and extracting memory data, each optimized for specific use cases.

This strategy compresses conversations into concise overviews, preserving essential context and key insights for quick recall.
Extracted memory example: Users confused by cloud setup during onboarding.

##### `usingBuiltInUserPreference` <a name="usingBuiltInUserPreference" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingBuiltInUserPreference"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingBuiltInUserPreference()
```

Default strategies for organizing and extracting memory data, each optimized for specific use cases.

Captures individual preferences, interaction patterns, and personalized settings to enhance future experiences.
Extracted memory example: User needs clear guidance on cloud storage account connection during onboarding.

##### `usingSemantic` <a name="usingSemantic" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemantic"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingSemantic(config: MemoryStrategyCommonProps)
```

Creates a semantic memory strategy with custom configuration.

Distills general facts, concepts, and underlying meanings from raw conversational data, presenting the information in a context-independent format.
Extracted memory example: In-context learning = task-solving via examples, no training needed.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemantic.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps

The configuration for the semantic memory strategy.

---

##### `usingSemanticOverride` <a name="usingSemanticOverride" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemanticOverride"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingSemanticOverride(config: OverrideStrategyProps)
```

Creates a custom semantic memory strategy.

Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
You can also choose the model that you want to use for extraction and consolidation.
You can override the prompts for extracting and consolidating semantic memories.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSemanticOverride.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps

The configuration for the semantic memory strategy.

---

##### `usingSummarization` <a name="usingSummarization" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarization"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingSummarization(config: MemoryStrategyCommonProps)
```

Creates a summarization memory strategy with custom configuration.

This strategy compresses conversations into concise overviews, preserving essential context and key insights for quick recall.
Extracted memory example: Users confused by cloud setup during onboarding.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarization.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps

The configuration for the summarization memory strategy.

---

##### `usingSummarizationOverride` <a name="usingSummarizationOverride" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarizationOverride"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingSummarizationOverride(config: OverrideStrategyProps)
```

Creates a custom summarization memory strategy.

Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
You can also choose the model that you want to use for extraction and consolidation.
You can override the prompts for extracting and consolidating summarization memories.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingSummarizationOverride.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps

The configuration for the summarization memory strategy.

---

##### `usingUserPreference` <a name="usingUserPreference" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreference"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingUserPreference(config: MemoryStrategyCommonProps)
```

Creates a user preference memory strategy with custom configuration.

Captures individual preferences, interaction patterns, and personalized settings to enhance future experiences.
Extracted memory example: User needs clear guidance on cloud storage account connection during onboarding.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreference.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyCommonProps

The configuration for the user preference memory strategy.

---

##### `usingUserPreferenceOverride` <a name="usingUserPreferenceOverride" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreferenceOverride"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.MemoryStrategy.usingUserPreferenceOverride(config: OverrideStrategyProps)
```

Creates a custom user preference memory strategy.

Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
You can also choose the model that you want to use for extraction and consolidation.
You can override the prompts for extracting and consolidating user preference memories.

###### `config`<sup>Required</sup> <a name="config" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategy.usingUserPreferenceOverride.parameter.config"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps

The configuration for the user preference memory strategy.

---



### NetworkConfiguration <a name="NetworkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration"></a>

Abstract base class for network configuration.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.NetworkConfiguration(mode: string, scope?: Construct, vpcConfig?: VpcConfigProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.mode">mode</a></code> | <code>string</code> | - the network mode to use for the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.vpcConfig">vpcConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps</code> | *No description.* |

---

##### `mode`<sup>Required</sup> <a name="mode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.mode"></a>

- *Type:* string

the network mode to use for the tool.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `vpcConfig`<sup>Optional</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.Initializer.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

---



#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.networkMode">networkMode</a></code> | <code>string</code> | The network mode to use. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The connections object to the network. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.scope">scope</a></code> | <code>constructs.Construct</code> | The scope to create the resource in. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.vpcSubnets">vpcSubnets</a></code> | <code>aws-cdk-lib.aws_ec2.SubnetSelection</code> | The VPC subnets to use. |

---

##### `networkMode`<sup>Required</sup> <a name="networkMode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.networkMode"></a>

```typescript
public readonly networkMode: string;
```

- *Type:* string

The network mode to use.

Configure the security level for agent
execution to control access, isolate resources, and protect sensitive data.

---

##### `connections`<sup>Optional</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The connections object to the network.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.scope"></a>

```typescript
public readonly scope: Construct;
```

- *Type:* constructs.Construct

The scope to create the resource in.

---

##### `vpcSubnets`<sup>Optional</sup> <a name="vpcSubnets" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.NetworkConfiguration.property.vpcSubnets"></a>

```typescript
public readonly vpcSubnets: SubnetSelection;
```

- *Type:* aws-cdk-lib.aws_ec2.SubnetSelection

The VPC subnets to use.

---


### OAuthCredentialProviderConfiguration <a name="OAuthCredentialProviderConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider

OAuth credential provider configuration implementation.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.OAuthCredentialProviderConfiguration(configuration: OAuthConfiguration)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.Initializer.parameter.configuration">configuration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration</code> | *No description.* |

---

##### `configuration`<sup>Required</sup> <a name="configuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.Initializer.parameter.configuration"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthConfiguration

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.grantNeededPermissionsToRole">grantNeededPermissionsToRole</a></code> | Grant the needed permissions to the role for OAuth authentication. |

---

##### `grantNeededPermissionsToRole` <a name="grantNeededPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.grantNeededPermissionsToRole"></a>

```typescript
public grantNeededPermissionsToRole(role: IRole): Grant
```

Grant the needed permissions to the role for OAuth authentication.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.grantNeededPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.credentialProviderType">credentialProviderType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType</code> | The credential provider type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.providerArn">providerArn</a></code> | <code>string</code> | The ARN of the OAuth provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.scopes">scopes</a></code> | <code>string[]</code> | The OAuth scopes to request. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.secretArn">secretArn</a></code> | <code>string</code> | The ARN of the Secrets Manager secret. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.customParameters">customParameters</a></code> | <code>{[ key: string ]: string}</code> | Custom parameters for the OAuth flow. |

---

##### `credentialProviderType`<sup>Required</sup> <a name="credentialProviderType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.credentialProviderType"></a>

```typescript
public readonly credentialProviderType: CredentialProviderType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType

The credential provider type.

---

##### `providerArn`<sup>Required</sup> <a name="providerArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.providerArn"></a>

```typescript
public readonly providerArn: string;
```

- *Type:* string

The ARN of the OAuth provider.

---

##### `scopes`<sup>Required</sup> <a name="scopes" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.scopes"></a>

```typescript
public readonly scopes: string[];
```

- *Type:* string[]

The OAuth scopes to request.

---

##### `secretArn`<sup>Required</sup> <a name="secretArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.secretArn"></a>

```typescript
public readonly secretArn: string;
```

- *Type:* string

The ARN of the Secrets Manager secret.

---

##### `customParameters`<sup>Optional</sup> <a name="customParameters" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration.property.customParameters"></a>

```typescript
public readonly customParameters: {[ key: string ]: string};
```

- *Type:* {[ key: string ]: string}

Custom parameters for the OAuth flow.

---


### OpenApiTargetConfiguration <a name="OpenApiTargetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration"></a>

Configuration for OpenAPI-based MCP targets.

This configuration exposes an OpenAPI/REST API as MCP tools,
allowing the gateway to transform API operations into tool calls.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.OpenApiTargetConfiguration(apiSchema: ApiSchema)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.Initializer.parameter.apiSchema">apiSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | *No description.* |

---

##### `apiSchema`<sup>Required</sup> <a name="apiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.Initializer.parameter.apiSchema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.bind">bind</a></code> | Binds this configuration to a construct scope Sets up necessary permissions for the gateway to access the API schema. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.bind"></a>

```typescript
public bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig
```

Binds this configuration to a construct scope Sets up necessary permissions for the gateway to access the API schema.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.bind.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.bind.parameter.gateway"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that will use this target.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.create">create</a></code> | Create an OpenAPI target configuration. |

---

##### `create` <a name="create" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.create"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.OpenApiTargetConfiguration.create(apiSchema: ApiSchema)
```

Create an OpenAPI target configuration.

###### `apiSchema`<sup>Required</sup> <a name="apiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.create.parameter.apiSchema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The OpenAPI schema.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The target type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.property.apiSchema">apiSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The OpenAPI schema that defines the API. |

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The target type.

---

##### `apiSchema`<sup>Required</sup> <a name="apiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration.property.apiSchema"></a>

```typescript
public readonly apiSchema: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The OpenAPI schema that defines the API.

---


### OverrideMemoryStrategy <a name="OverrideMemoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy"></a>

- *Implements:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy

If you need long-term memory for context recall across sessions, you can setup memory extraction strategies to extract the relevant memory from the raw events.

use built-in strategies with override to specify models and prompt templates.
Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
You can override the prompts for extracting and consolidating semantic, summary, or user preferences.
You can also choose the model that you want to use for extraction and consolidation.
The custom prompts you create are appended to a non-editable system prompt.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.OverrideMemoryStrategy(strategyType: MemoryStrategyType, props: OverrideStrategyProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.Initializer.parameter.strategyType">strategyType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType</code> | the strategy type to override. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.Initializer.parameter.props">props</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps</code> | the properties for the override. |

---

##### `strategyType`<sup>Required</sup> <a name="strategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.Initializer.parameter.strategyType"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType

the strategy type to override.

---

##### `props`<sup>Required</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.Initializer.parameter.props"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideStrategyProps

the properties for the override.

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.grant">grant</a></code> | Grants the necessary permissions to the role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.render">render</a></code> | Renders the network configuration as a CloudFormation property. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.grant"></a>

```typescript
public grant(role: IRole): Grant
```

Grants the necessary permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.grant.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

The role to grant permissions to.

---

##### `render` <a name="render" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.render"></a>

```typescript
public render(): MemoryStrategyProperty
```

Renders the network configuration as a CloudFormation property.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.name">name</a></code> | <code>string</code> | The name of the memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.namespaces">namespaces</a></code> | <code>string[]</code> | The namespaces of the memory strategy to store extracted memories. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.strategyClassType">strategyClassType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType</code> | The class of memory strategy (built-in or custom). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.strategyType">strategyType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType</code> | The type of memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.consolidationOverride">consolidationOverride</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.description">description</a></code> | <code>string</code> | The description of the memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.extractionOverride">extractionOverride</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig</code> | *No description.* |

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the memory strategy.

---

##### `namespaces`<sup>Required</sup> <a name="namespaces" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.namespaces"></a>

```typescript
public readonly namespaces: string[];
```

- *Type:* string[]

The namespaces of the memory strategy to store extracted memories.

---

##### `strategyClassType`<sup>Required</sup> <a name="strategyClassType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.strategyClassType"></a>

```typescript
public readonly strategyClassType: MemoryStrategyClassType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType

The class of memory strategy (built-in or custom).

---

##### `strategyType`<sup>Required</sup> <a name="strategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.strategyType"></a>

```typescript
public readonly strategyType: MemoryStrategyType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType

The type of memory strategy.

---

##### `consolidationOverride`<sup>Optional</sup> <a name="consolidationOverride" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.consolidationOverride"></a>

```typescript
public readonly consolidationOverride: OverrideConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the memory strategy.

---

##### `extractionOverride`<sup>Optional</sup> <a name="extractionOverride" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy.property.extractionOverride"></a>

```typescript
public readonly extractionOverride: OverrideConfig;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideConfig

---


### RuntimeAuthorizerConfiguration <a name="RuntimeAuthorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration"></a>

Abstract base class for runtime authorizer configurations.

Provides static factory methods to create different authentication types.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.RuntimeAuthorizerConfiguration()
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito">usingCognito</a></code> | Use AWS Cognito User Pool authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingIAM">usingIAM</a></code> | Use IAM authentication (default). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT">usingJWT</a></code> | Use custom JWT authentication. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth">usingOAuth</a></code> | Use OAuth 2.0 authentication. Supports various OAuth providers. |

---

##### `usingCognito` <a name="usingCognito" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito(userPoolId: string, clientId: string, region?: string, allowedAudience?: string[])
```

Use AWS Cognito User Pool authentication.

Validates Cognito-issued JWT tokens.

###### `userPoolId`<sup>Required</sup> <a name="userPoolId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito.parameter.userPoolId"></a>

- *Type:* string

The Cognito User Pool ID (e.g., 'us-west-2_ABC123').

---

###### `clientId`<sup>Required</sup> <a name="clientId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito.parameter.clientId"></a>

- *Type:* string

The Cognito App Client ID.

---

###### `region`<sup>Optional</sup> <a name="region" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito.parameter.region"></a>

- *Type:* string

Optional AWS region where the User Pool is located (defaults to stack region).

---

###### `allowedAudience`<sup>Optional</sup> <a name="allowedAudience" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingCognito.parameter.allowedAudience"></a>

- *Type:* string[]

Optional array of allowed audiences.

---

##### `usingIAM` <a name="usingIAM" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingIAM"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeAuthorizerConfiguration.usingIAM()
```

Use IAM authentication (default).

Requires AWS credentials to sign requests using SigV4.

##### `usingJWT` <a name="usingJWT" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT(discoveryUrl: string, allowedClients?: string[], allowedAudience?: string[])
```

Use custom JWT authentication.

Validates JWT tokens against the specified OIDC provider.

###### `discoveryUrl`<sup>Required</sup> <a name="discoveryUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT.parameter.discoveryUrl"></a>

- *Type:* string

The OIDC discovery URL (must end with /.well-known/openid-configuration).

---

###### `allowedClients`<sup>Optional</sup> <a name="allowedClients" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT.parameter.allowedClients"></a>

- *Type:* string[]

Optional array of allowed client IDs.

---

###### `allowedAudience`<sup>Optional</sup> <a name="allowedAudience" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingJWT.parameter.allowedAudience"></a>

- *Type:* string[]

Optional array of allowed audiences.

---

##### `usingOAuth` <a name="usingOAuth" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth(discoveryUrl: string, clientId: string, allowedAudience?: string[])
```

Use OAuth 2.0 authentication. Supports various OAuth providers.

###### `discoveryUrl`<sup>Required</sup> <a name="discoveryUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth.parameter.discoveryUrl"></a>

- *Type:* string

The OIDC discovery URL (must end with /.well-known/openid-configuration).

---

###### `clientId`<sup>Required</sup> <a name="clientId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth.parameter.clientId"></a>

- *Type:* string

OAuth client ID.

---

###### `allowedAudience`<sup>Optional</sup> <a name="allowedAudience" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeAuthorizerConfiguration.usingOAuth.parameter.allowedAudience"></a>

- *Type:* string[]

Optional array of allowed audiences.

---



### RuntimeNetworkConfiguration <a name="RuntimeNetworkConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration"></a>

Network configuration for the Runtime.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.RuntimeNetworkConfiguration(mode: string, scope?: Construct, vpcConfig?: VpcConfigProps)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.mode">mode</a></code> | <code>string</code> | - the network mode to use for the tool. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.scope">scope</a></code> | <code>constructs.Construct</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.vpcConfig">vpcConfig</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps</code> | *No description.* |

---

##### `mode`<sup>Required</sup> <a name="mode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.mode"></a>

- *Type:* string

the network mode to use for the tool.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `vpcConfig`<sup>Optional</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.Initializer.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

---


#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingPublicNetwork">usingPublicNetwork</a></code> | Creates a public network configuration. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingVpc">usingVpc</a></code> | Creates a network configuration from a VPC configuration. |

---

##### `usingPublicNetwork` <a name="usingPublicNetwork" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingPublicNetwork"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeNetworkConfiguration.usingPublicNetwork()
```

Creates a public network configuration.

PUBLIC is the default network mode.

##### `usingVpc` <a name="usingVpc" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingVpc"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.RuntimeNetworkConfiguration.usingVpc(scope: Construct, vpcConfig: VpcConfigProps)
```

Creates a network configuration from a VPC configuration.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingVpc.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope for creating resources.

---

###### `vpcConfig`<sup>Required</sup> <a name="vpcConfig" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.usingVpc.parameter.vpcConfig"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.VpcConfigProps

The VPC configuration.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.networkMode">networkMode</a></code> | <code>string</code> | The network mode to use. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The connections object to the network. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.scope">scope</a></code> | <code>constructs.Construct</code> | The scope to create the resource in. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.vpcSubnets">vpcSubnets</a></code> | <code>aws-cdk-lib.aws_ec2.SubnetSelection</code> | The VPC subnets to use. |

---

##### `networkMode`<sup>Required</sup> <a name="networkMode" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.networkMode"></a>

```typescript
public readonly networkMode: string;
```

- *Type:* string

The network mode to use.

Configure the security level for agent
execution to control access, isolate resources, and protect sensitive data.

---

##### `connections`<sup>Optional</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The connections object to the network.

---

##### `scope`<sup>Optional</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.scope"></a>

```typescript
public readonly scope: Construct;
```

- *Type:* constructs.Construct

The scope to create the resource in.

---

##### `vpcSubnets`<sup>Optional</sup> <a name="vpcSubnets" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeNetworkConfiguration.property.vpcSubnets"></a>

```typescript
public readonly vpcSubnets: SubnetSelection;
```

- *Type:* aws-cdk-lib.aws_ec2.SubnetSelection

The VPC subnets to use.

---


### S3ApiSchema <a name="S3ApiSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema"></a>

Class to define an API Schema from an S3 object.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.S3ApiSchema(location: Location, bucketOwnerAccountId?: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.Initializer.parameter.location">location</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.Initializer.parameter.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |

---

##### `location`<sup>Required</sup> <a name="location" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.Initializer.parameter.location"></a>

- *Type:* aws-cdk-lib.aws_s3.Location

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.Initializer.parameter.bucketOwnerAccountId"></a>

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromInline">fromInline</a></code> | Creates an API Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates an API Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromS3File">fromS3File</a></code> | Creates an API Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ApiSchema.fromInline(schema: string)
```

Creates an API Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromInline.parameter.schema"></a>

- *Type:* string

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ApiSchema.fromLocalAsset(path: string)
```

Creates an API Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the OpenAPI schema for the action group.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ApiSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates an API Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.inlineSchema">inlineSchema</a></code> | <code>string</code> | The inline OpenAPI schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the API schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: string;
```

- *Type:* string

The inline OpenAPI schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ApiSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the API schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### S3ToolSchema <a name="S3ToolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema"></a>

Class to define a Tool Schema from an S3 object.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.S3ToolSchema(location: Location, bucketOwnerAccountId?: string)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.Initializer.parameter.location">location</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.Initializer.parameter.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |

---

##### `location`<sup>Required</sup> <a name="location" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.Initializer.parameter.location"></a>

- *Type:* aws-cdk-lib.aws_s3.Location

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.Initializer.parameter.bucketOwnerAccountId"></a>

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromInline">fromInline</a></code> | Creates a Tool Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates a tool Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromS3File">fromS3File</a></code> | Creates a Tool Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ToolSchema.fromInline(schema: ToolDefinition[])
```

Creates a Tool Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromInline.parameter.schema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ToolSchema.fromLocalAsset(path: string)
```

Creates a tool Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the function schema for the tool.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.S3ToolSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates a Tool Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.inlineSchema">inlineSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | The inline tool schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the tool schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: ToolDefinition[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

The inline tool schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.S3ToolSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the tool schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


### SmithyTargetConfiguration <a name="SmithyTargetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration"></a>

Configuration for Smithy-based MCP targets.

This configuration exposes a Smithy-modeled API as MCP tools,
allowing the gateway to transform Smithy operations into tool calls.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.SmithyTargetConfiguration(smithyModel: ApiSchema)
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.Initializer.parameter.smithyModel">smithyModel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | *No description.* |

---

##### `smithyModel`<sup>Required</sup> <a name="smithyModel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.Initializer.parameter.smithyModel"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.bind">bind</a></code> | Binds this configuration to a construct scope Sets up necessary permissions for the gateway to access the Smithy model. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.bind"></a>

```typescript
public bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig
```

Binds this configuration to a construct scope Sets up necessary permissions for the gateway to access the Smithy model.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.bind.parameter.scope"></a>

- *Type:* constructs.Construct

The construct scope.

---

###### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.bind.parameter.gateway"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that will use this target.

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.create">create</a></code> | Create a Smithy target configuration. |

---

##### `create` <a name="create" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.create"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.SmithyTargetConfiguration.create(smithyModel: ApiSchema)
```

Create a Smithy target configuration.

###### `smithyModel`<sup>Required</sup> <a name="smithyModel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.create.parameter.smithyModel"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The Smithy model schema.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The target type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.property.smithyModel">smithyModel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema</code> | The Smithy model that defines the API. |

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The target type.

---

##### `smithyModel`<sup>Required</sup> <a name="smithyModel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration.property.smithyModel"></a>

```typescript
public readonly smithyModel: ApiSchema;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiSchema

The Smithy model that defines the API.

---


### ToolSchema <a name="ToolSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema"></a>

****************************************************************************                      TOOL SCHEMA CLASS ***************************************************************************.

#### Initializers <a name="Initializers" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

new bedrock_agentcore.ToolSchema(s3File?: Location, bucketOwnerAccountId?: string, inlineSchema?: ToolDefinition[])
```

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | *No description.* |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.inlineSchema">inlineSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | *No description.* |

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.s3File"></a>

- *Type:* aws-cdk-lib.aws_s3.Location

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.bucketOwnerAccountId"></a>

- *Type:* string

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.Initializer.parameter.inlineSchema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

---

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.bind">bind</a></code> | Bind the schema to a construct. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.grantPermissionsToRole">grantPermissionsToRole</a></code> | Grant permissions to the role. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.bind"></a>

```typescript
public bind(scope: Construct): void
```

Bind the schema to a construct.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

##### `grantPermissionsToRole` <a name="grantPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.grantPermissionsToRole"></a>

```typescript
public grantPermissionsToRole(role: IRole): void
```

Grant permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.grantPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Static Functions <a name="Static Functions" id="Static Functions"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromInline">fromInline</a></code> | Creates a Tool Schema from an inline string. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromLocalAsset">fromLocalAsset</a></code> | Creates a tool Schema from a local file. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromS3File">fromS3File</a></code> | Creates a Tool Schema from an S3 File. |

---

##### `fromInline` <a name="fromInline" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromInline"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ToolSchema.fromInline(schema: ToolDefinition[])
```

Creates a Tool Schema from an inline string.

###### `schema`<sup>Required</sup> <a name="schema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromInline.parameter.schema"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

the JSON or YAML payload defining the OpenAPI schema for the action group.

---

##### `fromLocalAsset` <a name="fromLocalAsset" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromLocalAsset"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ToolSchema.fromLocalAsset(path: string)
```

Creates a tool Schema from a local file.

###### `path`<sup>Required</sup> <a name="path" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromLocalAsset.parameter.path"></a>

- *Type:* string

the path to the local file containing the function schema for the tool.

---

##### `fromS3File` <a name="fromS3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromS3File"></a>

```typescript
import { bedrock_agentcore } from '@krokoko/agentcore-cdk-constructs'

bedrock_agentcore.ToolSchema.fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string)
```

Creates a Tool Schema from an S3 File.

###### `bucket`<sup>Required</sup> <a name="bucket" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromS3File.parameter.bucket"></a>

- *Type:* aws-cdk-lib.aws_s3.IBucket

the bucket containing the local file containing the OpenAPI schema for the action group.

---

###### `objectKey`<sup>Required</sup> <a name="objectKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromS3File.parameter.objectKey"></a>

- *Type:* string

object key in the bucket.

---

###### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.fromS3File.parameter.bucketOwnerAccountId"></a>

- *Type:* string

optional The account ID of the Amazon S3 bucket owner.

This ID is used for cross-account access to the bucket.

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.bucketOwnerAccountId">bucketOwnerAccountId</a></code> | <code>string</code> | The account ID of the S3 bucket owner for cross-account access. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.inlineSchema">inlineSchema</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]</code> | The inline tool schema definition as a string, if using an inline schema. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.s3File">s3File</a></code> | <code>aws-cdk-lib.aws_s3.Location</code> | The S3 location of the tool schema file, if using an S3-based schema. |

---

##### `bucketOwnerAccountId`<sup>Optional</sup> <a name="bucketOwnerAccountId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.bucketOwnerAccountId"></a>

```typescript
public readonly bucketOwnerAccountId: string;
```

- *Type:* string

The account ID of the S3 bucket owner for cross-account access.

---

##### `inlineSchema`<sup>Optional</sup> <a name="inlineSchema" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.inlineSchema"></a>

```typescript
public readonly inlineSchema: ToolDefinition[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolDefinition[]

The inline tool schema definition as a string, if using an inline schema.

Can be in JSON or YAML format.

---

##### `s3File`<sup>Optional</sup> <a name="s3File" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ToolSchema.property.s3File"></a>

```typescript
public readonly s3File: Location;
```

- *Type:* aws-cdk-lib.aws_s3.Location

The S3 location of the tool schema file, if using an S3-based schema.

Contains the bucket name and object key information.

---


## Protocols <a name="Protocols" id="Protocols"></a>

### IBedrockAgentRuntime <a name="IBedrockAgentRuntime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime"></a>

- *Extends:* aws-cdk-lib.IResource, aws-cdk-lib.aws_iam.IGrantable, aws-cdk-lib.aws_ec2.IConnectable

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.Runtime, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime

Interface for Agent Runtime resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.addToRolePolicy">addToRolePolicy</a></code> | Adds a policy statement to the runtime's execution role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grant">grant</a></code> | Grant the runtime specific actions on AWS resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvoke">grantInvoke</a></code> | Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntime">grantInvokeRuntime</a></code> | Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntimeForUser">grantInvokeRuntimeForUser</a></code> | Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metric">metric</a></code> | Return the given named metric for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocationsAggregated">metricInvocationsAggregated</a></code> | Return a metric containing the total number of invocations across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionCount">metricSessionCount</a></code> | Return a metric containing the number of agent sessions for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionsAggregated">metricSessionsAggregated</a></code> | Return a metric containing the total number of sessions across all resources. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricTotalErrors">metricTotalErrors</a></code> | Return a metric containing the total number of errors (system + user) for this agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors for this agent runtime. |

---

##### `addToRolePolicy` <a name="addToRolePolicy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.addToRolePolicy"></a>

```typescript
public addToRolePolicy(statement: PolicyStatement): IBedrockAgentRuntime
```

Adds a policy statement to the runtime's execution role.

###### `statement`<sup>Required</sup> <a name="statement" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.addToRolePolicy.parameter.statement"></a>

- *Type:* aws-cdk-lib.aws_iam.PolicyStatement

The IAM policy statement to add.

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grant"></a>

```typescript
public grant(actions: string[], resources: string[]): Grant
```

Grant the runtime specific actions on AWS resources.

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grant.parameter.actions"></a>

- *Type:* string[]

The actions to grant.

---

###### `resources`<sup>Required</sup> <a name="resources" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grant.parameter.resources"></a>

- *Type:* string[]

The resource ARNs to grant access to.

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime both directly and on behalf of users Grants both bedrock-agentcore:InvokeAgentRuntime and bedrock-agentcore:InvokeAgentRuntimeForUser permissions.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntime` <a name="grantInvokeRuntime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntime"></a>

```typescript
public grantInvokeRuntime(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime Grants the bedrock-agentcore:InvokeAgentRuntime permission.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntime.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `grantInvokeRuntimeForUser` <a name="grantInvokeRuntimeForUser" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntimeForUser"></a>

```typescript
public grantInvokeRuntimeForUser(grantee: IGrantable): Grant
```

Permits an IAM principal to invoke this runtime on behalf of a user Grants the bedrock-agentcore:InvokeAgentRuntimeForUser permission Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.grantInvokeRuntimeForUser.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

The principal to grant access to.

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this agent runtime.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsAggregated` <a name="metricInvocationsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocationsAggregated"></a>

```typescript
public metricInvocationsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricInvocationsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionCount` <a name="metricSessionCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionCount"></a>

```typescript
public metricSessionCount(props?: MetricOptions): Metric
```

Return a metric containing the number of agent sessions for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionsAggregated` <a name="metricSessionsAggregated" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionsAggregated"></a>

```typescript
public metricSessionsAggregated(props?: MetricOptions): Metric
```

Return a metric containing the total number of sessions across all resources.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSessionsAggregated.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTotalErrors` <a name="metricTotalErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricTotalErrors"></a>

```typescript
public metricTotalErrors(props?: MetricOptions): Metric
```

Return a metric containing the total number of errors (system + user) for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricTotalErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors for this agent runtime.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The network connections associated with this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the agent runtime resource - Format `arn:${Partition}:bedrock-agentcore:${Region}:${Account}:runtime/${RuntimeId}`. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeId">agentRuntimeId</a></code> | <code>string</code> | The ID of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeName">agentRuntimeName</a></code> | <code>string</code> | The name of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeVersion">agentRuntimeVersion</a></code> | <code>string</code> | The version of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentStatus">agentStatus</a></code> | <code>string</code> | The current status of the agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.createdAt">createdAt</a></code> | <code>string</code> | The time at which the runtime was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | The time at which the runtime was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The network connections associated with this resource.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the agent runtime resource - Format `arn:${Partition}:bedrock-agentcore:${Region}:${Account}:runtime/${RuntimeId}`.

---

*Example*

```typescript
"arn:aws:bedrock-agentcore:us-west-2:123456789012:runtime/runtime-abc123"
```


##### `agentRuntimeId`<sup>Required</sup> <a name="agentRuntimeId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeId"></a>

```typescript
public readonly agentRuntimeId: string;
```

- *Type:* string

The ID of the agent runtime.

---

*Example*

```typescript
"runtime-abc123"
```


##### `agentRuntimeName`<sup>Required</sup> <a name="agentRuntimeName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeName"></a>

```typescript
public readonly agentRuntimeName: string;
```

- *Type:* string

The name of the agent runtime.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the agent runtime.

---

##### `agentRuntimeVersion`<sup>Optional</sup> <a name="agentRuntimeVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentRuntimeVersion"></a>

```typescript
public readonly agentRuntimeVersion: string;
```

- *Type:* string

The version of the agent runtime.

---

##### `agentStatus`<sup>Optional</sup> <a name="agentStatus" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.agentStatus"></a>

```typescript
public readonly agentStatus: string;
```

- *Type:* string

The current status of the agent runtime.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

The time at which the runtime was created.

---

*Example*

```typescript
"2024-01-15T10:30:00Z"
```


##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBedrockAgentRuntime.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

The time at which the runtime was last updated.

---

*Example*

```typescript
"2024-01-15T14:45:00Z"
```


### IBrowserCustom <a name="IBrowserCustom" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom"></a>

- *Extends:* aws-cdk-lib.IResource, aws-cdk-lib.aws_iam.IGrantable, aws-cdk-lib.aws_ec2.IConnectable

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustom, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BrowserCustomBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom

Interface for Browser resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantUse">grantUse</a></code> | Grants `Invoke`, `Start`, and `Update` actions on the Browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metric">metric</a></code> | Return the given named metric for this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Return a metric containing the number of errors for a specific API operation performed on this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricForApiOperation">metricForApiOperation</a></code> | Return the given named metric related to the API operation performed on this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Return a metric containing the total number of API requests made for a specific browser operation. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Return a metric measuring the latency of a specific API operation performed on this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSessionDuration">metricSessionDuration</a></code> | Return a metric measuring the duration of browser sessions. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Return a metric containing the number of system errors for a specific API operation performed on this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverCount">metricTakeOverCount</a></code> | Return a metric containing the number of user takeovers. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverDuration">metricTakeOverDuration</a></code> | Return a metric measuring the duration of user takeovers. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverReleaseCount">metricTakeOverReleaseCount</a></code> | Return a metric containing the number of user takeovers released. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Return a metric containing the number of throttled requests for a specific API operation performed on this browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Return a metric containing the number of user errors for a specific API operation performed on this browser. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Browser.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grants `Invoke`, `Start`, and `Update` actions on the Browser.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this browser.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of errors for a specific API operation performed on this browser.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Return the given named metric related to the API operation performed on this browser.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the total number of API requests made for a specific browser operation.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric measuring the latency of a specific API operation performed on this browser.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of browser sessions.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of system errors for a specific API operation performed on this browser.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTakeOverCount` <a name="metricTakeOverCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverCount"></a>

```typescript
public metricTakeOverCount(props?: MetricOptions): Metric
```

Return a metric containing the number of user takeovers.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTakeOverDuration` <a name="metricTakeOverDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverDuration"></a>

```typescript
public metricTakeOverDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of user takeovers.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTakeOverReleaseCount` <a name="metricTakeOverReleaseCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverReleaseCount"></a>

```typescript
public metricTakeOverReleaseCount(props?: MetricOptions): Metric
```

Return a metric containing the number of user takeovers released.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricTakeOverReleaseCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests for a specific API operation performed on this browser.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of user errors for a specific API operation performed on this browser.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The network connections associated with this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.browserArn">browserArn</a></code> | <code>string</code> | The ARN of the browser resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.browserId">browserId</a></code> | <code>string</code> | The id of the browser. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the browser to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the browser was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | Timestamp when the browser was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.status">status</a></code> | <code>string</code> | The status of the browser. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The network connections associated with this resource.

---

##### `browserArn`<sup>Required</sup> <a name="browserArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.browserArn"></a>

```typescript
public readonly browserArn: string;
```

- *Type:* string

The ARN of the browser resource.

---

##### `browserId`<sup>Required</sup> <a name="browserId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.browserId"></a>

```typescript
public readonly browserId: string;
```

- *Type:* string

The id of the browser.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the browser to access AWS services.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the browser was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

Timestamp when the browser was last updated.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IBrowserCustom.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the browser.

---

### ICodeInterpreterCustom <a name="ICodeInterpreterCustom" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom"></a>

- *Extends:* aws-cdk-lib.IResource, aws-cdk-lib.aws_iam.IGrantable, aws-cdk-lib.aws_ec2.IConnectable

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustom, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CodeInterpreterCustomBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom

Interface for CodeInterpreterCustom resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Code Interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantUse">grantUse</a></code> | Grants `Invoke`, `Start`, and `Stop` actions on the Code Interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metric">metric</a></code> | Return the given named metric for this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Return a metric containing the number of errors for a specific API operation performed on this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricForApiOperation">metricForApiOperation</a></code> | Return the given named metric related to the API operation performed on this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Return a metric containing the total number of API requests made for a specific code interpreter operation. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Return a metric measuring the latency of a specific API operation performed on this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSessionDuration">metricSessionDuration</a></code> | Return a metric measuring the duration of code interpreter sessions. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSystemErrorsForApiOperation">metricSystemErrorsForApiOperation</a></code> | Return a metric containing the number of system errors for a specific API operation performed on this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricThrottlesForApiOperation">metricThrottlesForApiOperation</a></code> | Return a metric containing the number of throttled requests for a specific API operation performed on this code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricUserErrorsForApiOperation">metricUserErrorsForApiOperation</a></code> | Return a metric containing the number of user errors for a specific API operation performed on this code interpreter. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Code Interpreter.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantUse` <a name="grantUse" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantUse"></a>

```typescript
public grantUse(grantee: IGrantable): Grant
```

Grants `Invoke`, `Start`, and `Stop` actions on the Code Interpreter.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.grantUse.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this code interpreter.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of errors for a specific API operation performed on this code interpreter.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Return the given named metric related to the API operation performed on this code interpreter.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the total number of API requests made for a specific code interpreter operation.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric measuring the latency of a specific API operation performed on this code interpreter.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSessionDuration` <a name="metricSessionDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSessionDuration"></a>

```typescript
public metricSessionDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of code interpreter sessions.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSessionDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrorsForApiOperation` <a name="metricSystemErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSystemErrorsForApiOperation"></a>

```typescript
public metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of system errors for a specific API operation performed on this code interpreter.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSystemErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricSystemErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottlesForApiOperation` <a name="metricThrottlesForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricThrottlesForApiOperation"></a>

```typescript
public metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests for a specific API operation performed on this code interpreter.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricThrottlesForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricThrottlesForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrorsForApiOperation` <a name="metricUserErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricUserErrorsForApiOperation"></a>

```typescript
public metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of user errors for a specific API operation performed on this code interpreter.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricUserErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.metricUserErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.connections">connections</a></code> | <code>aws-cdk-lib.aws_ec2.Connections</code> | The network connections associated with this resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.codeInterpreterArn">codeInterpreterArn</a></code> | <code>string</code> | The ARN of the code interpreter resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.codeInterpreterId">codeInterpreterId</a></code> | <code>string</code> | The id of the code interpreter. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the code interpreter to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the code interpreter was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.lastUpdatedAt">lastUpdatedAt</a></code> | <code>string</code> | Timestamp when the code interpreter was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.status">status</a></code> | <code>string</code> | The status of the code interpreter. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `connections`<sup>Required</sup> <a name="connections" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.connections"></a>

```typescript
public readonly connections: Connections;
```

- *Type:* aws-cdk-lib.aws_ec2.Connections

The network connections associated with this resource.

---

##### `codeInterpreterArn`<sup>Required</sup> <a name="codeInterpreterArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.codeInterpreterArn"></a>

```typescript
public readonly codeInterpreterArn: string;
```

- *Type:* string

The ARN of the code interpreter resource.

---

##### `codeInterpreterId`<sup>Required</sup> <a name="codeInterpreterId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.codeInterpreterId"></a>

```typescript
public readonly codeInterpreterId: string;
```

- *Type:* string

The id of the code interpreter.

---

##### `executionRole`<sup>Required</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the code interpreter to access AWS services.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the code interpreter was created.

---

##### `lastUpdatedAt`<sup>Optional</sup> <a name="lastUpdatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.lastUpdatedAt"></a>

```typescript
public readonly lastUpdatedAt: string;
```

- *Type:* string

Timestamp when the code interpreter was last updated.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICodeInterpreterCustom.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the code interpreter.

---

### ICredentialProvider <a name="ICredentialProvider" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider"></a>

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ApiKeyCredentialProviderConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayIamRoleCredentialProvider, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OAuthCredentialProviderConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider

Abstract interface for gateway credential provider configuration.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider.grantNeededPermissionsToRole">grantNeededPermissionsToRole</a></code> | Grant the role the permissions. |

---

##### `grantNeededPermissionsToRole` <a name="grantNeededPermissionsToRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider.grantNeededPermissionsToRole"></a>

```typescript
public grantNeededPermissionsToRole(role: IRole): Grant
```

Grant the role the permissions.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider.grantNeededPermissionsToRole.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider.property.credentialProviderType">credentialProviderType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType</code> | The credential provider type. |

---

##### `credentialProviderType`<sup>Required</sup> <a name="credentialProviderType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider.property.credentialProviderType"></a>

```typescript
public readonly credentialProviderType: CredentialProviderType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType

The credential provider type.

---

### IGateway <a name="IGateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway"></a>

- *Extends:* aws-cdk-lib.IResource

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.Gateway, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

Interface for Gateway resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantInvoke">grantInvoke</a></code> | Grants permission to invoke this Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metric">metric</a></code> | Return the given named metric for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricDuration">metricDuration</a></code> | Return a metric measuring the duration of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricInvocations">metricInvocations</a></code> | Return a metric containing the total number of invocations for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricLatency">metricLatency</a></code> | Return a metric measuring the latency of requests for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricSystemErrors">metricSystemErrors</a></code> | Return a metric containing the number of system errors (5xx status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetExecutionTime">metricTargetExecutionTime</a></code> | Return a metric measuring the target execution time for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetType">metricTargetType</a></code> | Return a metric containing the number of requests served by each target type for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricThrottles">metricThrottles</a></code> | Return a metric containing the number of throttled requests (429 status code) for this gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricUserErrors">metricUserErrors</a></code> | Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantInvoke` <a name="grantInvoke" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantInvoke"></a>

```typescript
public grantInvoke(grantee: IGrantable): Grant
```

Grants permission to invoke this Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantInvoke.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this gateway.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricDuration` <a name="metricDuration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricDuration"></a>

```typescript
public metricDuration(props?: MetricOptions): Metric
```

Return a metric measuring the duration of requests for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricDuration.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocations` <a name="metricInvocations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricInvocations"></a>

```typescript
public metricInvocations(props?: MetricOptions): Metric
```

Return a metric containing the total number of invocations for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricInvocations.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatency` <a name="metricLatency" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricLatency"></a>

```typescript
public metricLatency(props?: MetricOptions): Metric
```

Return a metric measuring the latency of requests for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricLatency.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricSystemErrors` <a name="metricSystemErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricSystemErrors"></a>

```typescript
public metricSystemErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of system errors (5xx status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricSystemErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetExecutionTime` <a name="metricTargetExecutionTime" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetExecutionTime"></a>

```typescript
public metricTargetExecutionTime(props?: MetricOptions): Metric
```

Return a metric measuring the target execution time for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetExecutionTime.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricTargetType` <a name="metricTargetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetType"></a>

```typescript
public metricTargetType(targetType: string, props?: MetricOptions): Metric
```

Return a metric containing the number of requests served by each target type for this gateway.

###### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetType.parameter.targetType"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricTargetType.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricThrottles` <a name="metricThrottles" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricThrottles"></a>

```typescript
public metricThrottles(props?: MetricOptions): Metric
```

Return a metric containing the number of throttled requests (429 status code) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricThrottles.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricUserErrors` <a name="metricUserErrors" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricUserErrors"></a>

```typescript
public metricUserErrors(props?: MetricOptions): Metric
```

Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.metricUserErrors.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.authorizerConfiguration">authorizerConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer</code> | The authorizer configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayArn">gatewayArn</a></code> | <code>string</code> | The ARN of the gateway resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayId">gatewayId</a></code> | <code>string</code> | The id of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.name">name</a></code> | <code>string</code> | The name of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.protocolConfiguration">protocolConfiguration</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol</code> | The protocol configuration for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.role">role</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the gateway to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.description">description</a></code> | <code>string</code> | The description of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.exceptionLevel">exceptionLevel</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel</code> | The exception level for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayUrl">gatewayUrl</a></code> | <code>string</code> | The URL endpoint for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | The KMS key used for encryption. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.status">status</a></code> | <code>string</code> | The status of the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.statusReason">statusReason</a></code> | <code>string[]</code> | The status reasons for the gateway. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `authorizerConfiguration`<sup>Required</sup> <a name="authorizerConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.authorizerConfiguration"></a>

```typescript
public readonly authorizerConfiguration: IGatewayAuthorizer;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

The authorizer configuration for the gateway.

---

##### `gatewayArn`<sup>Required</sup> <a name="gatewayArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayArn"></a>

```typescript
public readonly gatewayArn: string;
```

- *Type:* string

The ARN of the gateway resource.

---

##### `gatewayId`<sup>Required</sup> <a name="gatewayId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayId"></a>

```typescript
public readonly gatewayId: string;
```

- *Type:* string

The id of the gateway.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway.

---

##### `protocolConfiguration`<sup>Required</sup> <a name="protocolConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.protocolConfiguration"></a>

```typescript
public readonly protocolConfiguration: IGatewayProtocol;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol

The protocol configuration for the gateway.

---

##### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.role"></a>

```typescript
public readonly role: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the gateway to access AWS services.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway.

---

##### `exceptionLevel`<sup>Optional</sup> <a name="exceptionLevel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.exceptionLevel"></a>

```typescript
public readonly exceptionLevel: GatewayExceptionLevel;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel

The exception level for the gateway.

---

##### `gatewayUrl`<sup>Optional</sup> <a name="gatewayUrl" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.gatewayUrl"></a>

```typescript
public readonly gatewayUrl: string;
```

- *Type:* string

The URL endpoint for the gateway.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

The KMS key used for encryption.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway.

---

##### `statusReason`<sup>Optional</sup> <a name="statusReason" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.statusReason"></a>

```typescript
public readonly statusReason: string[];
```

- *Type:* string[]

The status reasons for the gateway.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway was last updated.

---

### IGatewayAuthorizer <a name="IGatewayAuthorizer" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer"></a>

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.CustomJwtAuthorizer, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IamAuthorizer, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer

Abstract interface for gateway authorizer configuration.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer.property.authorizerType">authorizerType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType</code> | The authorizer type. |

---

##### `authorizerType`<sup>Required</sup> <a name="authorizerType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayAuthorizer.property.authorizerType"></a>

```typescript
public readonly authorizerType: GatewayAuthorizerType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType

The authorizer type.

---

### IGatewayProtocol <a name="IGatewayProtocol" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol"></a>

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpProtocolConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol

Abstract interface for gateway protocol configuration.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol.property.protocolType">protocolType</a></code> | <code>string</code> | The protocol type. |

---

##### `protocolType`<sup>Required</sup> <a name="protocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayProtocol.property.protocolType"></a>

```typescript
public readonly protocolType: string;
```

- *Type:* string

The protocol type.

---

### IGatewayTarget <a name="IGatewayTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget"></a>

- *Extends:* aws-cdk-lib.IResource

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget

Interface for GatewayTarget resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grant">grant</a></code> | Grants IAM actions to the IAM Principal. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantManage">grantManage</a></code> | Grants `Create`, `Update`, and `Delete` actions on the Gateway Target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantRead">grantRead</a></code> | Grants `Get` and `List` actions on the Gateway Target. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grants IAM actions to the IAM Principal.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantManage` <a name="grantManage" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantManage"></a>

```typescript
public grantManage(grantee: IGrantable): Grant
```

Grants `Create`, `Update`, and `Delete` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantManage.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grants `Get` and `List` actions on the Gateway Target.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | The credential provider configuration for the target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway that this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.name">name</a></code> | <code>string</code> | The name of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetArn">targetArn</a></code> | <code>string</code> | The ARN of the gateway target resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetId">targetId</a></code> | <code>string</code> | The id of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetProtocolType">targetProtocolType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType</code> | The target protocol. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway target was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.description">description</a></code> | <code>string</code> | The description of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.status">status</a></code> | <code>string</code> | The status of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.statusReasons">statusReasons</a></code> | <code>string[]</code> | The status reasons for the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway target was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `credentialProviderConfigurations`<sup>Required</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]

The credential provider configuration for the target.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that this target belongs to.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway target.

---

##### `targetArn`<sup>Required</sup> <a name="targetArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetArn"></a>

```typescript
public readonly targetArn: string;
```

- *Type:* string

The ARN of the gateway target resource.

---

##### `targetId`<sup>Required</sup> <a name="targetId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetId"></a>

```typescript
public readonly targetId: string;
```

- *Type:* string

The id of the gateway target.

---

##### `targetProtocolType`<sup>Required</sup> <a name="targetProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.targetProtocolType"></a>

```typescript
public readonly targetProtocolType: GatewayTargetProtocolType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType

The target protocol.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway target was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway target.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway target.

---

##### `statusReasons`<sup>Optional</sup> <a name="statusReasons" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.statusReasons"></a>

```typescript
public readonly statusReasons: string[];
```

- *Type:* string[]

The status reasons for the gateway target.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway target was last updated.

---

### IMcpGatewayTarget <a name="IMcpGatewayTarget" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget"></a>

- *Extends:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGatewayTarget

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTarget, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget

Interface for MCP gateway targets.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.credentialProviderConfigurations">credentialProviderConfigurations</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]</code> | The credential provider configuration for the target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.gateway">gateway</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway</code> | The gateway that this target belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.name">name</a></code> | <code>string</code> | The name of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetArn">targetArn</a></code> | <code>string</code> | The ARN of the gateway target resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetId">targetId</a></code> | <code>string</code> | The id of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetProtocolType">targetProtocolType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType</code> | The target protocol. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the gateway target was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.description">description</a></code> | <code>string</code> | The description of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.status">status</a></code> | <code>string</code> | The status of the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.statusReasons">statusReasons</a></code> | <code>string[]</code> | The status reasons for the gateway target. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the gateway target was last updated. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The type of target. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `credentialProviderConfigurations`<sup>Required</sup> <a name="credentialProviderConfigurations" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.credentialProviderConfigurations"></a>

```typescript
public readonly credentialProviderConfigurations: ICredentialProvider[];
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ICredentialProvider[]

The credential provider configuration for the target.

---

##### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.gateway"></a>

```typescript
public readonly gateway: IGateway;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

The gateway that this target belongs to.

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the gateway target.

---

##### `targetArn`<sup>Required</sup> <a name="targetArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetArn"></a>

```typescript
public readonly targetArn: string;
```

- *Type:* string

The ARN of the gateway target resource.

---

##### `targetId`<sup>Required</sup> <a name="targetId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetId"></a>

```typescript
public readonly targetId: string;
```

- *Type:* string

The id of the gateway target.

---

##### `targetProtocolType`<sup>Required</sup> <a name="targetProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetProtocolType"></a>

```typescript
public readonly targetProtocolType: GatewayTargetProtocolType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType

The target protocol.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the gateway target was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the gateway target.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the gateway target.

---

##### `statusReasons`<sup>Optional</sup> <a name="statusReasons" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.statusReasons"></a>

```typescript
public readonly statusReasons: string[];
```

- *Type:* string[]

The status reasons for the gateway target.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the gateway target was last updated.

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMcpGatewayTarget.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The type of target.

---

### IMemory <a name="IMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory"></a>

- *Extends:* aws-cdk-lib.IResource, aws-cdk-lib.aws_iam.IGrantable

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.Memory, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory

Interface for Memory resources.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grant">grant</a></code> | Grant the given principal identity permissions to perform actions on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantAdmin">grantAdmin</a></code> | Grant the given principal identity permissions to manage the control plane of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDelete">grantDelete</a></code> | Grant the given principal identity permissions to delete content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteLongTermMemory">grantDeleteLongTermMemory</a></code> | Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteShortTermMemory">grantDeleteShortTermMemory</a></code> | Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantFullAccess">grantFullAccess</a></code> | Grant the given principal identity permissions to do every action on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantRead">grantRead</a></code> | Grant the given principal identity permissions to read the contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadLongTermMemory">grantReadLongTermMemory</a></code> | Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadShortTermMemory">grantReadShortTermMemory</a></code> | Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantWrite">grantWrite</a></code> | Grant the given principal identity permissions to write content to this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metric">metric</a></code> | Return the given named metric for this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricErrorsForApiOperation">metricErrorsForApiOperation</a></code> | Return a metric containing the number of errors for a specific API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricEventCreationCount">metricEventCreationCount</a></code> | Returns the metric containing the number of created memory events and memory records. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricForApiOperation">metricForApiOperation</a></code> | Return the given named metric related to the API operation performed on this memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricInvocationsForApiOperation">metricInvocationsForApiOperation</a></code> | Return a metric containing the total number of API requests made for a specific memory operation. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricLatencyForApiOperation">metricLatencyForApiOperation</a></code> | Return a metric measuring the latency of a specific API operation performed on this memory. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grant"></a>

```typescript
public grant(grantee: IGrantable, actions: ...string[]): Grant
```

Grant the given principal identity permissions to perform actions on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grant.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

###### `actions`<sup>Required</sup> <a name="actions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grant.parameter.actions"></a>

- *Type:* ...string[]

---

##### `grantAdmin` <a name="grantAdmin" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantAdmin"></a>

```typescript
public grantAdmin(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to manage the control plane of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantAdmin.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantDelete` <a name="grantDelete" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDelete"></a>

```typescript
public grantDelete(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDelete.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantDeleteLongTermMemory` <a name="grantDeleteLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteLongTermMemory"></a>

```typescript
public grantDeleteLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Long-Term Memory (LTM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantDeleteShortTermMemory` <a name="grantDeleteShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteShortTermMemory"></a>

```typescript
public grantDeleteShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to delete Short-Term Memory (STM) content on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantDeleteShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantFullAccess` <a name="grantFullAccess" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantFullAccess"></a>

```typescript
public grantFullAccess(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to do every action on this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantFullAccess.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantRead` <a name="grantRead" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantRead"></a>

```typescript
public grantRead(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the contents of this memory.

Both Short-Term Memory (STM) and Long-Term Memory (LTM).

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantRead.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantReadLongTermMemory` <a name="grantReadLongTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadLongTermMemory"></a>

```typescript
public grantReadLongTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Long-Term Memory (LTM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadLongTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantReadShortTermMemory` <a name="grantReadShortTermMemory" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadShortTermMemory"></a>

```typescript
public grantReadShortTermMemory(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to read the Short-Term Memory (STM) contents of this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantReadShortTermMemory.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `grantWrite` <a name="grantWrite" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantWrite"></a>

```typescript
public grantWrite(grantee: IGrantable): Grant
```

Grant the given principal identity permissions to write content to this memory.

###### `grantee`<sup>Required</sup> <a name="grantee" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.grantWrite.parameter.grantee"></a>

- *Type:* aws-cdk-lib.aws_iam.IGrantable

---

##### `metric` <a name="metric" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metric"></a>

```typescript
public metric(metricName: string, dimensions: {[ key: string ]: string}, props?: MetricOptions): Metric
```

Return the given named metric for this memory.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metric.parameter.metricName"></a>

- *Type:* string

---

###### `dimensions`<sup>Required</sup> <a name="dimensions" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metric.parameter.dimensions"></a>

- *Type:* {[ key: string ]: string}

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metric.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricErrorsForApiOperation` <a name="metricErrorsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricErrorsForApiOperation"></a>

```typescript
public metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the number of errors for a specific API operation performed on this memory.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricErrorsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricErrorsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricEventCreationCount` <a name="metricEventCreationCount" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricEventCreationCount"></a>

```typescript
public metricEventCreationCount(props?: MetricOptions): Metric
```

Returns the metric containing the number of created memory events and memory records.

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricEventCreationCount.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricForApiOperation` <a name="metricForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricForApiOperation"></a>

```typescript
public metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric
```

Return the given named metric related to the API operation performed on this memory.

###### `metricName`<sup>Required</sup> <a name="metricName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricForApiOperation.parameter.metricName"></a>

- *Type:* string

---

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricInvocationsForApiOperation` <a name="metricInvocationsForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricInvocationsForApiOperation"></a>

```typescript
public metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric containing the total number of API requests made for a specific memory operation.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricInvocationsForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricInvocationsForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

##### `metricLatencyForApiOperation` <a name="metricLatencyForApiOperation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricLatencyForApiOperation"></a>

```typescript
public metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric
```

Return a metric measuring the latency of a specific API operation performed on this memory.

###### `operation`<sup>Required</sup> <a name="operation" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricLatencyForApiOperation.parameter.operation"></a>

- *Type:* string

---

###### `props`<sup>Optional</sup> <a name="props" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.metricLatencyForApiOperation.parameter.props"></a>

- *Type:* aws-cdk-lib.aws_cloudwatch.MetricOptions

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.grantPrincipal">grantPrincipal</a></code> | <code>aws-cdk-lib.aws_iam.IPrincipal</code> | The principal to grant permissions to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.memoryArn">memoryArn</a></code> | <code>string</code> | The ARN of the memory resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.memoryId">memoryId</a></code> | <code>string</code> | The id of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.createdAt">createdAt</a></code> | <code>string</code> | Timestamp when the memory was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.executionRole">executionRole</a></code> | <code>aws-cdk-lib.aws_iam.IRole</code> | The IAM role that provides permissions for the memory to access AWS services. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.kmsKey">kmsKey</a></code> | <code>aws-cdk-lib.aws_kms.IKey</code> | Custom KMS key for encryption (if provided). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.status">status</a></code> | <code>string</code> | The status of the memory. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.updatedAt">updatedAt</a></code> | <code>string</code> | Timestamp when the memory was last updated. |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `grantPrincipal`<sup>Required</sup> <a name="grantPrincipal" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.grantPrincipal"></a>

```typescript
public readonly grantPrincipal: IPrincipal;
```

- *Type:* aws-cdk-lib.aws_iam.IPrincipal

The principal to grant permissions to.

---

##### `memoryArn`<sup>Required</sup> <a name="memoryArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.memoryArn"></a>

```typescript
public readonly memoryArn: string;
```

- *Type:* string

The ARN of the memory resource.

---

##### `memoryId`<sup>Required</sup> <a name="memoryId" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.memoryId"></a>

```typescript
public readonly memoryId: string;
```

- *Type:* string

The id of the memory.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

Timestamp when the memory was created.

---

##### `executionRole`<sup>Optional</sup> <a name="executionRole" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.executionRole"></a>

```typescript
public readonly executionRole: IRole;
```

- *Type:* aws-cdk-lib.aws_iam.IRole

The IAM role that provides permissions for the memory to access AWS services.

---

##### `kmsKey`<sup>Optional</sup> <a name="kmsKey" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.kmsKey"></a>

```typescript
public readonly kmsKey: IKey;
```

- *Type:* aws-cdk-lib.aws_kms.IKey

Custom KMS key for encryption (if provided).

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The status of the memory.

---

##### `updatedAt`<sup>Optional</sup> <a name="updatedAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemory.property.updatedAt"></a>

```typescript
public readonly updatedAt: string;
```

- *Type:* string

Timestamp when the memory was last updated.

---

### IMemoryStrategy <a name="IMemoryStrategy" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy"></a>

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.BuiltInMemoryStrategy, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OverrideMemoryStrategy, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy

Interface for Memory strategies.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.grant">grant</a></code> | Grants the necessary permissions to the role. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.render">render</a></code> | Renders internal attributes to CloudFormation. |

---

##### `grant` <a name="grant" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.grant"></a>

```typescript
public grant(role: IRole): Grant
```

Grants the necessary permissions to the role.

###### `role`<sup>Required</sup> <a name="role" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.grant.parameter.role"></a>

- *Type:* aws-cdk-lib.aws_iam.IRole

The role to grant permissions to.

---

##### `render` <a name="render" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.render"></a>

```typescript
public render(): MemoryStrategyProperty
```

Renders internal attributes to CloudFormation.

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.name">name</a></code> | <code>string</code> | The name of the memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.namespaces">namespaces</a></code> | <code>string[]</code> | The namespaces of the memory strategy to store extracted memories. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.strategyClassType">strategyClassType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType</code> | The class of memory strategy (built-in or custom). |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.strategyType">strategyType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType</code> | The type of memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.description">description</a></code> | <code>string</code> | The description of the memory strategy. |

---

##### `name`<sup>Required</sup> <a name="name" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.name"></a>

```typescript
public readonly name: string;
```

- *Type:* string

The name of the memory strategy.

---

##### `namespaces`<sup>Required</sup> <a name="namespaces" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.namespaces"></a>

```typescript
public readonly namespaces: string[];
```

- *Type:* string[]

The namespaces of the memory strategy to store extracted memories.

---

##### `strategyClassType`<sup>Required</sup> <a name="strategyClassType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.strategyClassType"></a>

```typescript
public readonly strategyClassType: MemoryStrategyClassType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType

The class of memory strategy (built-in or custom).

---

##### `strategyType`<sup>Required</sup> <a name="strategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.strategyType"></a>

```typescript
public readonly strategyType: MemoryStrategyType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType

The type of memory strategy.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IMemoryStrategy.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the memory strategy.

---

### IRuntimeEndpoint <a name="IRuntimeEndpoint" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint"></a>

- *Extends:* aws-cdk-lib.IResource

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpoint, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.RuntimeEndpointBase, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint

Interface for Runtime Endpoint resources.


#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.node">node</a></code> | <code>constructs.Node</code> | The tree node. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.env">env</a></code> | <code>aws-cdk-lib.ResourceEnvironment</code> | The environment this resource belongs to. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.stack">stack</a></code> | <code>aws-cdk-lib.Stack</code> | The stack in which this resource is defined. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.agentRuntimeArn">agentRuntimeArn</a></code> | <code>string</code> | The ARN of the parent agent runtime. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.agentRuntimeEndpointArn">agentRuntimeEndpointArn</a></code> | <code>string</code> | The ARN of the runtime endpoint resource. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.endpointName">endpointName</a></code> | <code>string</code> | The name of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.createdAt">createdAt</a></code> | <code>string</code> | When the endpoint was created. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.description">description</a></code> | <code>string</code> | The description of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.liveVersion">liveVersion</a></code> | <code>string</code> | The live version of the agent runtime that is currently serving requests. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.status">status</a></code> | <code>string</code> | The current status of the runtime endpoint. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.targetVersion">targetVersion</a></code> | <code>string</code> | The target version the endpoint is transitioning to (during updates). |

---

##### `node`<sup>Required</sup> <a name="node" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.node"></a>

```typescript
public readonly node: Node;
```

- *Type:* constructs.Node

The tree node.

---

##### `env`<sup>Required</sup> <a name="env" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.env"></a>

```typescript
public readonly env: ResourceEnvironment;
```

- *Type:* aws-cdk-lib.ResourceEnvironment

The environment this resource belongs to.

For resources that are created and managed by the CDK
(generally, those created by creating new class instances like Role, Bucket, etc.),
this is always the same as the environment of the stack they belong to;
however, for imported resources
(those obtained from static methods like fromRoleArn, fromBucketName, etc.),
that might be different than the stack they were imported into.

---

##### `stack`<sup>Required</sup> <a name="stack" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.stack"></a>

```typescript
public readonly stack: Stack;
```

- *Type:* aws-cdk-lib.Stack

The stack in which this resource is defined.

---

##### `agentRuntimeArn`<sup>Required</sup> <a name="agentRuntimeArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.agentRuntimeArn"></a>

```typescript
public readonly agentRuntimeArn: string;
```

- *Type:* string

The ARN of the parent agent runtime.

---

##### `agentRuntimeEndpointArn`<sup>Required</sup> <a name="agentRuntimeEndpointArn" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.agentRuntimeEndpointArn"></a>

```typescript
public readonly agentRuntimeEndpointArn: string;
```

- *Type:* string

The ARN of the runtime endpoint resource.

---

*Example*

```typescript
"arn:aws:bedrock-agentcore:us-west-2:123456789012:agent-runtime-endpoint/endpoint-abc123"
```


##### `endpointName`<sup>Required</sup> <a name="endpointName" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.endpointName"></a>

```typescript
public readonly endpointName: string;
```

- *Type:* string

The name of the runtime endpoint.

---

##### `createdAt`<sup>Optional</sup> <a name="createdAt" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.createdAt"></a>

```typescript
public readonly createdAt: string;
```

- *Type:* string

When the endpoint was created.

---

##### `description`<sup>Optional</sup> <a name="description" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.description"></a>

```typescript
public readonly description: string;
```

- *Type:* string

The description of the runtime endpoint.

---

##### `liveVersion`<sup>Optional</sup> <a name="liveVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.liveVersion"></a>

```typescript
public readonly liveVersion: string;
```

- *Type:* string

The live version of the agent runtime that is currently serving requests.

---

##### `status`<sup>Optional</sup> <a name="status" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.status"></a>

```typescript
public readonly status: string;
```

- *Type:* string

The current status of the runtime endpoint.

---

##### `targetVersion`<sup>Optional</sup> <a name="targetVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.IRuntimeEndpoint.property.targetVersion"></a>

```typescript
public readonly targetVersion: string;
```

- *Type:* string

The target version the endpoint is transitioning to (during updates).

---

### ITargetConfiguration <a name="ITargetConfiguration" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration"></a>

- *Implemented By:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.LambdaTargetConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.OpenApiTargetConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.SmithyTargetConfiguration, @krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration

Base interface for target configurations.

#### Methods <a name="Methods" id="Methods"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.bind">bind</a></code> | Binds the configuration to a construct scope Sets up permissions and dependencies. |

---

##### `bind` <a name="bind" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.bind"></a>

```typescript
public bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig
```

Binds the configuration to a construct scope Sets up permissions and dependencies.

###### `scope`<sup>Required</sup> <a name="scope" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.bind.parameter.scope"></a>

- *Type:* constructs.Construct

---

###### `gateway`<sup>Required</sup> <a name="gateway" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.bind.parameter.gateway"></a>

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.IGateway

---

#### Properties <a name="Properties" id="Properties"></a>

| **Name** | **Type** | **Description** |
| --- | --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.property.targetType">targetType</a></code> | <code>@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType</code> | The target type. |

---

##### `targetType`<sup>Required</sup> <a name="targetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ITargetConfiguration.property.targetType"></a>

```typescript
public readonly targetType: McpTargetType;
```

- *Type:* @krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType

The target type.

---

## Enums <a name="Enums" id="Enums"></a>

### CredentialProviderType <a name="CredentialProviderType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType"></a>

Credential provider types supported by gateway target.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.GATEWAY_IAM_ROLE">GATEWAY_IAM_ROLE</a></code> | Gateway IAM role credential provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.OAUTH">OAUTH</a></code> | OAuth credential provider. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.API_KEY">API_KEY</a></code> | API Key credential provider. |

---

##### `GATEWAY_IAM_ROLE` <a name="GATEWAY_IAM_ROLE" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.GATEWAY_IAM_ROLE"></a>

Gateway IAM role credential provider.

This uses the Gateway's execution role to
authenticate with AWS services.

---


##### `OAUTH` <a name="OAUTH" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.OAUTH"></a>

OAuth credential provider.

---


##### `API_KEY` <a name="API_KEY" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.CredentialProviderType.API_KEY"></a>

API Key credential provider.

---


### GatewayAuthorizerType <a name="GatewayAuthorizerType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType"></a>

Gateway authorizer type.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType.CUSTOM_JWT">CUSTOM_JWT</a></code> | Custom JWT authorizer type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType.AWS_IAM">AWS_IAM</a></code> | AWS IAM authorizer type. |

---

##### `CUSTOM_JWT` <a name="CUSTOM_JWT" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType.CUSTOM_JWT"></a>

Custom JWT authorizer type.

---


##### `AWS_IAM` <a name="AWS_IAM" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayAuthorizerType.AWS_IAM"></a>

AWS IAM authorizer type.

---


### GatewayExceptionLevel <a name="GatewayExceptionLevel" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel"></a>

Exception levels for gateway.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel.DEBUG">DEBUG</a></code> | Debug mode for granular exception messages. |

---

##### `DEBUG` <a name="DEBUG" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayExceptionLevel.DEBUG"></a>

Debug mode for granular exception messages.

Allows the return of
specific error messages related to the gateway target configuration
to help you with debugging.

---


### GatewayTargetProtocolType <a name="GatewayTargetProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType"></a>

****************************************************************************                                ENUM ***************************************************************************.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType.MCP">MCP</a></code> | Model Context Protocol type. |

---

##### `MCP` <a name="MCP" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.GatewayTargetProtocolType.MCP"></a>

Model Context Protocol type.

---


### McpGatewaySearchType <a name="McpGatewaySearchType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewaySearchType"></a>

Search types supported by MCP gateway.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewaySearchType.SEMANTIC">SEMANTIC</a></code> | Semantic search type. |

---

##### `SEMANTIC` <a name="SEMANTIC" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpGatewaySearchType.SEMANTIC"></a>

Semantic search type.

When semantic search is enabled, your gateway can search the tools via
the gateway SDK based off of a natural language phrase.

---


### MCPProtocolVersion <a name="MCPProtocolVersion" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion"></a>

MCP protocol versions.

The Model Context Protocol uses string-based version identifiers following the format YYYY-MM-DD,
to indicate the last date backwards incompatible changes were made.
Versions are available at https://github.com/modelcontextprotocol/modelcontextprotocol/releases

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion.MCP_2025_06_18">MCP_2025_06_18</a></code> | The latest version of the MCP protocol. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion.MCP_2025_03_26">MCP_2025_03_26</a></code> | MCP version 2025-03-26. |

---

##### `MCP_2025_06_18` <a name="MCP_2025_06_18" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion.MCP_2025_06_18"></a>

The latest version of the MCP protocol.

---


##### `MCP_2025_03_26` <a name="MCP_2025_03_26" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MCPProtocolVersion.MCP_2025_03_26"></a>

MCP version 2025-03-26.

---


### McpTargetType <a name="McpTargetType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType"></a>

MCP target types.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.OPENAPI_SCHEMA">OPENAPI_SCHEMA</a></code> | OpenAPI schema target type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.SMITHY_MODEL">SMITHY_MODEL</a></code> | Smithy model target type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.LAMBDA">LAMBDA</a></code> | Lambda function target type. |

---

##### `OPENAPI_SCHEMA` <a name="OPENAPI_SCHEMA" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.OPENAPI_SCHEMA"></a>

OpenAPI schema target type.

---


##### `SMITHY_MODEL` <a name="SMITHY_MODEL" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.SMITHY_MODEL"></a>

Smithy model target type.

---


##### `LAMBDA` <a name="LAMBDA" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.McpTargetType.LAMBDA"></a>

Lambda function target type.

---


### MemoryStrategyClassType <a name="MemoryStrategyClassType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType"></a>

Internal enum used to differentiate the different classes of memory strategies.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.BUILT_IN">BUILT_IN</a></code> | Built-in memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.BUILT_IN_OVERRIDE">BUILT_IN_OVERRIDE</a></code> | Overrides a built-in memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.CUSTOM">CUSTOM</a></code> | Fully custom memory strategy. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.SELF_MANAGED">SELF_MANAGED</a></code> | Self managed memory strategy. |

---

##### `BUILT_IN` <a name="BUILT_IN" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.BUILT_IN"></a>

Built-in memory strategy.

---


##### `BUILT_IN_OVERRIDE` <a name="BUILT_IN_OVERRIDE" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.BUILT_IN_OVERRIDE"></a>

Overrides a built-in memory strategy.

---


##### `CUSTOM` <a name="CUSTOM" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.CUSTOM"></a>

Fully custom memory strategy.

---


##### `SELF_MANAGED` <a name="SELF_MANAGED" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyClassType.SELF_MANAGED"></a>

Self managed memory strategy.

---


### MemoryStrategyType <a name="MemoryStrategyType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType"></a>

Long-term memory extraction strategy types.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.SUMMARIZATION">SUMMARIZATION</a></code> | Summarization strategy - extracts concise summaries to preserve critical context and key insights. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.SEMANTIC">SEMANTIC</a></code> | Semantic memory strategy - extracts general factual knowledge, concepts and meanings from raw conversations using vector embeddings for similarity search. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.USER_PREFERENCE">USER_PREFERENCE</a></code> | User preferences strategy - extracts user behavior patterns from raw conversations. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.CUSTOM">CUSTOM</a></code> | Customize memory processing through custom foundation model and prompt templates. |

---

##### `SUMMARIZATION` <a name="SUMMARIZATION" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.SUMMARIZATION"></a>

Summarization strategy - extracts concise summaries to preserve critical context and key insights.

---


##### `SEMANTIC` <a name="SEMANTIC" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.SEMANTIC"></a>

Semantic memory strategy - extracts general factual knowledge, concepts and meanings from raw conversations using vector embeddings for similarity search.

---


##### `USER_PREFERENCE` <a name="USER_PREFERENCE" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.USER_PREFERENCE"></a>

User preferences strategy - extracts user behavior patterns from raw conversations.

---


##### `CUSTOM` <a name="CUSTOM" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.MemoryStrategyType.CUSTOM"></a>

Customize memory processing through custom foundation model and prompt templates.

---


### ProtocolType <a name="ProtocolType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType"></a>

Protocol configuration for Agent Runtime.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType.MCP">MCP</a></code> | Model Context Protocol. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType.HTTP">HTTP</a></code> | HTTP protocol. |

---

##### `MCP` <a name="MCP" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType.MCP"></a>

Model Context Protocol.

---


##### `HTTP` <a name="HTTP" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.ProtocolType.HTTP"></a>

HTTP protocol.

---


### SchemaDefinitionType <a name="SchemaDefinitionType" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType"></a>

Schema definition types.

#### Members <a name="Members" id="Members"></a>

| **Name** | **Description** |
| --- | --- |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.STRING">STRING</a></code> | String type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.NUMBER">NUMBER</a></code> | Number type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.OBJECT">OBJECT</a></code> | Object type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.ARRAY">ARRAY</a></code> | Array type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.BOOLEAN">BOOLEAN</a></code> | Boolean type. |
| <code><a href="#@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.INTEGER">INTEGER</a></code> | Integer type. |

---

##### `STRING` <a name="STRING" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.STRING"></a>

String type.

---


##### `NUMBER` <a name="NUMBER" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.NUMBER"></a>

Number type.

---


##### `OBJECT` <a name="OBJECT" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.OBJECT"></a>

Object type.

---


##### `ARRAY` <a name="ARRAY" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.ARRAY"></a>

Array type.

---


##### `BOOLEAN` <a name="BOOLEAN" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.BOOLEAN"></a>

Boolean type.

---


##### `INTEGER` <a name="INTEGER" id="@krokoko/agentcore-cdk-constructs.bedrock_agentcore.SchemaDefinitionType.INTEGER"></a>

Integer type.

---

