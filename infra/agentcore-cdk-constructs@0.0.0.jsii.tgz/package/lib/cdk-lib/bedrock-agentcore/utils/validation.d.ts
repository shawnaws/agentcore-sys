/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
export interface StringValidationConfig {
    minLength: number;
    maxLength: number;
    fieldName: string;
    pattern?: RegExp;
    extraErrorInfo?: string;
}
export declare function validateStringField(value: string, config: StringValidationConfig): void;
export interface NumberValidationConfig {
    min: number;
    max: number;
    fieldName: string;
}
export declare function validateNumberField(value: number, config: NumberValidationConfig): void;
export declare function validateMemoryName(name: string): void;
