/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { CfnRuntime } from 'aws-cdk-lib/aws-bedrockagentcore';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as assets from 'aws-cdk-lib/aws-ecr-assets';
import { Construct } from 'constructs';
import { Runtime } from './runtime';
/**
 * Abstract base class for agent runtime artifacts.
 * Provides methods to reference container images from ECR repositories or local assets.
 */
export declare abstract class AgentRuntimeArtifact {
    /**
     * Reference an image in an ECR repository
     */
    static fromEcrRepository(repository: ecr.IRepository, tag?: string): AgentRuntimeArtifact;
    /**
     * Reference an agent runtime artifact that's constructed directly from sources on disk
     * @param directory The directory where the Dockerfile is stored
     * @param options The options to further configure the selected image
     */
    static fromAsset(directory: string, options?: assets.DockerImageAssetOptions): AgentRuntimeArtifact;
    /**
     * Called when the image is used by a Runtime to handle side effects like permissions
     */
    abstract bind(scope: Construct, runtime: Runtime): void;
    /**
     * Render the artifact configuration for CloudFormation
     * @internal
     */
    abstract _render(): CfnRuntime.AgentRuntimeArtifactProperty;
}
