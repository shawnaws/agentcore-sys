/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { CfnRuntime } from 'aws-cdk-lib/aws-bedrockagentcore';
/**
 * Abstract base class for runtime authorizer configurations.
 * Provides static factory methods to create different authentication types.
 */
export declare abstract class RuntimeAuthorizerConfiguration {
    /**
     * Use IAM authentication (default).
     * Requires AWS credentials to sign requests using SigV4.
     *
     * @returns RuntimeAuthorizerConfiguration for IAM authentication
     */
    static usingIAM(): RuntimeAuthorizerConfiguration;
    /**
     * Use custom JWT authentication.
     * Validates JWT tokens against the specified OIDC provider.
     *
     * @param discoveryUrl The OIDC discovery URL (must end with /.well-known/openid-configuration)
     * @param allowedClients Optional array of allowed client IDs
     * @param allowedAudience Optional array of allowed audiences
     * @returns RuntimeAuthorizerConfiguration for JWT authentication
     */
    static usingJWT(discoveryUrl: string, allowedClients?: string[], allowedAudience?: string[]): RuntimeAuthorizerConfiguration;
    /**
     * Use AWS Cognito User Pool authentication.
     * Validates Cognito-issued JWT tokens.
     *
     * @param userPoolId The Cognito User Pool ID (e.g., 'us-west-2_ABC123')
     * @param clientId The Cognito App Client ID
     * @param region Optional AWS region where the User Pool is located (defaults to stack region)
     * @param allowedAudience Optional array of allowed audiences
     * @returns RuntimeAuthorizerConfiguration for Cognito authentication
     */
    static usingCognito(userPoolId: string, clientId: string, region?: string, allowedAudience?: string[]): RuntimeAuthorizerConfiguration;
    /**
     * Use OAuth 2.0 authentication.
     * Supports various OAuth providers.
     *
     * @param discoveryUrl The OIDC discovery URL (must end with /.well-known/openid-configuration)
     * @param clientId OAuth client ID
     * @param allowedAudience Optional array of allowed audiences
     * @returns RuntimeAuthorizerConfiguration for OAuth authentication
     */
    static usingOAuth(discoveryUrl: string, clientId: string, allowedAudience?: string[]): RuntimeAuthorizerConfiguration;
    /**
     * Render the authorizer configuration for CloudFormation
     * @internal
     */
    abstract _render(): CfnRuntime.AuthorizerConfigurationProperty | undefined;
}
