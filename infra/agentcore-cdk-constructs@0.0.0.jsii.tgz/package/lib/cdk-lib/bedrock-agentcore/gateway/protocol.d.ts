/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { CfnGateway } from 'aws-cdk-lib/aws-bedrockagentcore';
/******************************************************************************
 *                                 Enums
 *****************************************************************************/
/**
 * The type of protocols
 * @internal
 */
export declare enum GatewayProtocolType {
    /**
     * MCP (Model Context Protocol) protocol type.
     */
    MCP = "MCP"
}
/******************************************************************************
 *                                Protocol Configuration
 *****************************************************************************/
/**
 * Abstract interface for gateway protocol configuration
 */
export interface IGatewayProtocol {
    /**
     * The protocol type
     */
    readonly protocolType: string;
    /**
     * Returns internal info as the CFN protocol configuration object
     * @internal
     */
    _render(): any;
}
/**
 * Factory class for instantiating Gateway Protocols
 */
export declare abstract class GatewayProtocol {
    /**
     * Create an MCP protocol configuration
     * @param props - Optional MCP configuration properties
     * @returns IGatewayProtocol configured for MCP
     */
    static mcp(props?: McpConfiguration): IGatewayProtocol;
}
/******************************************************************************
 *                          MCP Protocol Configuration
 *****************************************************************************/
/**
 * MCP protocol versions.
 * The Model Context Protocol uses string-based version identifiers following the format YYYY-MM-DD,
 * to indicate the last date backwards incompatible changes were made.
 * Versions are available at https://github.com/modelcontextprotocol/modelcontextprotocol/releases
 */
export declare enum MCPProtocolVersion {
    /**
     * The latest version of the MCP protocol.
     */
    MCP_2025_06_18 = "2025-06-18",
    /** MCP version 2025-03-26 */
    MCP_2025_03_26 = "2025-03-26"
}
/**
 * Search types supported by MCP gateway
 */
export declare enum McpGatewaySearchType {
    /**
     * Semantic search type.
     * When semantic search is enabled, your gateway can search the tools via
     * the gateway SDK based off of a natural language phrase.
     */
    SEMANTIC = "SEMANTIC"
}
/**
 * MCP protocol configuration
 * The configuration for the Model Context Protocol (MCP).
 * This protocol enables communication between Amazon Bedrock Agent and external tools.
 */
export interface McpConfiguration {
    /**
     * The instructions for using the Model Context Protocol gateway.
     * These instructions provide guidance on how to interact with the gateway.
     *
     * @default - No instructions provided
     */
    readonly instructions?: string;
    /**
     * The search type for the Model Context Protocol gateway.
     * This field specifies how the gateway handles search operations.
     *
     * @default - No search type specified
     */
    readonly searchType?: McpGatewaySearchType;
    /**
     * The supported versions of the Model Context Protocol.
     * This field specifies which versions of the protocol the gateway can use.
     *
     * @default - No specific versions specified
     */
    readonly supportedVersions?: MCPProtocolVersion[];
}
/**
 * MCP (Model Context Protocol) configuration implementation
 */
export declare class McpProtocolConfiguration implements IGatewayProtocol {
    readonly protocolType: string;
    /**
     * The supported MCP protocol versions
     */
    readonly supportedVersions?: MCPProtocolVersion[];
    /**
     * The search type for the MCP gateway
     */
    readonly searchType?: string;
    /**
     * Instructions for using the MCP gateway
     */
    readonly instructions?: string;
    constructor(props?: McpConfiguration);
    /**
     * @internal
     */
    _render(): CfnGateway.GatewayProtocolConfigurationProperty;
}
