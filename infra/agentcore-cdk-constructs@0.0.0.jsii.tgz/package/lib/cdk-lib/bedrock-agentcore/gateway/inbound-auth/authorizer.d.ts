/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { IUserPoolClient, UserPool } from 'aws-cdk-lib/aws-cognito';
/******************************************************************************
 *                                Authorizer Configuration
 *****************************************************************************/
/**
 * Gateway authorizer type
 */
export declare enum GatewayAuthorizerType {
    /** Custom JWT authorizer type */
    CUSTOM_JWT = "CUSTOM_JWT",
    /** AWS IAM authorizer type */
    AWS_IAM = "AWS_IAM"
}
/**
 * Abstract interface for gateway authorizer configuration
 */
export interface IGatewayAuthorizer {
    /**
     * The authorizer type
     */
    readonly authorizerType: GatewayAuthorizerType;
    /**
     * The authorizer configuration in CFN format
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                                  Custom JWT
 *****************************************************************************/
/**
 * Custom JWT authorizer configuration
 */
export interface CustomJwtConfiguration {
    /**
     * This URL is used to fetch OpenID Connect configuration or authorization server metadata
     * for validating incoming tokens.
     *
     * Pattern: .+/\.well-known/openid-configuration
     * Required: Yes
     */
    readonly discoveryUrl: string;
    /**
     * Represents individual audience values that are validated in the incoming JWT token validation process.   *
     * @default - No audience validation
     */
    readonly allowedAudience?: string[];
    /**
     * Represents individual client IDs that are validated in the incoming JWT token validation process.   *
     * @default - No client ID validation
     */
    readonly allowedClients?: string[];
}
/**
 * Custom JWT authorizer configuration implementation
 */
export declare class CustomJwtAuthorizer implements IGatewayAuthorizer {
    /**
     * Create a JWT authorizer from Cognito User Pool
     * @param props - The Cognito configuration
     * @returns CustomJwtAuthorizer configured for Cognito
     */
    static fromCognito(props: CognitoAuthorizerProps): CustomJwtAuthorizer;
    readonly authorizerType = GatewayAuthorizerType.CUSTOM_JWT;
    private readonly discoveryUrl;
    private readonly allowedAudience?;
    private readonly allowedClients?;
    constructor(config: CustomJwtConfiguration);
    /**
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                               AWS IAM
 *****************************************************************************/
/**
 * AWS IAM authorizer configuration implementation
 *
 */
export declare class IamAuthorizer implements IGatewayAuthorizer {
    readonly authorizerType = GatewayAuthorizerType.AWS_IAM;
    /**
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                               Factory
 *****************************************************************************/
export interface CognitoAuthorizerProps {
    /**
     * The Cognito User Pool to use for authentication
     */
    readonly userPool: UserPool;
    /**
     * The allowed User Pool clients
     * @default - All clients are allowed
     */
    readonly allowedClients?: IUserPoolClient[];
    /**
     * The allowed audiences for JWT validation
     * @default - No audience validation
     */
    readonly allowedAudiences?: string[];
}
/**
 * Factory class for creating Gateway Authorizers
 */
export declare abstract class GatewayAuthorizer {
    /**
     * AWS IAM authorizer instance
     */
    static awsIam: IamAuthorizer;
    /**
     * Create a custom JWT authorizer
     * @param configuration - The JWT configuration
     * @returns IGatewayAuthorizer configured for custom JWT
     */
    static usingCustomJwt(configuration: CustomJwtConfiguration): IGatewayAuthorizer;
    /**
     * Static method for creating a Cognito authorizer
     */
    static usingCognito(props: CognitoAuthorizerProps): IGatewayAuthorizer;
}
