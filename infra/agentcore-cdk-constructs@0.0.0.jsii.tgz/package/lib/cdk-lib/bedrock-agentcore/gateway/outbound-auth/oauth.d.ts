/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { Grant, IRole } from 'aws-cdk-lib/aws-iam';
import { CredentialProviderType, ICredentialProvider } from './credential-provider';
/******************************************************************************
 *                                OAuth
 *****************************************************************************/
/**
 * OAuth configuration
 */
export interface OAuthConfiguration {
    /**
     * The OAuth credential provider ARN.
     * This is returned when creating the OAuth credential provider via Console or API.
     * Format: arn:aws:bedrock-agentcore:region:account:token-vault/id/oauth2credentialprovider/name
     * Required: Yes
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret containing OAuth credentials (client ID and secret).
     * This is returned when creating the OAuth credential provider via Console or API.
     * Format: arn:aws:secretsmanager:region:account:secret:name
     * Required: Yes
     */
    readonly secretArn: string;
    /**
     * The OAuth scopes for the credential provider.
     * These scopes define the level of access requested from the OAuth provider.
     *
     * Array Members: Minimum number of 0 items. Maximum number of 100 items.
     * Length Constraints: Minimum length of 1. Maximum length of 64.
     * Required: Yes
     */
    readonly scopes: string[];
    /**
     * The custom parameters for the OAuth credential provider.
     * These parameters provide additional configuration for the OAuth authentication process.
     *
     * Map Entries: Maximum number of 10 items.
     * Key Length Constraints: Minimum length of 1. Maximum length of 256.
     * Value Length Constraints: Minimum length of 1. Maximum length of 2048.
     * Required: No
     */
    /**
     * Custom parameters for the OAuth flow
     * @default - No custom parameters
     */
    readonly customParameters?: Record<string, string>;
}
/**
 * OAuth credential provider configuration implementation
 */
export declare class OAuthCredentialProviderConfiguration implements ICredentialProvider {
    readonly credentialProviderType = CredentialProviderType.OAUTH;
    /**
     * The ARN of the OAuth provider
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret
     */
    readonly secretArn: string;
    /**
     * The OAuth scopes to request
     */
    readonly scopes: string[];
    /**
     * Custom parameters for the OAuth flow
     */
    readonly customParameters?: Record<string, string>;
    constructor(configuration: OAuthConfiguration);
    /**
     * Grant the needed permissions to the role for OAuth authentication
     */
    grantNeededPermissionsToRole(role: IRole): Grant | undefined;
    /**
     * @internal
     */
    _render(): any;
}
