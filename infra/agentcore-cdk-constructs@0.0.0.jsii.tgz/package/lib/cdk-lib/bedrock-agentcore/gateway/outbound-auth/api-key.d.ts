/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { Grant, IRole } from 'aws-cdk-lib/aws-iam';
import { CredentialProviderType, ICredentialProvider } from './credential-provider';
/******************************************************************************
 *                                 API KEY
 *****************************************************************************/
/**
 * API Key additional configuration
 */
export interface ApiKeyAdditionalConfiguration {
    /**
     * The name of the credential parameter for the API key.
     * This parameter name is used when sending the API key to the target endpoint.
     *
     * Length Constraints: Minimum length of 1. Maximum length of 64.
     * @default - 'Authorization' for HEADER, 'api_key' for QUERY_PARAMETER
     */
    readonly credentialParameterName?: string;
    /**
     * The prefix for the API key credential.
     * This prefix is added to the API key when sending it to the target endpoint.
     *
     * Length Constraints: Minimum length of 1. Maximum length of 64.
     * @default - 'Bearer ' for HEADER, no prefix for QUERY_PARAMETER
     */
    readonly credentialPrefix?: string;
}
/**
 * API Key credential location type
 * @internal
 */
export declare enum ApiKeyCredentialLocationType {
    HEADER = "HEADER",
    QUERY_PARAMETER = "QUERY_PARAMETER"
}
/**
 * API Key location within the request
 */
export declare class ApiKeyCredentialLocation {
    /**
     * Create a header-based API key credential location
     * @param config - Optional configuration for the credential location
     * @returns ApiKeyCredentialLocation configured for header placement
     */
    static header(config?: ApiKeyAdditionalConfiguration): ApiKeyCredentialLocation;
    /**
     * Create a query parameter-based API key credential location
     * @param config - Optional configuration for the credential location
     * @returns ApiKeyCredentialLocation configured for query parameter placement
     */
    static queryParameter(config?: ApiKeyAdditionalConfiguration): ApiKeyCredentialLocation;
    /**
     * The name of the credential parameter
     */
    readonly credentialParameterName: string;
    /**
     * The prefix for the credential value
     */
    readonly credentialPrefix?: string;
    /**
     * The type of credential location (HEADER or QUERY_PARAMETER)
     */
    readonly credentialLocationType: string;
    private constructor();
}
/**
 * API Key configuration
 */
export interface ApiKeyCredentialProviderProps {
    /**
     * The API key credential provider ARN.
     * This is returned when creating the API key credential provider via Console or API.
     * Format: arn:aws:bedrock-agentcore:region:account:token-vault/id/apikeycredentialprovider/name
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret containing the API key.
     * This is returned when creating the API key credential provider via Console or API.
     * Format: arn:aws:secretsmanager:region:account:secret:name
     */
    readonly secretArn: string;
    /**
     * The location of the API key credential.
     * This field specifies where in the request the API key should be placed.
     *
     * @default - HEADER
     */
    readonly credentialLocation?: ApiKeyCredentialLocation;
}
/**
 * API Key credential provider configuration implementation
 */
export declare class ApiKeyCredentialProviderConfiguration implements ICredentialProvider {
    readonly credentialProviderType = CredentialProviderType.API_KEY;
    /**
     * The ARN of the API key provider
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret
     */
    readonly secretArn: string;
    /**
     * The location configuration for the API key credential
     */
    readonly credentialLocation: ApiKeyCredentialLocation;
    constructor(configuration: ApiKeyCredentialProviderProps);
    /**
     * Grant the needed permissions to the role for API key authentication
     */
    grantNeededPermissionsToRole(role: IRole): Grant | undefined;
    /**
     * @internal
     */
    _render(): any;
}
