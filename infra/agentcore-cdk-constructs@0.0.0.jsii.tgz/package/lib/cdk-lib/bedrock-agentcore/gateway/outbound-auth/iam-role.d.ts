/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
/******************************************************************************
 *                                 IAM Role
 *****************************************************************************/
import { Grant, IRole } from 'aws-cdk-lib/aws-iam';
import { CredentialProviderType, ICredentialProvider } from './credential-provider';
/**
 * Gateway IAM Role credential provider configuration implementation
 */
export declare class GatewayIamRoleCredentialProvider implements ICredentialProvider {
    readonly credentialProviderType = CredentialProviderType.GATEWAY_IAM_ROLE;
    constructor();
    /**
     * @internal
     */
    _render(): any;
    /**
     * Grant needed permissions to the provided role
     * @param role The role to grant permissions to
     * @returns Grant object or undefined
     */
    grantNeededPermissionsToRole(role: IRole): Grant | undefined;
}
