/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { IResource, Resource } from 'aws-cdk-lib';
import { DimensionsMap, Metric, MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import { Construct } from 'constructs';
import { IGatewayAuthorizer } from './inbound-auth/authorizer';
import { IGatewayProtocol } from './protocol';
/******************************************************************************
 *                                 Enums
 *****************************************************************************/
/**
 * Exception levels for gateway
 */
export declare enum GatewayExceptionLevel {
    /**
     * Debug mode for granular exception messages. Allows the return of
     * specific error messages related to the gateway target configuration
     * to help you with debugging.
     */
    DEBUG = "DEBUG"
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for Gateway resources
 */
export interface IGateway extends IResource {
    /**
     * The ARN of the gateway resource
     * @attribute
     */
    readonly gatewayArn: string;
    /**
     * The id of the gateway
     * @attribute
     */
    readonly gatewayId: string;
    /**
     * The name of the gateway
     */
    readonly name: string;
    /**
     * The IAM role that provides permissions for the gateway to access AWS services
     */
    readonly role: iam.IRole;
    /**
     * The description of the gateway
     */
    readonly description?: string;
    /**
     * The protocol configuration for the gateway
     */
    readonly protocolConfiguration: IGatewayProtocol;
    /**
     * The authorizer configuration for the gateway
     */
    readonly authorizerConfiguration: IGatewayAuthorizer;
    /**
     * The exception level for the gateway
     */
    readonly exceptionLevel?: GatewayExceptionLevel;
    /**
     * The KMS key used for encryption
     */
    readonly kmsKey?: kms.IKey;
    /**
     * The URL endpoint for the gateway
     * @attribute
     */
    readonly gatewayUrl?: string;
    /**
     * The status of the gateway
     * @attribute
     */
    readonly status?: string;
    /**
     * The status reasons for the gateway.
     * @attribute
     */
    readonly statusReason?: string[];
    /**
     * Timestamp when the gateway was created
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * Timestamp when the gateway was last updated
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants permission to invoke this Gateway
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this gateway.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations for this gateway.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of throttled requests (429 status code) for this gateway.
     */
    metricThrottles(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of system errors (5xx status code) for this gateway.
     */
    metricSystemErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway.
     */
    metricUserErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the latency of requests for this gateway.
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the duration of requests for this gateway.
     */
    metricDuration(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the target execution time for this gateway.
     */
    metricTargetExecutionTime(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of requests served by each target type for this gateway.
     */
    metricTargetType(targetType: string, props?: MetricOptions): Metric;
}
/******************************************************************************
 *                                Base Class
 *****************************************************************************/
export declare abstract class GatewayBase extends Resource implements IGateway {
    abstract readonly gatewayArn: string;
    abstract readonly gatewayId: string;
    abstract readonly name: string;
    abstract readonly description?: string;
    abstract readonly protocolConfiguration: IGatewayProtocol;
    abstract readonly authorizerConfiguration: IGatewayAuthorizer;
    abstract readonly exceptionLevel?: GatewayExceptionLevel;
    abstract readonly kmsKey?: kms.IKey;
    abstract readonly role: iam.IRole;
    abstract readonly gatewayUrl?: string;
    abstract readonly status?: string;
    abstract readonly statusReason?: string[];
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    constructor(scope: Construct, id: string);
    /**
     * Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants permission to invoke this Gateway
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this gateway.   *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of invocations for this gateway.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of throttled requests (429 status code) for this gateway.
     */
    metricThrottles(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of system errors (5xx status code) for this gateway.
     */
    metricSystemErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of user errors (4xx status code, excluding 429) for this gateway.
     */
    metricUserErrors(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the latency of requests for this gateway.
     *
     * The latency metric represents the time elapsed between when the service receives
     * the request and when it begins sending the first response token.
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the duration of requests for this gateway.
     *
     * The duration metric represents the total time elapsed between receiving the request
     * and sending the final response token, representing complete end-to-end processing time.
     */
    metricDuration(props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the target execution time for this gateway.
     *
     * This metric helps determine the contribution of the target (Lambda, OpenAPI, etc.)
     * to the total latency.
     */
    metricTargetExecutionTime(props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of requests served by each target type for this gateway.
     */
    metricTargetType(targetType: string, props?: MetricOptions): Metric;
    /**
     * Internal method to create a metric.
     */
    private configureMetric;
}
