/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IGateway } from '../gateway-base';
import { ApiSchema } from './schema/api-schema';
import { ToolSchema } from './schema/tool-schema';
import { McpTargetType } from './target-base';
/******************************************************************************
 *                          Interface
 *****************************************************************************/
/**
 * Configuration returned by binding a target configuration
 */
export interface TargetConfigurationConfig {
    /**
     * Indicates that the configuration has been successfully bound
     */
    readonly bound: boolean;
}
/**
 * Base interface for target configurations
 */
export interface ITargetConfiguration {
    /**
     * The target type
     */
    readonly targetType: McpTargetType;
    /**
     * Binds the configuration to a construct scope
     * Sets up permissions and dependencies
     */
    bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig;
    /**
     * Renders the configuration as CloudFormation properties
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                     MCP Target Configuration Base
 *****************************************************************************/
/**
 * Abstract base class for MCP target configurations
 * Provides common functionality for all MCP target types
 */
export declare abstract class McpTargetConfiguration implements ITargetConfiguration {
    /**
     * The target type
     */
    abstract readonly targetType: McpTargetType;
    /**
     * Binds the configuration to a construct scope
     * Sets up permissions and dependencies
     */
    abstract bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig;
    /**
     * Renders the MCP-specific configuration
     */
    protected abstract renderMcpConfiguration(): any;
    /**
     * Renders the configuration as CloudFormation properties
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                     Lambda Target Configuration
 *****************************************************************************/
/**
 * Configuration for Lambda-based MCP targets
 *
 * This configuration wraps a Lambda function as MCP tools,
 * allowing the gateway to invoke the function to provide tool capabilities.
 */
export declare class LambdaTargetConfiguration extends McpTargetConfiguration {
    /**
     * Create a Lambda target configuration
     *
     * @param lambdaFunction The Lambda function to invoke
     * @param toolSchema The schema defining the tools
     * @returns A new LambdaTargetConfiguration instance
     */
    static create(lambdaFunction: IFunction, toolSchema: ToolSchema): LambdaTargetConfiguration;
    readonly targetType = McpTargetType.LAMBDA;
    /**
     * The Lambda function that implements the MCP server logic
     */
    readonly lambdaFunction: IFunction;
    /**
     * The tool schema that defines the available tools
     */
    readonly toolSchema: ToolSchema;
    constructor(lambdaFunction: IFunction, toolSchema: ToolSchema);
    /**
     * Binds this configuration to a construct scope
     * Sets up necessary permissions for the gateway to invoke the Lambda function
     *
     * @param scope The construct scope
     * @param gateway The gateway that will use this target
     */
    bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig;
    /**
     * Renders the MCP-specific configuration
     */
    protected renderMcpConfiguration(): any;
}
/******************************************************************************
 *                     OpenAPI Target Configuration
 *****************************************************************************/
/**
 * Configuration for OpenAPI-based MCP targets
 *
 * This configuration exposes an OpenAPI/REST API as MCP tools,
 * allowing the gateway to transform API operations into tool calls.
 */
export declare class OpenApiTargetConfiguration extends McpTargetConfiguration {
    /**
     * Create an OpenAPI target configuration
     *
     * @param apiSchema The OpenAPI schema
     * @returns A new OpenApiTargetConfiguration instance
     */
    static create(apiSchema: ApiSchema): OpenApiTargetConfiguration;
    readonly targetType = McpTargetType.OPENAPI_SCHEMA;
    /**
     * The OpenAPI schema that defines the API
     */
    readonly apiSchema: ApiSchema;
    constructor(apiSchema: ApiSchema);
    /**
     * Binds this configuration to a construct scope
     * Sets up necessary permissions for the gateway to access the API schema
     *
     * @param scope The construct scope
     * @param gateway The gateway that will use this target
     */
    bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig;
    /**
     * Renders the MCP-specific configuration
     */
    protected renderMcpConfiguration(): any;
}
/******************************************************************************
 *                     Smithy Target Configuration
 *****************************************************************************/
/**
 * Configuration for Smithy-based MCP targets
 *
 * This configuration exposes a Smithy-modeled API as MCP tools,
 * allowing the gateway to transform Smithy operations into tool calls.
 */
export declare class SmithyTargetConfiguration extends McpTargetConfiguration {
    /**
     * Create a Smithy target configuration
     *
     * @param smithyModel The Smithy model schema
     * @returns A new SmithyTargetConfiguration instance
     */
    static create(smithyModel: ApiSchema): SmithyTargetConfiguration;
    readonly targetType = McpTargetType.SMITHY_MODEL;
    /**
     * The Smithy model that defines the API
     */
    readonly smithyModel: ApiSchema;
    constructor(smithyModel: ApiSchema);
    /**
     * Binds this configuration to a construct scope
     * Sets up necessary permissions for the gateway to access the Smithy model
     *
     * @param scope The construct scope
     * @param gateway The gateway that will use this target
     */
    bind(scope: Construct, gateway: IGateway): TargetConfigurationConfig;
    /**
     * Renders the MCP-specific configuration
     */
    protected renderMcpConfiguration(): any;
}
