/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { Resource, IResource } from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import { IGateway } from '../gateway-base';
import { ICredentialProvider } from '../outbound-auth/credential-provider';
/******************************************************************************
 *                                 ENUM
 *****************************************************************************/
export declare enum GatewayTargetProtocolType {
    /** Model Context Protocol type */
    MCP = "MCP"
}
/**
 * MCP target types
 */
export declare enum McpTargetType {
    /** OpenAPI schema target type */
    OPENAPI_SCHEMA = "OPENAPI_SCHEMA",
    /** Smithy model target type */
    SMITHY_MODEL = "SMITHY_MODEL",
    /** Lambda function target type */
    LAMBDA = "LAMBDA"
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for GatewayTarget resources
 */
export interface IGatewayTarget extends IResource {
    /**
     * The ARN of the gateway target resource
     * @attribute
     */
    readonly targetArn: string;
    /**
     * The id of the gateway target
     * @attribute
     */
    readonly targetId: string;
    /**
     * The name of the gateway target
     */
    readonly name: string;
    /**
     * The description of the gateway target
     */
    readonly description?: string;
    /**
     * The gateway that this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The target protocol
     */
    readonly targetProtocolType: GatewayTargetProtocolType;
    /**
     * The credential provider configuration for the target
     */
    readonly credentialProviderConfigurations: ICredentialProvider[];
    /**
     * The status of the gateway target
     * @attribute
     */
    readonly status?: string;
    /**
     * The status reasons for the gateway target
     * @attribute
     */
    readonly statusReasons?: string[];
    /**
     * Timestamp when the gateway target was created
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * Timestamp when the gateway target was last updated
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway Target
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway Target
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Interface for MCP gateway targets
 */
export interface IMcpGatewayTarget extends IGatewayTarget {
    /**
     * The type of target
     */
    readonly targetType: McpTargetType;
}
/******************************************************************************
 *                                Base Class
 *****************************************************************************/
export declare abstract class GatewayTargetBase extends Resource implements IGatewayTarget {
    abstract readonly targetArn: string;
    abstract readonly targetId: string;
    abstract readonly name: string;
    abstract readonly description?: string;
    abstract readonly gateway: IGateway;
    abstract readonly credentialProviderConfigurations: ICredentialProvider[];
    abstract readonly status?: string;
    abstract readonly statusReasons?: string[];
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    abstract readonly targetProtocolType: GatewayTargetProtocolType;
    /**
     * Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Gateway Target
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Create`, `Update`, and `Delete` actions on the Gateway Target
     */
    grantManage(grantee: iam.IGrantable): iam.Grant;
}
