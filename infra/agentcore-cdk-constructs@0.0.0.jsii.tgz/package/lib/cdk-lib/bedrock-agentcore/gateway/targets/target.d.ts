/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { IFunction } from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import { IGateway } from '../gateway-base';
import { ApiSchema } from './schema/api-schema';
import { ToolSchema } from './schema/tool-schema';
import { GatewayTargetBase, GatewayTargetProtocolType, IGatewayTarget, IMcpGatewayTarget, McpTargetType } from './target-base';
import { ITargetConfiguration } from './target-configuration';
import { ICredentialProvider } from '../outbound-auth/credential-provider';
/******************************************************************************
 *                                Props
 *****************************************************************************/
/**
 * Common properties for all Gateway Target types
 */
export interface McpGatewayTargetCommonProps {
    /**
     * The name of the gateway target
     * The name must be unique within the gateway
     * Pattern: ^([0-9a-zA-Z][-]?){1,100}$
     */
    readonly gatewayTargetName: string;
    /**
     * Optional description for the gateway target
     * The description can have up to 200 characters
     * @default - No description
     */
    readonly description?: string;
}
/**
 * Properties for creating a Gateway Target resource
 */
export interface GatewayTargetProps extends McpGatewayTargetCommonProps {
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The target configuration (Lambda, OpenAPI, or Smithy)
     * Use one of the configuration helper classes:
     * - LambdaTargetConfiguration.create()
     * - OpenApiTargetConfiguration.create()
     * - SmithyTargetConfiguration.create()
     */
    readonly targetConfiguration: ITargetConfiguration;
    /**
     * Credential providers for authentication
     * @default - [GatewayCredentialProvider.iamRole()]
     */
    readonly credentialProviderConfigurations?: ICredentialProvider[];
}
/**
 * Properties for creating a Lambda-based Gateway Target
 * Convenience interface for the most common use case
 */
export interface GatewayTargetLambdaProps extends McpGatewayTargetCommonProps {
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The Lambda function to associate with this target
     */
    readonly lambdaFunction: IFunction;
    /**
     * The tool schema defining the available tools
     */
    readonly toolSchema: ToolSchema;
    /**
     * Credential providers for authentication
     * @default - [GatewayCredentialProvider.iamRole()]
     */
    readonly credentialProviderConfigurations?: ICredentialProvider[];
}
/**
 * Properties for creating an OpenAPI-based Gateway Target
 */
export interface GatewayTargetOpenApiProps extends McpGatewayTargetCommonProps {
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The OpenAPI schema defining the API
     */
    readonly apiSchema: ApiSchema;
    /**
     * Credential providers for authentication
     * @default - [GatewayCredentialProvider.iamRole()]
     */
    readonly credentialProviderConfigurations?: ICredentialProvider[];
}
/**
 * Properties for creating a Smithy-based Gateway Target
 */
export interface GatewayTargetSmithyProps extends McpGatewayTargetCommonProps {
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The Smithy model defining the API
     */
    readonly smithyModel: ApiSchema;
    /**
     * Credential providers for authentication
     * @default - [GatewayCredentialProvider.iamRole()]
     */
    readonly credentialProviderConfigurations?: ICredentialProvider[];
}
/**
 * Attributes for importing an existing Gateway Target
 */
export interface GatewayTargetAttributes {
    /**
     * The ARN of the gateway target
     */
    readonly targetArn: string;
    /**
     * The ID of the gateway target
     */
    readonly targetId: string;
    /**
     * The name of the gateway target
     */
    readonly gatewayTargetName: string;
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * Optional status of the target
     * @default - No status
     */
    readonly status?: string;
    /**
     * Optional creation timestamp
     * @default - No creation timestamp
     */
    readonly createdAt?: string;
    /**
     * Optional last update timestamp
     * @default - No update timestamp
     */
    readonly updatedAt?: string;
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 *
 * Defines tools that your gateway will host. Supports multiple target types:
 * - Lambda: Wraps a Lambda function as MCP tools
 * - OpenAPI: Exposes an OpenAPI/REST API as MCP tools
 * - Smithy: Exposes a Smithy-modeled API as MCP tools
 *
 * @resource AWS::BedrockAgentCore::GatewayTarget
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-building-adding-targets.html
 */
export declare class GatewayTarget extends GatewayTargetBase implements IMcpGatewayTarget {
    /**
     * Import an existing Gateway Target using its attributes
     * This allows you to reference a Gateway Target that was created outside of CDK
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param attrs The attributes of the existing Gateway Target
     * @returns An IGatewayTarget instance representing the imported target
     */
    static fromGatewayTargetAttributes(scope: Construct, id: string, attrs: GatewayTargetAttributes): IGatewayTarget;
    /**
     * Create a Lambda-based MCP target
     * Convenience method for creating a target that wraps a Lambda function
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param props The properties for the Lambda target
     * @returns A new GatewayTarget instance
     */
    static forLambda(scope: Construct, id: string, props: GatewayTargetLambdaProps): GatewayTarget;
    /**
     * Create an OpenAPI-based MCP target
     * Convenience method for creating a target that exposes an OpenAPI/REST API
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param props The properties for the OpenAPI target
     * @returns A new GatewayTarget instance
     *
     */
    static forOpenApi(scope: Construct, id: string, props: GatewayTargetOpenApiProps): GatewayTarget;
    /**
     * Create a Smithy-based MCP target
     * Convenience method for creating a target that exposes a Smithy-modeled API
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param props The properties for the Smithy target
     * @returns A new GatewayTarget instance
     */
    static forSmithy(scope: Construct, id: string, props: GatewayTargetSmithyProps): GatewayTarget;
    /**
     * The ARN of the gateway target
     * @attribute
     */
    readonly targetArn: string;
    /**
     * The unique identifier of the gateway target
     * @attribute
     */
    readonly targetId: string;
    /**
     * The name of the gateway target
     */
    readonly name: string;
    /**
     * Optional description for the gateway target
     */
    readonly description: string | undefined;
    /**
     * The gateway this target belongs to
     */
    readonly gateway: IGateway;
    /**
     * The credential providers for this target
     */
    readonly credentialProviderConfigurations: ICredentialProvider[];
    /**
     * The protocol type (always MCP for now)
     */
    readonly targetProtocolType = GatewayTargetProtocolType.MCP;
    /**
     * The specific MCP target type (Lambda, OpenAPI, or Smithy)
     */
    readonly targetType: McpTargetType;
    /**
     * The status of the gateway target
     * @attribute
     */
    readonly status?: string | undefined;
    /**
     * The status reasons for the gateway target
     * @attribute
     */
    readonly statusReasons?: string[];
    /**
     * Timestamp when the gateway target was created
     * @attribute
     */
    readonly createdAt?: string | undefined;
    /**
     * Timestamp when the gateway target was last updated
     * @attribute
     */
    readonly updatedAt?: string | undefined;
    private readonly targetResource;
    private readonly targetConfiguration;
    constructor(scope: Construct, id: string, props: GatewayTargetProps);
    /**
     * Validates the gateway target name format
     * Pattern: ^([0-9a-zA-Z][-]?){1,100}$
     * Max length: 100 characters
     * @param gatewayTargetName The gateway target name to validate
     * @throws Error if the name is invalid
     */
    protected validateGatewayTargetName(gatewayTargetName: string): void;
    /**
     * Validates the description format
     * Must be between 1 and 200 characters
     * @throws Error if validation fails
     */
    private validateDescription;
}
