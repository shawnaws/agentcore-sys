/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
export declare namespace GatewayPerms {
    /******************************************************************************
   * Data Plane Permissions
   *****************************************************************************/
    /**
     * Permissions to invoke the gateway
     * Used by agents or other services that need to call the gateway
     */
    const INVOKE_PERMS: string[];
    /******************************************************************************
     * Execution Role Permissions
     *****************************************************************************/
    /**
     * Gateway service role permissions
     * Used by the Gateway to manage its own resources and invoke targets
     */
    const SERVICE_ROLE_PERMS: string[];
    /**
     * Workload identity permissions
     * Used to manage authentication identities for gateway access
     */
    const WORKLOAD_IDENTITY_PERMS: string[];
    /**
     * Credential provider permissions
     * Used to manage credential configurations for outbound auth
     */
    const CREDENTIAL_PROVIDER_PERMS: string[];
    /**
     * Token management permissions
     * Used for JWT token operations
     */
    const TOKEN_PERMS: string[];
    /**
     * Access control permissions
     * Used to manage who can access the gateway
     */
    const ACCESS_PERMS: string[];
    /**
     * Lambda target permissions
     * Required when Gateway invokes Lambda functions
     */
    const LAMBDA_INVOKE_PERMS: string[];
    /**
     * KMS permissions for encryption
     * Required when using KMS keys for encryption
     */
    const KMS_KEY_PERMS: string[];
    /**
     * Assume role
     */
    const ASSUME_ROLE: string[];
    const GATEWAY_WORKLOAD_IDENTITY_PERMS: string[];
    const GATEWAY_OAUTH_PERMS: string[];
    const GATEWAY_API_KEY_PERMS: string[];
    /**
     * S3 permissions for schema storage
     * Required when schemas are stored in S3
     */
    const S3_SCHEMA_PERMS: string[];
    /**
     * Secrets Manager permissions
     * Required for storing and retrieving API keys and OAuth credentials
     */
    const SECRETS_PERMS: string[];
    /**
     * CloudWatch Logs permissions for gateway logs
     */
    const LOGS_PERMS: string[];
    const GET_PERMS: string[];
    const LIST_PERMS: string[];
    const CREATE_PERMS: string[];
    const UPDATE_PERMS: string[];
    const DELETE_PERMS: string[];
    const READ_PERMS: string[];
    const MANAGE_PERMS: string[];
}
