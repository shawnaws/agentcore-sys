/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as bedrockagentcore from 'aws-cdk-lib/aws-bedrockagentcore';
import { Grant, IRole } from 'aws-cdk-lib/aws-iam';
import { IMemoryStrategy, MemoryStrategyClassType, MemoryStrategyCommonProps, MemoryStrategyType } from '../memory-strategy';
/**
 * If you need long-term memory for context recall across sessions,
 * you can setup memory extraction strategies to extract the relevant memory from the raw events.
 * Use built-in strategies for quick setup
 */
export declare class BuiltInMemoryStrategy implements IMemoryStrategy {
    readonly strategyClassType: MemoryStrategyClassType;
    readonly name: string;
    readonly description?: string;
    readonly namespaces: string[];
    readonly strategyType: MemoryStrategyType;
    constructor(strategyType: MemoryStrategyType, props: MemoryStrategyCommonProps);
    /**
     * Renders the network configuration as a CloudFormation property.
     * @returns The CloudFormation property for the memory strategy.
     */
    render(): bedrockagentcore.CfnMemory.MemoryStrategyProperty;
    /**
     * Grants the necessary permissions to the role
     * @param _role - The role to grant permissions to
     * @returns The Grant object for chaining
     */
    grant(_role: IRole): Grant | undefined;
    /**
     * Validates the memory strategy
     * @param name - The name to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyName;
    /**
     * Validates the memory strategy namespaces
     * @param namespaces - The namespaces to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyNamespaces;
}
