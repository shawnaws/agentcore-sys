/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { IBedrockInvokable } from '@aws-cdk/aws-bedrock-alpha';
import * as bedrockagentcore from 'aws-cdk-lib/aws-bedrockagentcore';
import { Grant, IRole } from 'aws-cdk-lib/aws-iam';
import { MemoryStrategyCommonProps, IMemoryStrategy, MemoryStrategyClassType, MemoryStrategyType } from '../memory-strategy';
/**
 * Configuration for overriding model and prompt template
 */
export interface OverrideConfig {
    /**
     * The model to use for consolidation/extraction
     */
    readonly model: IBedrockInvokable;
    /**
     * The prompt that will be appended to the system prompt to define
     * the model's memory consolidation/extraction strategy.
     * This configuration provides customization to how the model identifies and extracts
     * relevant information for memory storage. You can use the default user prompt or create a customized one.
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/system-prompts.html
     */
    readonly appendToPrompt: string;
}
/**
 * Configuration parameters for a memory strategy that overrides
 * existing built-in default prompts/models
 */
export interface OverrideStrategyProps extends MemoryStrategyCommonProps {
    /**
     * The configuration for the custom extraction.
     * This configuration provides customization to how the model identifies
     * and extracts relevant information for memory storage.
     * @default - No custom extraction
     * @required - No
     */
    readonly customExtraction?: OverrideConfig;
    /**
     * The configuration for the custom consolidation.
     * This configuration provides customization to how the model identifies
     * and extracts relevant information for memory storage.
     * @default - No custom extraction
     * @required - No
     */
    readonly customConsolidation?: OverrideConfig;
}
/**
 * If you need long-term memory for context recall across sessions,
 * you can setup memory extraction strategies to extract the relevant memory from the raw events.
 * use built-in strategies with override to specify models and prompt templates.
 * Custom memory strategies let you tailor memory extraction and consolidation to your specific domain or use case.
 * You can override the prompts for extracting and consolidating semantic, summary, or user preferences.
 * You can also choose the model that you want to use for extraction and consolidation.
 * The custom prompts you create are appended to a non-editable system prompt.
 */
export declare class OverrideMemoryStrategy implements IMemoryStrategy {
    readonly strategyClassType: MemoryStrategyClassType;
    readonly name: string;
    readonly description?: string;
    readonly namespaces: string[];
    readonly consolidationOverride?: OverrideConfig;
    readonly extractionOverride?: OverrideConfig;
    readonly strategyType: MemoryStrategyType;
    /**
     * Constructor to create a new override memory strategy type
     * @param strategyType the strategy type to override
     * @param props the properties for the override
     */
    constructor(strategyType: MemoryStrategyType, props: OverrideStrategyProps);
    /**
     * Renders the network configuration as a CloudFormation property.
     * @returns The CloudFormation property for the memory strategy.
     */
    render(): bedrockagentcore.CfnMemory.MemoryStrategyProperty;
    /**
     * Grants the necessary permissions to the role
     * @param role - The role to grant permissions to
     * @returns The Grant object for chaining
     */
    grant(role: IRole): Grant | undefined;
    /**
     * Validates the memory strategy
     * @param name - The name to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyName;
    /**
     * Validates the memory strategy
     * @param name - The name to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validatePrompt;
    /**
     * Validates the memory strategy namespaces
     * @param namespaces - The namespaces to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyNamespaces;
}
