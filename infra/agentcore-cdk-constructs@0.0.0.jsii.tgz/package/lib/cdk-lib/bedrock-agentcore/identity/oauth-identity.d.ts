/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
import { IdentityType, IdentityBase, CommonIdentityProps, CommonIdentityAttributes, IIdentity } from './identity';
import { OAuthProviderConfig } from './oauth-provider';
/**
 * Represents an OAuth Identity, either created with CDK or imported.
 */
export interface IOAuthIdentity extends IIdentity {
    /**
     * The Amazon Resource Name (ARN) of the client secret in AWS Secrets Manager.
     */
    readonly clientSecretArn: string;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating an OAuth Identity.
 */
export interface OAuthIdentityProps extends CommonIdentityProps {
    /**
     * The OAuth provider configuration.
     */
    readonly oauthProvider: OAuthProviderConfig;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Properties for importing an API key identity outside of this stack
 */
export interface OAuthIdentityAttributes extends CommonIdentityAttributes {
    /**
     * The Amazon Resource Name (ARN) of the client secret in AWS Secrets Manager.
     */
    readonly clientSecretArn: string;
}
/******************************************************************************
 *                              ABSTRACT CLASS
 *****************************************************************************/
export declare abstract class OAuthIdentityBase extends IdentityBase {
    abstract readonly clientSecretArn: string;
    abstract readonly credentialProviderArn: string;
    readonly identityType: IdentityType;
}
/******************************************************************************
 *                        		  CONSTRUCT
 *****************************************************************************/
export declare class OAuthIdentity extends OAuthIdentityBase {
    static fromOAuthIdentityAttributes(scope: Construct, id: string, attrs: OAuthIdentityAttributes): IOAuthIdentity;
    readonly clientSecretArn: string;
    readonly credentialProviderArn: string;
    readonly name: string;
    readonly identityType: IdentityType;
    constructor(scope: Construct, id: string, props: OAuthIdentityProps);
    /**
     * Validates the OAuth provider format
     * @param oauthProvider The OAuth provider to validate
     * @throws Error if the OAuth provider is invalid
     */
    private validateOAuthProvider;
    /**
     * Grant the given principal identity permissions to read this OAuth identity.
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
