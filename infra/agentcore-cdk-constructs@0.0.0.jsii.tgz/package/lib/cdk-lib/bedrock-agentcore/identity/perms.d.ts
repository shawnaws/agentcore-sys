/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
export declare namespace IdentityPerms {
    namespace API_KEY {
        /******************************************************************************
         *                         Control Plane Permissions
         *****************************************************************************/
        /**
         * Permissions to read API key identity.
         */
        const READ_PERMS: string[];
        /**
         * Permissions to update API key identity.
         */
        const UPDATE_PERMS: string[];
        /**
         * Permissions to list all API Key Credential Providers in the Token Vault
         */
        const LIST_PERMS: string[];
    }
    namespace OAUTH {
        /******************************************************************************
         *                         Control Plane Permissions
         *****************************************************************************/
        /**
         * Permissions to read OAuth identity.
         */
        const READ_PERMS: string[];
        /**
         * Permissions to update OAuth identity.
         */
        const UPDATE_PERMS: string[];
        /**
         * Permissions to list all OAuth2 Credential Providers in the Token Vault
         */
        const LIST_PERMS: string[];
    }
    const GET_SECRET_PERMS: string[];
}
