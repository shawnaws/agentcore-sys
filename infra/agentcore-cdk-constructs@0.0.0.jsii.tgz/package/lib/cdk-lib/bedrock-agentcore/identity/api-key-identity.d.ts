/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as iam from 'aws-cdk-lib/aws-iam';
import { Construct } from 'constructs';
import { IdentityType, IdentityBase, CommonIdentityProps, CommonIdentityAttributes, IIdentity } from './identity';
/**
 * Represents an API Key Identity, either created with CDK or imported.
 */
export interface IApiKeyIdentity extends IIdentity {
    /**
     * The API key secret ARN.
     */
    readonly apiKeySecretArn: string;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating an API Key Identity.
 */
export interface ApiKeyIdentityProps extends CommonIdentityProps {
    /**
     * The API key credential provider configuration.
     */
    readonly apiKey: string;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Properties for importing an API key identity outside of this stack
 */
export interface ApiKeyIdentityAttributes extends CommonIdentityAttributes {
    /**
     * The API key ARN.
     */
    readonly apiKeySecretArn: string;
}
/******************************************************************************
 *                              ABSTRACT CLASS
 *****************************************************************************/
export declare abstract class ApiKeyIdentityBase extends IdentityBase {
    abstract readonly apiKeySecretArn: string;
    abstract readonly credentialProviderArn: string;
    readonly identityType: IdentityType;
}
/******************************************************************************
 *                        		  CONSTRUCT
 *****************************************************************************/
export declare class ApiKeyIdentity extends ApiKeyIdentityBase {
    static fromApiKeyIdentityAttributes(scope: Construct, id: string, attrs: ApiKeyIdentityAttributes): IApiKeyIdentity;
    readonly apiKeySecretArn: string;
    readonly credentialProviderArn: string;
    readonly name: string;
    readonly identityType: IdentityType;
    constructor(scope: Construct, id: string, props: ApiKeyIdentityProps);
    /**
     * Grant the given principal identity permissions to read this API key identity.
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
