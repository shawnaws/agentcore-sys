/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
export declare enum OAuthProviderType {
    GOOGLE_OAUTH2 = "GoogleOauth2",
    GITHUB_OAUTH2 = "GithubOauth2",
    SLACK_OAUTH2 = "SlackOauth2",
    SALESFORCE_OAUTH2 = "SalesforceOauth2",
    MICROSOFT_OAUTH2 = "MicrosoftOauth2",
    CUSTOM_OAUTH2 = "CustomOauth2"
}
/**
 * OAuth2 Authorization Server Metadata interface for when you need to configure
 * a custom OAuth2 provider and you do not use the Discovery URL, but rather specify
 * all details manually.
 */
export interface Oauth2AuthorizationServerMetadata {
    /**
     * The authorization endpoint URL for the OAuth2 authorization server.
     *
     * @example "https://auth.example.com/oauth2/identity"
     */
    readonly authorizationEndpoint: string;
    /**
     * The token endpoint URL for the OAuth2 authorization server.
     * @example "https://auth.example.com/oauth2/token"
     */
    readonly tokenEndpoint: string;
    /**
     * The issuer URL for the OAuth2 authorization server.
     * @example "https://auth.example.com"
     */
    readonly issuer: string;
    /**
     * The OAuth 2.0 response types supported by the authorization server.
     * @example ["code", "token"]
     */
    readonly responseTypes?: string[];
}
/**
 * OAuth2 Discovery interface for for when you need to configure a custom OAuth2
 * provider and you want clients to dynamically discover using the Discovery URL.
 */
export interface Oauth2Discovery {
    /**
     * The authorization server metadata for the OAuth2 provider.
     */
    readonly authorizationServerMetadata?: Oauth2AuthorizationServerMetadata;
    /**
     * The discovery URL for the OAuth2 provider.
     * @example "https://accounts.example.com/.well-known/openid-configuration"
     */
    readonly discoveryUrl?: string;
}
/**
 * Base interface for OAuth2 provider configuration.
 */
export interface BaseOauth2ProviderConfig {
    /**
     * The client ID for the OAuth2 provider.
     */
    readonly clientId: string;
    /**
     * The client secret for the OAuth2 provider.
     */
    readonly clientSecret: string;
}
/**
 * Custom OAuth2 provider configuration interface.
 */
export interface CustomOauth2ProviderConfig extends BaseOauth2ProviderConfig {
    /**
     * The OAuth2 discovery information for the custom provider.
     */
    readonly oauthDiscovery: Oauth2Discovery;
}
/**
 * Abstract base class for all OAuth provider types.
 */
export declare abstract class OAuthProviderConfig {
    /**
     * The string value of the OAuth provider type.
     */
    readonly value: string;
    readonly clientId: string;
    readonly clientSecret: string;
    /**
     * Constructor for OAuth provider type.
     */
    protected constructor(value: string, config: BaseOauth2ProviderConfig);
    /**
     * Returns the string representation of the OAuth provider type.
     * @returns The string value of the OAuth provider type.
     */
    toString(): string;
}
/**
 * Google OAuth2 provider.
 */
export declare class GoogleOauth2Config extends OAuthProviderConfig {
    constructor(config: BaseOauth2ProviderConfig);
}
/**
 * GitHub OAuth2 provider.
 */
export declare class GithubOauth2Config extends OAuthProviderConfig {
    constructor(config: BaseOauth2ProviderConfig);
}
/**
 * Slack OAuth2 provider.
 */
export declare class SlackOauth2Config extends OAuthProviderConfig {
    constructor(config: BaseOauth2ProviderConfig);
}
/**
 * Salesforce OAuth2 provider.
 */
export declare class SalesforceOauth2Config extends OAuthProviderConfig {
    constructor(config: BaseOauth2ProviderConfig);
}
/**
 * Microsoft OAuth2 provider.
 */
export declare class MicrosoftOauth2Config extends OAuthProviderConfig {
    constructor(config: BaseOauth2ProviderConfig);
}
/**
 * Custom OAuth2 provider.
 */
export declare class CustomOauth2Config extends OAuthProviderConfig {
    readonly oauthDiscovery: Oauth2Discovery;
    constructor(config: CustomOauth2ProviderConfig);
}
