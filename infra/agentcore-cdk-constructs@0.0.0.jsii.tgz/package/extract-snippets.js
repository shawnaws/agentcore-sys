#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

/**
 * Script to extract code snippets from .jsii.tabl.json and organize them by language
 * into a multi-languages.md file
 */

function extractSnippetsFromTabl() {
    const tablFilePath = path.join(__dirname, '.jsii.tabl.json');
    const outputFilePath = path.join(__dirname, 'multi-languages.md');
    
    try {
        // Read the tabl file
        const tablContent = fs.readFileSync(tablFilePath, 'utf8');
        const tablData = JSON.parse(tablContent);
        
        // Organize snippets by language
        const snippetsByLanguage = {};
        let snippetCount = 0;
        
        // Process each snippet
        for (const [snippetId, snippetData] of Object.entries(tablData.snippets)) {
            if (snippetData.translations) {
                for (const [language, translation] of Object.entries(snippetData.translations)) {
                    if (!snippetsByLanguage[language]) {
                        snippetsByLanguage[language] = [];
                    }
                    
                    snippetsByLanguage[language].push({
                        id: snippetId,
                        source: translation.source,
                        version: translation.version || '1'
                    });
                }
                snippetCount++;
            }
        }
        
        // Generate markdown content
        let markdownContent = `# Multi-Language Code Snippets

This file contains code snippets extracted from the .jsii.tabl.json file, organized by programming language.

**Total snippets processed:** ${snippetCount}
**Languages available:** ${Object.keys(snippetsByLanguage).map(lang => lang === '$' ? 'TypeScript' : lang).join(', ')}

## Table of Contents

`;
        
        // Add table of contents
        const availableLanguages = Object.keys(snippetsByLanguage);
        const languageOrder = ['$', 'python', 'java', 'csharp', 'go'];
        
        // Process languages in preferred order, then add any remaining ones
        const orderedLanguages = [
            ...languageOrder.filter(lang => availableLanguages.includes(lang)),
            ...availableLanguages.filter(lang => !languageOrder.includes(lang))
        ];
        
        // Generate table of contents
        for (const language of orderedLanguages) {
            const languageName = language === '$' ? 'TypeScript' : language.charAt(0).toUpperCase() + language.slice(1);
            const anchor = language === '$' ? 'typescript' : language.toLowerCase();
            markdownContent += `- [${languageName}](#${anchor})\n`;
        }
        
        markdownContent += '\n---\n\n';
        
        // Add content for each language
        for (const language of orderedLanguages) {
            const snippets = snippetsByLanguage[language];
            const languageName = language === '$' ? 'TypeScript' : language.charAt(0).toUpperCase() + language.slice(1);
            const anchor = language === '$' ? 'typescript' : language.toLowerCase();
            
            markdownContent += `## ${languageName}\n\n`;
            markdownContent += `**${snippets.length} snippet(s) available**\n\n`;
            
            snippets.forEach((snippet, index) => {
                markdownContent += `### Snippet ${index + 1} (ID: ${snippet.id.substring(0, 8)}...)\n\n`;
                const codeLanguage = language === '$' ? 'typescript' : language;
                markdownContent += `\`\`\`${codeLanguage}\n`;
                markdownContent += snippet.source;
                markdownContent += `\n\`\`\`\n\n`;
            });
            
            markdownContent += '---\n\n';
        }
        
        // Write the markdown file
        fs.writeFileSync(outputFilePath, markdownContent, 'utf8');
        
        console.log(`✅ Successfully extracted ${snippetCount} snippets`);
        console.log(`📝 Generated multi-languages.md with content for ${Object.keys(snippetsByLanguage).length} languages`);
        console.log(`📁 Output file: ${outputFilePath}`);
        
        // Print summary
        console.log('\n📊 Summary by language:');
        for (const [language, snippets] of Object.entries(snippetsByLanguage)) {
            console.log(`   ${language}: ${snippets.length} snippets`);
        }
        
    } catch (error) {
        console.error('❌ Error processing tabl file:', error.message);
        process.exit(1);
    }
}

// Run the extraction
if (require.main === module) {
    extractSnippetsFromTabl();
}

module.exports = { extractSnippetsFromTabl };
